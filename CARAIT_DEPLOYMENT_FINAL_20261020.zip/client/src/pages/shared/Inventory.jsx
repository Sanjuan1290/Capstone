import { BrowserMultiFormatReader } from '@zxing/browser'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  MdAdd, MdCameraAlt, MdClose, MdDelete, MdEdit, MdInventory2,
  MdQrCodeScanner, MdRefresh, MdSave, MdSearch, MdWarningAmber,
  MdCheckCircle, MdLocationOn, MdCalendarToday, MdFlashOn, MdCameraswitch, MdUploadFile, MdSwapHoriz,
} from 'react-icons/md'
import { useToast } from '../../components/ui/ToastProvider'
import ConfirmDialog from '../../components/ui/ConfirmDialog'

const CATEGORIES = [{ value: 'medical', label: 'General Medicine' }, { value: 'derma', label: 'Dermatology' }]
const ITEM_TYPES = [{ value: 'medicine', label: 'Medicine' }, { value: 'supplies', label: 'Supplies' }]
const ITEMS_PER_PAGE = 5
const supplierSupportsClinic = (supplier, clinic) => String(supplier?.category || '')
  .split(',')
  .map((value) => value.trim())
  .filter(Boolean)
  .includes(clinic)

const CODE39_PATTERNS = {
  '0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw',
  '5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn',
  A:'wnnnnwnnw',B:'nnwnnwnnw',C:'wnwnnwnnn',D:'nnnnwwnnw',E:'wnnnwwnnn',F:'nnwnwwnnn',
  G:'nnnnnwwnw',H:'wnnnnwwnn',I:'nnwnnwwnn',J:'nnnnwwwnn',K:'wnnnnnnww',L:'nnwnnnnww',
  M:'wnwnnnnwn',N:'nnnnwnnww',O:'wnnnwnnwn',P:'nnwnwnnwn',Q:'nnnnnnwww',R:'wnnnnnwwn',
  S:'nnwnnnwwn',T:'nnnnwnwwn',U:'wwnnnnnnw',V:'nwwnnnnnw',W:'wwwnnnnnn',X:'nwnnwnnnw',
  Y:'wwnnwnnnn',Z:'nwwnwnnnn','-':'nwnnnnwnw','.':'wwnnnnwnn',' ':'nwwnnnwnn',
  '$':'nwnwnwnnn','/':'nwnwnnnwn','+':'nwnnnwnwn','%':'nnnwnwnwn','*':'nwnnwnwnn',
}

const buildCode39 = (rawValue) => {
  const value = String(rawValue || '').trim().toUpperCase()
  if (!value || [...value].some((char) => !CODE39_PATTERNS[char] || char === '*')) return null
  const bars = []
  let x = 10
  for (const char of `*${value}*`) {
    const pattern = CODE39_PATTERNS[char]
    for (let index = 0; index < pattern.length; index += 1) {
      const width = pattern[index] === 'w' ? 3 : 1
      if (index % 2 === 0) bars.push({ x, width })
      x += width
    }
    x += 1
  }
  return { value, bars, width: x + 9 }
}

const BarcodePreview = ({ value, title = 'Barcode', compact = false }) => {
  const encoded = buildCode39(value)
  if (!String(value || '').trim()) return null
  if (!encoded) {
    return <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-700">Barcode preview is unavailable for characters outside Code 39, but the entered code can still be saved and scanned by supported product scanners.</div>
  }
  return <div className={`rounded-2xl border border-slate-200 bg-white ${compact ? 'p-2.5' : 'p-4'}`}>
    <div className="mb-2 flex items-center justify-between gap-2">
      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{title}</span>
      <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">Scannable</span>
    </div>
    <div className="overflow-hidden rounded-lg bg-white px-2 py-1">
      <svg viewBox={`0 0 ${encoded.width} 54`} className={`${compact ? 'h-10' : 'h-16'} w-full`} preserveAspectRatio="xMidYMid meet" role="img" aria-label={`${title}: ${encoded.value}`} shapeRendering="crispEdges">
        <rect width={encoded.width} height="54" fill="white" />
        {encoded.bars.map((bar, index) => <rect key={`${bar.x}-${index}`} x={bar.x} y="3" width={bar.width} height="46" fill="black" />)}
      </svg>
    </div>
    <p className={`mt-1 text-center font-mono font-bold tracking-[0.16em] text-slate-800 ${compact ? 'text-[9px]' : 'text-xs'}`}>{encoded.value}</p>
  </div>
}

const getNextGeneratedItemCode = (category, items = []) => {
  const prefix = category === 'derma' ? 'DRM' : 'GMED'
  let max = 0
  for (const item of items) {
    const match = String(item?.barcode || '').match(new RegExp(`^${prefix}-(\\d+)$`, 'i'))
    if (match) max = Math.max(max, Number(match[1]) || 0)
  }
  return `${prefix}-${String(max + 1).padStart(5, '0')}`
}

const getNextBatchCodePreview = (item) => {
  const prefix = String(item?.barcode || `ITEM-${item?.id || 'NEW'}`).trim()
  let max = 0
  for (const batch of Array.isArray(item?.batches) ? item.batches : []) {
    const escaped = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    const match = String(batch?.batch_code || '').match(new RegExp(`^${escaped}-B(\\d+)$`, 'i'))
    if (match) max = Math.max(max, Number(match[1]) || 0)
  }
  return `${prefix}-B${String(max + 1).padStart(3, '0')}`
}

const DEFAULT_STOCK_IN_REASONS = [
  { value: 'received', label: 'Received from Supplier' },
  { value: 'returned', label: 'Returned to Stock' },
  { value: 'correction_in', label: 'Inventory Correction (+)' },
]

const DEFAULT_STOCK_OUT_REASONS = [
  { value: 'adjustment_out', label: 'Inventory Correction (-)' },
  { value: 'expired', label: 'Expired Stock' },
  { value: 'damaged', label: 'Damaged Stock' },
  { value: 'wastage', label: 'Wastage / Spillage' },
  { value: 'returned_to_supplier', label: 'Returned to Supplier' },
]



const getPackageCount = (item) => {
  const unitSize = Number(item.unit_size || 1)
  const stockBase = Number(item.stock_base ?? Number(item.stock || 0) * unitSize)
  return Math.floor(stockBase / unitSize)
}

const getStockBadge = (item) => {
  const count = getPackageCount(item)
  if (count === 0) return 'bg-red-50 text-red-600 border-red-200'
  if (count <= Number(item.threshold || 0)) return 'bg-amber-50 text-amber-700 border-amber-200'
  return 'bg-emerald-50 text-emerald-700 border-emerald-200'
}

const parseDateOnly = (value) => {
  const normalized = String(value || '').trim().slice(0, 10)
  const [year, month, day] = normalized.split('-').map(Number)
  if (!year || !month || !day) return null
  return new Date(year, month - 1, day)
}

const formatDate = (value) => {
  if (!value) return 'No expiry recorded'
  const parsed = parseDateOnly(value)
  if (!parsed) return 'No expiry recorded'
  return parsed.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })
}

const formatUnits = (value) => {
  const qty = Number(value || 0)
  return `${qty} unit${qty === 1 ? '' : 's'}`
}

const formatBatchLabel = (batch) => {
  const qty = Number(batch?.quantity || 0)
  const expiry = batch?.expiration_date ? formatDate(batch.expiration_date) : 'No expiry'
  return `${formatUnits(qty)} - ${expiry}`
}

const getExpiryMeta = (item) => {
  if (!item.expiration_date) return { label: 'No expiry recorded', tone: 'text-slate-400' }
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const expiry = parseDateOnly(item.expiration_date)
  if (!expiry) return { label: 'No expiry recorded', tone: 'text-slate-400' }
  expiry.setHours(0, 0, 0, 0)
  const diffDays = Math.round((expiry - today) / 86400000)
  if (diffDays < 0) return { label: `Expired ${Math.abs(diffDays)} day${Math.abs(diffDays) === 1 ? '' : 's'} ago`, tone: 'text-red-600' }
  if (diffDays <= 30) return { label: `Expires in ${diffDays} day${diffDays === 1 ? '' : 's'}`, tone: 'text-amber-600' }
  return { label: `Expires ${formatDate(item.expiration_date)}`, tone: 'text-slate-500' }
}

const getBatchLotSuffix = (item, batch) => {
  const code = String(batch?.batch_code || '').trim()
  const prefix = String(item?.barcode || '').trim()
  if (prefix && code.toLowerCase().startsWith(`${prefix.toLowerCase()}-`)) return code.slice(prefix.length + 1)
  return code
}

const getBatchStatusMeta = (batch) => {
  if (batch?.archived_at) return { label: 'Archived', tone: 'bg-slate-100 text-slate-600 border-slate-200' }
  const qty = Number(batch?.quantity || 0)
  if (qty <= 0) return { label: 'Depleted', tone: 'bg-slate-50 text-slate-500 border-slate-200' }
  const expiry = batch?.expiration_date ? parseDateOnly(batch.expiration_date) : null
  const today = new Date(); today.setHours(0,0,0,0)
  if (expiry) { expiry.setHours(0,0,0,0); if (expiry < today) return { label: 'Expired', tone: 'bg-red-50 text-red-700 border-red-200' } }
  return { label: 'Active', tone: 'bg-emerald-50 text-emerald-700 border-emerald-200' }
}

const CameraScanner = ({ onDetected, onClose }) => {
  const videoRef = useRef(null)
  const readerRef = useRef(null)
  const controlsRef = useRef(null)
  const mountedRef = useRef(true)
  const lastCodeRef = useRef({ code: '', at: 0 })
  const [status, setStatus] = useState('starting')
  const [errorMsg, setErrorMsg] = useState('')
  const [devices, setDevices] = useState([])
  const [selectedDeviceId, setSelectedDeviceId] = useState('')
  const [manualCode, setManualCode] = useState('')
  const [torchOn, setTorchOn] = useState(false)
  const [retryKey, setRetryKey] = useState(0)

  const stopScanner = useCallback(() => {
    controlsRef.current?.stop?.()
    controlsRef.current = null
    readerRef.current?.reset?.()
    if (videoRef.current) videoRef.current.srcObject = null
  }, [])

  const emitCode = useCallback((rawCode) => {
    const code = String(rawCode || '').trim()
    if (!code) return
    const now = Date.now()
    if (lastCodeRef.current.code === code && now - lastCodeRef.current.at < 1800) return
    lastCodeRef.current = { code, at: now }
    setStatus('detected')
    stopScanner()
    window.setTimeout(() => onDetected(code), 180)
  }, [onDetected, stopScanner])

  useEffect(() => {
    mountedRef.current = true
    let permissionStream = null

    const init = async () => {
      setStatus('starting')
      setErrorMsg('')
      setTorchOn(false)

      if (!navigator.mediaDevices?.getUserMedia) {
        setStatus('error')
        setErrorMsg('Camera access is unavailable. Use HTTPS on a phone, or enter the barcode manually.')
        return
      }

      try {
        // Ask for permission first so mobile browsers expose camera labels and rear cameras.
        permissionStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false })
        permissionStream.getTracks().forEach((track) => track.stop())
        permissionStream = null

        const availableDevices = await BrowserMultiFormatReader.listVideoInputDevices().catch(() => [])
        if (!mountedRef.current) return
        setDevices(availableDevices)

        const preferred = selectedDeviceId
          || availableDevices.find((device) => /back|rear|environment/i.test(device.label))?.deviceId
          || availableDevices[0]?.deviceId
          || ''
        if (!selectedDeviceId && preferred) setSelectedDeviceId(preferred)

        readerRef.current = new BrowserMultiFormatReader()
        controlsRef.current = await readerRef.current.decodeFromConstraints(
          {
            video: preferred
              ? { deviceId: { exact: preferred }, width: { ideal: 1920 }, height: { ideal: 1080 } }
              : { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } },
          },
          videoRef.current,
          (result) => {
            if (!mountedRef.current || !result) return
            emitCode(result.getText())
          }
        )
        if (mountedRef.current) setStatus('scanning')
      } catch (err) {
        if (!mountedRef.current) return
        setStatus('error')
        const message = err?.name === 'NotAllowedError'
          ? 'Camera permission was denied. Allow camera access in your browser settings, then retry.'
          : err?.name === 'NotFoundError'
            ? 'No camera was found. Enter the barcode manually or upload a barcode image.'
            : err?.name === 'OverconstrainedError'
              ? 'The selected camera is unavailable. Switch cameras and retry.'
              : err?.message || 'The scanner could not start.'
        setErrorMsg(message)
      }
    }

    stopScanner()
    init()
    return () => {
      mountedRef.current = false
      permissionStream?.getTracks?.().forEach((track) => track.stop())
      stopScanner()
    }
  }, [emitCode, retryKey, selectedDeviceId, stopScanner])

  const switchCamera = () => {
    if (devices.length < 2) return
    const currentIndex = devices.findIndex((device) => device.deviceId === selectedDeviceId)
    const next = devices[(currentIndex + 1) % devices.length]
    if (next?.deviceId) setSelectedDeviceId(next.deviceId)
  }

  const toggleTorch = async () => {
    try {
      if (controlsRef.current?.switchTorch) {
        await controlsRef.current.switchTorch()
        setTorchOn((current) => !current)
        return
      }
      const track = videoRef.current?.srcObject?.getVideoTracks?.()[0]
      const capabilities = track?.getCapabilities?.()
      if (!capabilities?.torch) throw new Error('Torch is not supported by this camera.')
      const next = !torchOn
      await track.applyConstraints({ advanced: [{ torch: next }] })
      setTorchOn(next)
    } catch (error) {
      setErrorMsg(error.message || 'Torch control is unavailable.')
    }
  }

  const scanImage = async (event) => {
    const file = event.target.files?.[0]
    if (!file) return
    const objectUrl = URL.createObjectURL(file)
    setStatus('starting')
    try {
      const reader = readerRef.current || new BrowserMultiFormatReader()
      const result = await reader.decodeFromImageUrl(objectUrl)
      emitCode(result?.getText())
    } catch {
      setStatus('error')
      setErrorMsg('No readable barcode was found in that image.')
    } finally {
      URL.revokeObjectURL(objectUrl)
      event.target.value = ''
    }
  }

  const statusConfig = {
    starting: { color: '#64748b', text: 'Starting camera...', pulse: false },
    scanning: { color: '#0ea5e9', text: 'Scanning — hold the barcode steady', pulse: true },
    detected: { color: '#22c55e', text: 'Barcode detected', pulse: false },
    error: { color: '#ef4444', text: errorMsg, pulse: false },
  }
  const cfg = statusConfig[status]

  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-black/80 sm:items-center sm:px-4">
      <div className="flex h-[100dvh] w-full flex-col overflow-hidden bg-white shadow-2xl sm:h-auto sm:max-h-[94vh] sm:max-w-lg sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <div>
            <p className="flex items-center gap-2 text-sm font-bold text-slate-800"><MdCameraAlt className="text-sky-500" /> Camera Barcode Scanner</p>
            <p className="text-xs text-slate-400">Rear camera is preferred on supported phones</p>
          </div>
          <button type="button" onClick={onClose} className="icon-button" aria-label="Close barcode scanner"><MdClose /></button>
        </div>

        <div className="relative min-h-[42vh] flex-1 overflow-hidden bg-black sm:aspect-[4/3] sm:min-h-0 sm:flex-none">
          {status === 'error' ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 px-8 text-center text-sm text-slate-200">
              <MdWarningAmber className="text-3xl text-amber-400" />
              <p>{errorMsg}</p>
              <button type="button" className="rounded-xl bg-white px-4 py-2 text-xs font-bold text-slate-800" onClick={() => setRetryKey((current) => current + 1)}>Retry Camera</button>
            </div>
          ) : (
            <>
              <video ref={videoRef} className="h-full w-full object-cover" muted playsInline autoPlay />
              <div className="pointer-events-none absolute inset-[12%] rounded-2xl border-2 border-sky-400 shadow-[0_0_0_999px_rgba(0,0,0,0.35)]" />
              {status === 'scanning' && <div className="absolute left-[14%] right-[14%] top-1/2 h-0.5 animate-pulse bg-sky-400 shadow-[0_0_8px_#38bdf8]" />}
              {status === 'starting' && <div className="absolute inset-0 flex items-center justify-center bg-black/40"><span className="loading-spinner" /></div>}
              {status === 'detected' && <div className="absolute inset-0 flex items-center justify-center bg-emerald-500/25"><MdCheckCircle className="text-6xl text-white drop-shadow" /></div>}
            </>
          )}
        </div>

        <div className="space-y-4 overflow-y-auto p-5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex min-w-0 items-center gap-2 text-xs text-slate-500">
              <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: cfg.color }} />
              <span className="truncate">{cfg.text}</span>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={switchCamera} disabled={devices.length < 2} className="icon-button border border-slate-200" aria-label="Switch camera"><MdCameraswitch /></button>
              <button type="button" onClick={toggleTorch} disabled={status !== 'scanning'} className={`icon-button border border-slate-200 ${torchOn ? 'bg-amber-50 text-amber-600' : ''}`} aria-label="Toggle camera torch"><MdFlashOn /></button>
            </div>
          </div>

          {devices.length > 1 && (
            <div>
              <label htmlFor="scanner-camera" className="form-label">Camera</label>
              <select id="scanner-camera" value={selectedDeviceId} onChange={(event) => setSelectedDeviceId(event.target.value)} className="form-control mt-1.5">
                {devices.map((device, index) => <option key={device.deviceId} value={device.deviceId}>{device.label || `Camera ${index + 1}`}</option>)}
              </select>
            </div>
          )}

          <div>
            <label htmlFor="manual-barcode" className="form-label">Manual Barcode</label>
            <div className="mt-1.5 flex gap-2">
              <input id="manual-barcode" value={manualCode} onChange={(event) => setManualCode(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && emitCode(manualCode)} placeholder="Type or paste barcode" className="form-control" />
              <button type="button" className="button-primary shrink-0" disabled={!manualCode.trim()} onClick={() => emitCode(manualCode)}>Use Code</button>
            </div>
          </div>

          <label className="button-secondary w-full cursor-pointer">
            <MdUploadFile /> Scan Barcode Image
            <input type="file" accept="image/*" capture="environment" onChange={scanImage} className="sr-only" />
          </label>

          <p className="text-[11px] leading-relaxed text-slate-400">
            Phone camera access requires HTTPS or localhost. On a local network, open the app through an HTTPS development URL.
          </p>
        </div>
      </div>
    </div>
  )
}

const ItemFormModal = ({ title, initialItem, initialBarcode = '', onClose, onSubmit, canManageSellingPrice = false, masterData = {}, existingItems = [] }) => {
  const isEditing = Boolean(initialItem?.id)
  const [supplierChoice, setSupplierChoice] = useState(initialItem?.supplier_id ? String(initialItem.supplier_id) : '')
  const [barcodeScannerOpen, setBarcodeScannerOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [noExpiry, setNoExpiry] = useState(false)
  const [form, setForm] = useState({
    barcode: initialItem?.barcode || initialBarcode || '',
    name: initialItem?.name || '',
    category: ['medical','derma'].includes(initialItem?.category) ? initialItem.category : (String(initialItem?.category || '').toLowerCase().includes('derm') ? 'derma' : 'medical'),
    item_type: initialItem?.item_type || 'medicine',
    uom: 'unit',
    measurement_value: initialItem?.measurement_value === null || initialItem?.measurement_value === undefined ? '' : String(initialItem.measurement_value),
    measurement_unit: initialItem?.measurement_unit || '',
    strength: initialItem?.measurement_value ? '' : (initialItem?.strength || ''),
    stock: String(isEditing ? 0 : (initialItem?.stock ?? 0)),
    threshold: String(initialItem?.threshold ?? 5),
    price: String(initialItem?.selling_price ?? initialItem?.price ?? ''),
    selling_price: initialItem?.selling_price === null || initialItem?.selling_price === undefined ? '' : String(initialItem.selling_price),
    expiration_date: '',
    location_type_id: initialItem?.location_type_id ? String(initialItem.location_type_id) : '',
  })

  const categorySuppliers = (masterData.suppliers || []).filter((entry) => supplierSupportsClinic(entry, form.category))
  const locationTypes = (masterData.location_types || []).filter((entry) => Number(entry.is_active ?? 1) === 1)
  const quantityStep = 1
  const update = (key) => (e) => setForm(prev => ({ ...prev, [key]: e.target.value }))
  const normalizedBarcode = String(form.barcode || '').trim()
  const duplicateBarcode = normalizedBarcode
    ? existingItems.find((item) => Number(item.id) !== Number(initialItem?.id) && String(item.barcode || '').trim().toLowerCase() === normalizedBarcode.toLowerCase())
    : null
  const generatedItemPreview = getNextGeneratedItemCode(form.category, existingItems)
  const barcodePreview = normalizedBarcode || generatedItemPreview
  const sellingPrice = Number(form.selling_price)
  const thresholdValid = form.threshold !== '' && Number.isFinite(Number(form.threshold)) && Number(form.threshold) >= 0 && Number.isInteger(Number(form.threshold))
  const sellingPriceValid = Number.isFinite(sellingPrice) && sellingPrice > 0
  const openingQuantity = Math.max(0, Number(form.stock) || 0)
  const openingQuantityValid = isEditing || (form.stock !== '' && Number.isFinite(Number(form.stock)) && Number(form.stock) >= 0 && Number.isInteger(Number(form.stock)))
  const openingExpiryValid = isEditing || openingQuantity <= 0 || Boolean(noExpiry || form.expiration_date)
  const canSaveDetails = Boolean(
    form.name.trim()
    && form.category
    && form.item_type
    && form.location_type_id
    && supplierChoice
    && thresholdValid
    && (!canManageSellingPrice || sellingPriceValid)
    && openingQuantityValid
    && openingExpiryValid
    && !duplicateBarcode
  )

  const handleScannedBarcode = (code) => {
    const normalized = String(code || '').trim()
    setBarcodeScannerOpen(false)
    if (normalized) setForm((current) => ({ ...current, barcode: normalized }))
  }

  const handleSubmit = async () => {
    if (!canSaveDetails || submitting) return
    const supplierId = supplierChoice ? Number(supplierChoice) : null
    const supplierName = categorySuppliers.find((x) => Number(x.id) === supplierId)?.name || ''
    const previousSellingPrice = Number(initialItem?.selling_price || 0)
    const sellingPriceChanged = Boolean(
      isEditing
      && canManageSellingPrice
      && sellingPriceValid
      && Math.abs(sellingPrice - previousSellingPrice) > 0.0001
    )
    if (sellingPriceChanged) {
      const linkedCount = Number(initialItem?.linked_service_count || 0)
      const linkedNames = String(initialItem?.linked_service_names || '').split('||').map((name) => name.trim()).filter(Boolean)
      const serviceText = linkedCount > 0
        ? `This item is currently used by ${linkedCount} service${linkedCount === 1 ? '' : 's'}${linkedNames.length ? `: ${linkedNames.join(', ')}` : ''}.\n\n`
        : ''
      const confirmed = window.confirm(
        `Changing this Selling Price affects linked service totals.\n\n${serviceText}`
        + `Price change: PHP ${previousSellingPrice.toFixed(2)} → PHP ${sellingPrice.toFixed(2)}.\n\n`
        + 'Every linked service will be recalculated automatically using the new consumable price. Historical bills and existing billing snapshots will not be changed.\n\nContinue with this price change?'
      )
      if (!confirmed) return
    }
    setSubmitting(true)
    try {
      const payload = {
        ...form,
        batch_code: '',
        batch_lot_code: '',
        supplier_lot_number: '',
        supplier_lot_missing: true,
        no_expiry: noExpiry,
        supplier_id: supplierId,
        supplier: supplierName,
        uom: 'unit',
        unit: 'unit',
        base_unit: 'unit',
        unit_size: 1,
        // Legacy strength fields are preserved for existing records, but are no longer edited in the simplified UI.
        measurement_value: form.measurement_value === '' ? null : Number(form.measurement_value),
        measurement_unit: String(form.measurement_unit || '').trim() || null,
        strength: String(form.strength || '').trim() || null,
        ...(isEditing ? {} : { stock: openingQuantity }),
        threshold: Math.max(0, parseFloat(form.threshold) || 0),
      }
      // Editing master data never sends stock; only the batch-based Stock In /
      // Stock Out workflow can change quantities.
      if (canManageSellingPrice) {
        payload.price = sellingPrice
        payload.selling_price = sellingPrice
      } else {
        delete payload.price
        delete payload.selling_price
      }
      await onSubmit(payload)
      onClose()
    } finally {
      setSubmitting(false)
    }
  }

  return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 px-4">
    <div className="w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-2xl">
      <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
        <div>
          <p className="text-base font-bold text-slate-900">{title}</p>
          <p className="mt-0.5 text-sm text-slate-500">{isEditing ? 'Edit product-level details only. Batch quantity and expiry are managed in Manage Batches.' : 'Create the inventory item and opening stock. The first batch is generated automatically.'}</p>
        </div>
        <button onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100" aria-label="Close"><MdClose/></button>
      </div>

      <div className="max-h-[72vh] overflow-y-auto p-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="md:col-span-2"><Field label="Item Name *"><input maxLength={150} value={form.name} onChange={update('name')} className={inputClass} placeholder={form.item_type==='medicine'?'e.g. Amoxicillin 500mg':'e.g. Sterile Gauze Pad'}/></Field></div>
          <Field label="Category *"><select value={form.category} onChange={(e)=>{setForm(p=>({...p,category:e.target.value}));setSupplierChoice('')}} className={inputClass}>{CATEGORIES.map(x=><option key={x.value} value={x.value}>{x.label}</option>)}</select></Field>
          <Field label="Type *"><select value={form.item_type} onChange={(e)=>{const value=e.target.value;setForm((p)=>({...p,item_type:value}));if(value==='medicine')setNoExpiry(false)}} className={inputClass}>{ITEM_TYPES.map(x=><option key={x.value} value={x.value}>{x.label}</option>)}</select></Field>
          <div className="md:col-span-2">
            <Field label="Product Barcode"><div className="flex flex-col gap-2 sm:flex-row">
              <input maxLength={50} value={form.barcode} onChange={update('barcode')} className={`${inputClass} flex-1`} placeholder={`Leave blank to auto-generate ${form.category==='derma'?'DRM':'GMED'} code`} />
              <button type="button" onClick={() => setBarcodeScannerOpen(true)} className="button-secondary shrink-0"><MdQrCodeScanner /> Scan Barcode</button>
            </div></Field>
            {duplicateBarcode ? <div className="mt-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">This barcode is already registered to <strong>{duplicateBarcode.name}</strong>. Use the existing inventory item instead.</div> : <p className="mt-2 text-xs text-slate-400">The product barcode identifies the product. Batch barcodes are generated automatically for each receipt.</p>}
            <div className="mt-3"><BarcodePreview value={barcodePreview} title={normalizedBarcode ? 'Product Barcode Preview' : 'Auto-generated Barcode Preview'} /></div>
          </div>
          <Field label="Storage Location *"><select value={form.location_type_id} onChange={update('location_type_id')} className={inputClass} disabled={!locationTypes.length}><option value="">{locationTypes.length ? 'Select storage location' : 'No storage locations configured'}</option>{locationTypes.map((entry)=><option key={entry.id} value={entry.id}>{entry.name}</option>)}</select></Field>
          <Field label="Supplier *"><select value={supplierChoice} onChange={(e)=>setSupplierChoice(e.target.value)} className={`${inputClass} ${!supplierChoice ? 'border-amber-300 bg-amber-50' : ''}`} disabled={!categorySuppliers.length}><option value="">{categorySuppliers.length ? 'Select supplier' : 'No suppliers configured for this category'}</option>{categorySuppliers.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select>{!supplierChoice && categorySuppliers.length > 0 && <p className="mt-1 text-xs font-semibold text-amber-700">Select a supplier.</p>}</Field>
          {!isEditing && <Field label="Opening Quantity *"><input type="number" inputMode="numeric" min="0" step={quantityStep} value={form.stock} onChange={update('stock')} className={`${inputClass} ${!openingQuantityValid ? 'border-amber-300 bg-amber-50' : ''}`}/>{!openingQuantityValid && <p className="mt-1 text-xs font-semibold text-amber-700">Enter a whole-number opening quantity of 0 or greater.</p>}</Field>}
          {!isEditing && openingQuantity > 0 && <div><Field label={`Opening Batch Expiry${form.item_type === 'medicine' ? ' *' : ''}`}><input type="date" value={form.expiration_date} onChange={update('expiration_date')} disabled={noExpiry} className={`${inputClass} ${!openingExpiryValid ? 'border-amber-300 bg-amber-50' : ''}`}/></Field>{form.item_type === 'supplies' && <label className="mt-2 flex items-center gap-2 text-xs font-semibold text-slate-600"><input type="checkbox" checked={noExpiry} onChange={(e)=>{setNoExpiry(e.target.checked);if(e.target.checked)setForm((v)=>({...v,expiration_date:''}))}}/> No expiry / Not applicable</label>}{!openingExpiryValid && <p className="mt-1 text-xs font-semibold text-amber-700">{form.item_type === 'medicine' ? 'Expiry is required for medicines with opening stock.' : 'Enter an expiry date or choose No expiry / Not applicable.'}</p>}</div>}
          <Field label="Low Stock Alert *"><input type="number" inputMode="numeric" min="0" step={quantityStep} value={form.threshold} onChange={update('threshold')} className={`${inputClass} ${!thresholdValid ? 'border-amber-300 bg-amber-50' : ''}`}/>{!thresholdValid && <p className="mt-1 text-xs font-semibold text-amber-700">Enter a whole-number low-stock alert quantity of 0 or greater.</p>}</Field>
          {canManageSellingPrice ? <Field label="Selling Price *"><input type="number" inputMode="decimal" min="0.01" step="0.01" value={form.selling_price} onChange={update('selling_price')} className={`${inputClass} ${!sellingPriceValid ? 'border-red-300 bg-red-50' : ''}`} placeholder="e.g. 10.00"/>{!sellingPriceValid ? <p className="mt-1 text-xs font-semibold text-red-700">Selling Price is required and must be greater than ₱0.00.</p> : <p className="mt-1 text-xs text-slate-400">Admin-only pricing. Changing this value recalculates every linked service total.</p>}</Field> : <Field label="Selling Price"><input readOnly value={Number(initialItem?.selling_price || 0) > 0 ? `PHP ${Number(initialItem.selling_price).toFixed(2)}` : 'Not set'} className={`${inputClass} bg-slate-100 text-slate-500`} /><p className="mt-1 text-xs text-slate-400">Only Admin can change inventory pricing.</p></Field>}
        </div>
      </div>

      <div className="flex gap-3 border-t border-slate-100 px-6 py-5">
        <button onClick={onClose} disabled={submitting} className="flex-1 rounded-2xl border border-slate-200 py-3 text-sm font-semibold text-slate-600 disabled:opacity-50">Cancel</button>
        <button onClick={handleSubmit} disabled={!canSaveDetails || submitting} className="flex-1 rounded-2xl bg-[#0b1a2c] py-3 text-sm font-semibold text-white disabled:opacity-50"><MdSave className="inline mr-2"/>{submitting ? (isEditing ? 'Saving…' : 'Adding…') : (isEditing ? 'Save Item Details' : 'Add Item')}</button>
      </div>
    </div>
    {barcodeScannerOpen && <CameraScanner onDetected={handleScannedBarcode} onClose={()=>setBarcodeScannerOpen(false)} />}
  </div>
}

const StockModal = ({ item, initialType = 'in', onClose, onSubmit, movementReasons = [], suppliers = [] }) => {
  const type = initialType === 'out' ? 'out' : 'in'
  const [qty, setQty] = useState(type === 'in' ? '1' : '')
  const [note, setNote] = useState('')
  const [expirationDate, setExpirationDate] = useState('')
  const [supplierId, setSupplierId] = useState(item?.supplier_id ? String(item.supplier_id) : '')
  const [noExpiry, setNoExpiry] = useState(false)
  const [movementReason, setMovementReason] = useState(type === 'in' ? 'received' : 'adjustment_out')
  const [stockOutSelectionKey, setStockOutSelectionKey] = useState('')
  const [busy, setBusy] = useState(false)
  const configuredStockInReasons = (Array.isArray(movementReasons) ? movementReasons : []).filter((reason) => reason.movement_type === 'in').map((reason) => ({ value: reason.code, label: reason.name, ...reason }))
  const configuredStockOutReasons = (Array.isArray(movementReasons) ? movementReasons : []).filter((reason) => reason.movement_type === 'out').map((reason) => ({ value: reason.code, label: reason.name, ...reason }))
  const stockInReasons = configuredStockInReasons.length ? configuredStockInReasons : DEFAULT_STOCK_IN_REASONS
  const stockOutReasons = configuredStockOutReasons.length ? configuredStockOutReasons : DEFAULT_STOCK_OUT_REASONS
  const reasons = type === 'in' ? stockInReasons : stockOutReasons
  const batches = (Array.isArray(item?.batches) ? item.batches : []).filter((batch) => !batch.archived_at)
  const stockOutOptions = useMemo(() => batches.flatMap((batch) => {
    const locations = (Array.isArray(batch?.locations) ? batch.locations : []).filter((location) => Number(location?.quantity || 0) > 0)
    if (locations.length) return locations.map((location) => ({ key: `${batch.id}:${location.id || location.name}`, batch, location, available: Number(location.quantity || 0) }))
    if (Number(batch.quantity || 0) <= 0) return []
    return [{ key: `${batch.id}:default`, batch, location: { id: null, name: 'Main Stockroom', quantity: Number(batch.quantity || 0) }, available: Number(batch.quantity || 0) }]
  }), [batches])
  const selectedStockOut = stockOutOptions.find((option) => option.key === stockOutSelectionKey) || null
  const selectedStockOutBatch = selectedStockOut?.batch || null
  const selectedStockOutAvailable = Number(selectedStockOut?.available || 0)
  const numericQty = Math.max(0, Number(qty) || 0)
  const clinicStock = Number(item?.stock ?? 0)
  const internalBatchPreview = getNextBatchCodePreview(item)
  const receiptSuppliers = (Array.isArray(suppliers) ? suppliers : []).filter((supplier)=>supplierSupportsClinic(supplier,item.category))
  const qtyStep = 1

  useEffect(() => {
    if (!reasons.some((reason) => reason.value === movementReason)) setMovementReason(reasons[0]?.value || '')
  }, [movementReason, reasons])

  const stockInInvalid = type === 'in' && (numericQty <= 0 || !Number.isInteger(numericQty) || !movementReason || !supplierId || (!noExpiry && !expirationDate) || (item?.item_type === 'medicine' && !expirationDate))
  const stockOutInvalid = type === 'out' && (!movementReason || !selectedStockOut || numericQty <= 0 || !Number.isInteger(numericQty) || numericQty > selectedStockOutAvailable)

  const handleSave = async () => {
    if (busy) return
    setBusy(true)
    try {
      await onSubmit(type === 'in' ? {
        type: 'in',
        qty: numericQty,
        note: note.trim(),
        movement_reason: movementReason,
        expiration_date: noExpiry ? '' : expirationDate,
        no_expiry: noExpiry,
        supplier_id: Number(supplierId),
        batch_code: '',
        supplier_lot_number: '',
        supplier_lot_missing: true,
        existing_batch_id: null,
      } : {
        type: 'out',
        qty: numericQty,
        batch_id: Number(selectedStockOutBatch?.id),
        storage_location_id: selectedStockOut?.location?.id ? Number(selectedStockOut.location.id) : null,
        movement_reason: movementReason,
        note: note.trim(),
      })
    } finally {
      setBusy(false)
    }
  }

  return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 px-4">
    <div className="flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
      <div className="flex shrink-0 items-center justify-between border-b border-slate-100 px-6 py-4">
        <div><p className="text-base font-bold text-slate-900">{type === 'in' ? 'Stock In' : 'Stock Out'} · {item.name}</p><p className="mt-0.5 text-xs text-slate-500">Clinic-wide stock: {formatUnits(clinicStock)}</p></div>
        <button onClick={onClose} disabled={busy} className="flex h-8 w-8 disabled:opacity-50 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100" aria-label="Close"><MdClose /></button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6"><div className="space-y-4">
        {type === 'in' ? <>
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50 px-4 py-3 text-sm text-emerald-800"><strong>Every Stock In creates a new batch automatically.</strong> Each receipt gets its own internal batch barcode and keeps its expiry and quantity separate.</div>
          <Field label={`Quantity Received (units) *`}><input type="number" inputMode="numeric" min={qtyStep} step={qtyStep} value={qty} onChange={(e) => setQty(e.target.value)} className={inputClass}/></Field>
          <Field label="Movement Reason *"><select value={movementReason} onChange={(e)=>setMovementReason(e.target.value)} className={inputClass}>{stockInReasons.map((reason)=><option key={reason.value} value={reason.value}>{reason.label}</option>)}</select></Field><Field label="Supplier for this receipt *"><select value={supplierId} onChange={(e)=>setSupplierId(e.target.value)} className={inputClass}><option value="">Select supplier</option>{receiptSuppliers.map((supplier)=><option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select><p className="mt-1 text-xs text-slate-400">Defaults to the item's Supplier, but each receipt can record the actual supplier used.</p></Field>
          <div><Field label={`Batch Expiry${item?.item_type === 'medicine' ? ' *' : ''}`}><input type="date" value={expirationDate} onChange={(e)=>setExpirationDate(e.target.value)} disabled={noExpiry} className={`${inputClass} ${!noExpiry && !expirationDate ? 'border-amber-300 bg-amber-50' : ''}`}/></Field>{item?.item_type === 'supplies' && <label className="mt-2 flex items-center gap-2 text-xs font-semibold text-slate-600"><input type="checkbox" checked={noExpiry} onChange={(e)=>{setNoExpiry(e.target.checked);if(e.target.checked)setExpirationDate('')}}/> No expiry / Not applicable</label>}{!noExpiry && !expirationDate && <p className="mt-1 text-xs font-semibold text-amber-700">{item?.item_type === 'medicine' ? 'Expiry is required for medicines.' : 'Enter an expiry date or choose No expiry / Not applicable.'}</p>}</div>
          <div className="rounded-2xl border border-sky-100 bg-sky-50 px-4 py-3 text-sm text-sky-800"><span className="font-semibold">Selling Price:</span> PHP {Number(item?.selling_price || 0).toFixed(2)} <span className="text-xs text-sky-600">(managed in Edit Item)</span></div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4"><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Internal Batch Barcode</p><div className="mt-2"><BarcodePreview value={internalBatchPreview} title="New Batch" compact/></div><p className="mt-2 text-xs text-slate-500">This internal batch barcode is generated automatically and is unique to this receipt.</p></div>
          <Field label="Reference / Delivery Note"><input maxLength={255} value={note} onChange={(e)=>setNote(e.target.value)} className={inputClass} placeholder="e.g. Delivery receipt DR-1024"/></Field>
          <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm"><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">After Stock In</p><div className="mt-2 flex justify-between"><span>Current clinic stock</span><strong>{formatUnits(clinicStock)}</strong></div><div className="mt-1 flex justify-between text-emerald-700"><span>Receiving</span><strong>+{formatUnits(numericQty)}</strong></div><div className="mt-2 border-t border-slate-100 pt-2 flex justify-between"><span>New clinic stock</span><strong>{formatUnits(clinicStock + numericQty)}</strong></div></div>
        </> : <>
          {!stockOutOptions.length ? <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4 text-sm text-amber-800">There is no available batch stock to remove.</div> : <>
            <Field label="Stock Out From Batch / Location *"><select value={stockOutSelectionKey} onChange={(e)=>{setStockOutSelectionKey(e.target.value);setQty('')}} className={inputClass}><option value="">Select batch and location</option>{stockOutOptions.map((option)=>{const batch=option.batch;const supplierLot=batch.supplier_lot_number?` · Lot ${batch.supplier_lot_number}`:'';return <option key={option.key} value={option.key}>{batch.batch_code || `Batch #${batch.id}`}{supplierLot} · {option.location?.name || 'Main Stockroom'} · {formatUnits(option.available)}</option>})}</select></Field>
            {selectedStockOutBatch && <div className="rounded-2xl border border-sky-200 bg-sky-50 p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] font-black uppercase tracking-widest text-sky-700">Selected Batch</p><p className="mt-1 font-mono text-sm font-bold text-slate-900">{selectedStockOutBatch.batch_code}</p>{selectedStockOutBatch.supplier_lot_number&&<p className="mt-1 text-xs text-slate-500">Supplier Lot: {selectedStockOutBatch.supplier_lot_number}</p>}</div><span className="rounded-full bg-white px-2.5 py-1 text-xs font-bold text-sky-700">{formatUnits(selectedStockOutAvailable)} available here</span></div><div className="mt-3 grid grid-cols-2 gap-3 text-sm"><div><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Expiry</p><p className="mt-1 font-semibold text-slate-700">{selectedStockOutBatch.expiration_date?formatDate(selectedStockOutBatch.expiration_date):'No expiry'}</p></div><div><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Location</p><p className="mt-1 font-semibold text-slate-700">{selectedStockOut?.location?.name || 'Main Stockroom'}</p></div></div></div>}
            <Field label={`Quantity to Stock Out (units) *`}><input type="number" inputMode="numeric" min={qtyStep} max={selectedStockOutAvailable||undefined} step={qtyStep} value={qty} onChange={(e)=>setQty(e.target.value)} className={inputClass} disabled={!selectedStockOut}/></Field>
            <Field label="Movement Reason *"><select value={movementReason} onChange={(e)=>setMovementReason(e.target.value)} className={inputClass}>{stockOutReasons.map((reason)=><option key={reason.value} value={reason.value}>{reason.label}</option>)}</select></Field>
            <Field label="Note"><input maxLength={255} value={note} onChange={(e)=>setNote(e.target.value)} className={inputClass} placeholder="Optional explanation or reference"/></Field>
            {selectedStockOut && <div className={`rounded-2xl border p-4 text-sm ${numericQty>selectedStockOutAvailable?'border-red-200 bg-red-50':'border-slate-200 bg-slate-50'}`}><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">After Stock Out</p><div className="mt-2 flex justify-between"><span>Location available</span><strong>{formatUnits(selectedStockOutAvailable)}</strong></div><div className="mt-1 flex justify-between text-red-600"><span>Stocking out</span><strong>-{formatUnits(numericQty)}</strong></div><div className="mt-2 border-t border-slate-200 pt-2 flex justify-between"><span>Location remaining</span><strong>{formatUnits(Math.max(0,selectedStockOutAvailable-numericQty))}</strong></div><div className="mt-1 flex justify-between"><span>Clinic remaining</span><strong>{formatUnits(Math.max(0,clinicStock-numericQty))}</strong></div>{numericQty>selectedStockOutAvailable&&<p className="mt-2 text-xs font-bold text-red-600">Quantity exceeds the selected batch/location balance.</p>}</div>}
          </>}
        </>}
      </div></div>

      <div className="shrink-0 border-t border-slate-100 bg-white px-6 pb-6 pt-4"><button onClick={handleSave} disabled={busy || stockInInvalid || stockOutInvalid || (type==='out'&&!stockOutOptions.length)} className={`w-full rounded-2xl py-3 text-sm font-bold text-white disabled:opacity-40 ${type==='in'?'bg-emerald-600 hover:bg-emerald-700':'bg-red-600 hover:bg-red-700'}`}>{busy ? 'Saving…' : type==='in'?`Receive ${numericQty || ''} unit${Number(numericQty) === 1 ? '' : 's'}`:`Stock Out ${numericQty || ''} unit${Number(numericQty) === 1 ? '' : 's'}`}</button></div>
    </div>
  </div>
}

const Field = ({ label, children }) => (
  <label className="space-y-1.5">
    <span className="text-xs font-bold uppercase tracking-widest text-slate-400">{label}</span>
    {children}
  </label>
)

const inputClass = 'w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none focus:border-sky-400'

const ProtectedBatchActionModal = ({ item, batch, action, onClose, onRequest, onConfirm, onSuccess }) => {
  const [reason,setReason]=useState('')
  const [password,setPassword]=useState('')
  const [code,setCode]=useState('')
  const [step,setStep]=useState('details')
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  const [targetQuantity,setTargetQuantity]=useState(String(Number(batch?.quantity || 0)))
  const [lotCode,setLotCode]=useState(getBatchLotSuffix(item,batch))
  const [expiry,setExpiry]=useState(batch?.expiration_date ? String(batch.expiration_date).slice(0,10) : '')
  const [note,setNote]=useState(batch?.note || '')
  const [supplierLot,setSupplierLot]=useState(batch?.supplier_lot_number || '')
  const labels={correct_quantity:'Correct Quantity',correct_details:'Edit Batch',archive:'Archive Batch',restore:'Restore Batch',delete:'Delete Batch'}
  const submitRequest=async()=>{
    if(reason.trim().length<5 || !password) return setError('Enter a reason (at least 5 characters) and your Admin password.')
    setBusy(true);setError('')
    try{
      const payload={action,password,reason:reason.trim()}
      if(action==='correct_quantity') payload.target_quantity=Math.max(0,Number(targetQuantity)||0)
      if(action==='correct_details') Object.assign(payload,{batch_lot_code:lotCode.trim(),supplier_lot_number:supplierLot.trim(),expiration_date:expiry,note:note.trim()})
      await onRequest(batch.id,payload);setStep('code')
    }catch(err){setError(err.message||'Could not send verification code.')}finally{setBusy(false)}
  }
  const confirm=async()=>{
    if(code.length!==6)return
    setBusy(true);setError('')
    try{const result=await onConfirm(batch.id,code);onSuccess(result?.message||'Batch updated.')}catch(err){setError(err.message||'Could not complete the batch action.')}finally{setBusy(false)}
  }
  return <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 px-4"><div className="w-full max-w-lg rounded-3xl bg-white shadow-2xl overflow-hidden">
    <div className="flex items-start justify-between border-b border-slate-100 px-6 py-4"><div><h3 className="font-bold text-slate-900">{labels[action]||'Batch Action'}</h3><p className="mt-1 text-xs text-slate-500">{item.name} · {batch.batch_code||`Batch #${batch.id}`}</p></div><button onClick={onClose} disabled={busy}><MdClose/></button></div>
    <div className="max-h-[70vh] overflow-y-auto p-6 space-y-4">
      {step==='details'?<>
        {action==='correct_quantity'&&<><div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm"><span className="text-slate-500">Current Quantity</span><p className="mt-1 text-xl font-black text-slate-900">{formatUnits(batch.quantity)}</p></div><Field label="Correct Quantity *"><input type="number" min="0" step="1" value={targetQuantity} onChange={e=>setTargetQuantity(e.target.value)} className={inputClass}/><p className="mt-1 text-xs text-slate-400">The system records only the difference as Inventory Correction (+/-); it never rewrites history silently.</p></Field></>}
        {action==='correct_details'&&<><div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600"><strong>Internal batch barcode:</strong> {batch.batch_code||'—'}<br/>The internal suffix can be corrected without changing the product barcode.</div><Field label="Internal Batch Suffix *"><input value={lotCode} onChange={e=>setLotCode(e.target.value)} className={inputClass}/><p className="mt-1 text-xs text-slate-400">Final internal barcode: <strong>{item.barcode?`${item.barcode}-${lotCode}`:lotCode}</strong></p></Field><Field label="Supplier Lot Number"><input value={supplierLot} onChange={e=>setSupplierLot(e.target.value)} className={inputClass} placeholder="Optional supplier/manufacturer lot"/></Field><Field label="Batch Expiry *"><input type="date" value={expiry} onChange={e=>setExpiry(e.target.value)} className={inputClass}/></Field><Field label="Batch Note"><textarea value={note} onChange={e=>setNote(e.target.value)} rows={3} className={inputClass}/></Field></>}
        {action==='archive'&&<div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">Archiving hides this zero-stock batch from normal stock operations while preserving its history.</div>}
        {action==='restore'&&<div className="rounded-2xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-800">Restoring makes this batch visible again for future stock operations.</div>}
        {action==='delete'&&<div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">Hard delete is allowed only when the batch has zero stock and absolutely no inventory, clinical, billing, or transfer history. Otherwise the backend will require Archive instead.</div>}
        <Field label="Reason *"><textarea rows={3} value={reason} onChange={e=>setReason(e.target.value)} className={inputClass} placeholder="Explain why this correction/action is required."/></Field>
        <Field label="Admin Password *"><input type="password" value={password} onChange={e=>setPassword(e.target.value)} className={inputClass} autoComplete="current-password"/></Field>
      </>:<div className="space-y-4"><div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">Password verified. Enter the 6-digit code sent to your administrator email.</div><Field label="6-Digit Email Verification Code *"><input value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,'').slice(0,6))} inputMode="numeric" maxLength={6} className={`${inputClass} text-center text-lg font-black tracking-[.35em]`} placeholder="000000"/></Field></div>}
      {error&&<p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}
    </div>
    <div className="flex gap-2 border-t border-slate-100 p-5"><button className="button-secondary flex-1" disabled={busy} onClick={onClose}>Cancel</button>{step==='details'?<button className="button-primary flex-1" disabled={busy||reason.trim().length<5||!password} onClick={submitRequest}>{busy?'Checking...':'Verify Password & Send Code'}</button>:<button className="button-primary flex-1" disabled={busy||code.length!==6} onClick={confirm}>{busy?'Applying...':'Verify & Apply'}</button>}</div>
  </div></div>
}

// Moves an exact batch between storage locations, for example unused treatment-room
// stock back to the Main Stockroom. Clinic-wide stock does not change.
const MoveStockModal = ({ item, locations = [], onClose, onSubmit }) => {
  const sources = (Array.isArray(item?.batches) ? item.batches : [])
    .filter((batch) => !batch.archived_at && Number(batch.quantity || 0) > 0)
    .flatMap((batch) => (Array.isArray(batch.locations) ? batch.locations : [])
      .filter((location) => location.id && Number(location.quantity || 0) > 0)
      .map((location) => ({ key: `${batch.id}:${location.id}`, batch, location, available: Number(location.quantity || 0) })))
  const activeLocations = locations.filter((location) => Number(location.is_active ?? 1) === 1)
  const mainStockroom = activeLocations.find((location) => Number(location.is_main_stockroom || 0) === 1)
  const firstNonMain = sources.find((entry) => Number(entry.location.id) !== Number(mainStockroom?.id)) || sources[0]
  const [sourceKey, setSourceKey] = useState(firstNonMain?.key || '')
  const source = sources.find((entry) => entry.key === sourceKey) || null
  const destinations = activeLocations.filter((location) => Number(location.id) !== Number(source?.location?.id))
  const defaultDestination = destinations.find((location) => Number(location.is_main_stockroom || 0) === 1) || destinations[0]
  const [destinationId, setDestinationId] = useState(defaultDestination ? String(defaultDestination.id) : '')
  const [qty, setQty] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!destinations.some((location) => String(location.id) === String(destinationId))) {
      setDestinationId(defaultDestination ? String(defaultDestination.id) : '')
    }
  }, [sourceKey]) // eslint-disable-line react-hooks/exhaustive-deps

  const numericQty = Number(qty)
  const invalidQty = !(numericQty > 0) || !Number.isInteger(numericQty) || numericQty > Number(source?.available || 0)

  const submit = async () => {
    if (!source || !destinationId || invalidQty) return
    setSaving(true)
    setError('')
    try {
      await onSubmit(item, {
        batch_id: source.batch.id,
        from_location_id: Number(source.location.id),
        to_location_id: Number(destinationId),
        quantity: numericQty,
        note: note.trim() || null,
      })
    } catch (err) {
      setError(err.message || 'Could not move stock.')
      setSaving(false)
    }
  }

  return <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/55 px-4"><div className="w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl">
    <div className="flex items-start justify-between border-b border-slate-100 px-6 py-4"><div><h3 className="text-lg font-bold text-slate-900">Move Stock</h3><p className="mt-1 text-xs text-slate-500">{item.name}. Moves an exact batch between locations. Clinic-wide stock stays the same.</p></div><button onClick={onClose} aria-label="Close"><MdClose/></button></div>
    <div className="space-y-4 p-6">
      {sources.length === 0 ? <p className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">This item has no batch stock assigned to a location.</p> : <>
        <Field label="From Batch / Location *"><select value={sourceKey} onChange={(e)=>{setSourceKey(e.target.value);setQty('')}} className={inputClass}>{sources.map((entry)=><option key={entry.key} value={entry.key}>{entry.location.name}: {entry.batch.batch_code || `Batch #${entry.batch.id}`}, {entry.batch.expiration_date ? `exp ${formatDate(entry.batch.expiration_date)}` : 'no expiry'} ({formatUnits(entry.available)} available)</option>)}</select></Field>
        <Field label="To Location *"><select value={destinationId} onChange={(e)=>setDestinationId(e.target.value)} className={inputClass}>{destinations.length===0&&<option value="">No other active location</option>}{destinations.map((location)=><option key={location.id} value={location.id}>{location.name}{Number(location.is_main_stockroom||0)===1?' (Main Stockroom)':''}</option>)}</select></Field>
        <Field label="Quantity *"><input type="number" min="1" step="1" max={source?.available || 0} value={qty} onChange={(e)=>setQty(e.target.value)} className={inputClass} /></Field>
        {qty !== '' && invalidQty && <p className="text-xs font-bold text-red-600">Enter a whole number from 1 to {formatUnits(source?.available || 0)}.</p>}
        <Field label="Note"><input type="text" maxLength={255} value={note} onChange={(e)=>setNote(e.target.value)} className={inputClass} placeholder="Example: unused room stock returned" /></Field>
      </>}
      {error && <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}
    </div>
    <div className="flex justify-end gap-2 border-t border-slate-100 px-6 py-4"><button className="button-secondary" disabled={saving} onClick={onClose}>Cancel</button><button className="button-primary" disabled={saving || !source || !destinationId || invalidQty} onClick={submit}>{saving ? 'Moving…' : 'Move Stock'}</button></div>
  </div></div>
}

const BatchManagerModal = ({ item, onClose, onRequestAction, onConfirmAction, onLoadHistory, onChanged }) => {
  const [showHistorical,setShowHistorical]=useState(false)
  const [selected,setSelected]=useState(null)
  const [historyBatch,setHistoryBatch]=useState(null)
  const [historyData,setHistoryData]=useState({movements:[],audit:[]})
  const [historyLoading,setHistoryLoading]=useState(false)
  const [historyError,setHistoryError]=useState('')
  const batches=Array.isArray(item?.batches)?item.batches:[]
  const visible=batches.filter((batch)=>showHistorical || (!batch.archived_at && Number(batch.quantity||0)>0))
  const openHistory=async(batch)=>{setHistoryBatch(batch);setHistoryData({movements:[],audit:[]});setHistoryError('');setHistoryLoading(true);try{const result=await onLoadHistory(batch.id);setHistoryData({movements:Array.isArray(result?.movements)?result.movements:[],audit:Array.isArray(result?.audit)?result.audit:[]})}catch(err){setHistoryError(err.message||'Could not load batch history.')}finally{setHistoryLoading(false)}}
  const formatAuditValue=(value)=>value===null||value===undefined||value===''?'—':String(value)
  const auditChanges=(row)=>{const oldValues=row?.old_values||{};const newValues=row?.new_values||{};return Object.keys(newValues).filter(key=>!['authorization','item_name','reason'].includes(key)&&formatAuditValue(oldValues[key])!==formatAuditValue(newValues[key])).map(key=>({key:key.replace(/_/g,' '),before:formatAuditValue(oldValues[key]),after:formatAuditValue(newValues[key])}))}

  return <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/55 px-4"><div className="flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
    <div className="flex items-start justify-between border-b border-slate-100 px-6 py-4"><div><h3 className="text-lg font-bold text-slate-900">Manage Batches</h3><p className="mt-1 text-xs text-slate-500">{item.name} · batch quantity, expiry and supplier lot are managed here. Selling Price is managed on the item.</p></div><button onClick={onClose}><MdClose/></button></div>
    <div className="border-b border-slate-100 bg-slate-50 px-6 py-4"><div className="grid gap-3 sm:grid-cols-3"><div><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Product Barcode</p><p className="mt-1 font-mono text-sm font-bold text-slate-800">{item.barcode||'—'}</p></div><div><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Clinic-wide Stock</p><p className="mt-1 text-sm font-black text-slate-800">{formatUnits(item.stock)}</p></div><div><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Selling Price</p><p className={`mt-1 text-sm font-black ${Number(item.selling_price || 0) > 0 ? 'text-slate-800' : 'text-red-600'}`}>{Number(item.selling_price || 0) > 0 ? `PHP ${Number(item.selling_price).toFixed(2)}` : 'Not set'}</p></div></div><label className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-slate-600"><input type="checkbox" checked={showHistorical} onChange={e=>setShowHistorical(e.target.checked)}/> Show depleted / archived</label></div>
    <div className="flex-1 overflow-y-auto p-6 space-y-4">{visible.length?visible.map((batch)=>{const status=getBatchStatusMeta(batch);const locations=(Array.isArray(batch.locations)?batch.locations:[]).filter((location)=>Number(location.quantity||0)>0);return <div key={batch.id} className="rounded-3xl border border-slate-200 p-5"><div className="flex flex-wrap items-start justify-between gap-4"><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="font-mono text-sm font-black text-slate-900">{batch.batch_code||`Batch #${batch.id}`}</p><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${status.tone}`}>{status.label}</span></div><div className="mt-3 grid gap-3 text-sm sm:grid-cols-3"><div><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Supplier</p><p className="mt-1 font-semibold text-slate-700">{batch.supplier_name||'Not recorded'}</p><p className="mt-1 text-xs text-slate-400">Lot: {batch.supplier_lot_number||'Not provided'}</p></div><div><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Quantity</p><p className="mt-1 font-semibold text-slate-700">{formatUnits(batch.quantity)}</p></div><div><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Expiry</p><p className="mt-1 font-semibold text-slate-700">{batch.expiration_date?formatDate(batch.expiration_date):'No expiry'}</p></div></div>{locations.length>0&&<div className="mt-4"><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Location Balance</p><div className="mt-2 flex flex-wrap gap-2">{locations.map((location)=><span key={`${batch.id}-${location.id||location.name}`} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600"><strong>{location.name||'Location'}</strong> · {formatUnits(location.quantity)}</span>)}</div></div>}{batch.archive_reason&&<p className="mt-3 text-xs text-slate-400">Archive reason: {batch.archive_reason}</p>}</div><div className="flex flex-wrap gap-2"><button className="button-secondary" onClick={()=>openHistory(batch)}>View History</button>{!batch.archived_at&&<><button className="button-secondary" onClick={()=>setSelected({action:'correct_details',batch})}><MdEdit/> Edit Batch</button><button className="button-secondary" onClick={()=>setSelected({action:'correct_quantity',batch})}>Correct Quantity</button></>}{!batch.archived_at&&Number(batch.quantity||0)<=0&&<button className="button-secondary" onClick={()=>setSelected({action:'archive',batch})}>Archive</button>}{batch.archived_at&&<button className="button-secondary" onClick={()=>setSelected({action:'restore',batch})}>Restore</button>}{Number(batch.quantity||0)<=0&&<button className="button-danger" onClick={()=>setSelected({action:'delete',batch})}>Delete</button>}</div></div></div>}) : <div className="rounded-2xl bg-slate-50 p-8 text-center text-sm text-slate-400">No batches in this view.</div>}</div>
    <div className="border-t border-slate-100 p-5 flex justify-end"><button className="button-secondary" onClick={onClose}>Close</button></div>
    {selected&&<ProtectedBatchActionModal item={item} batch={selected.batch} action={selected.action} onClose={()=>setSelected(null)} onRequest={onRequestAction} onConfirm={onConfirmAction} onSuccess={(message)=>{setSelected(null);onChanged(message)}}/>}
    {historyBatch&&<div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 px-4"><div className="flex max-h-[82vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl"><div className="flex items-start justify-between border-b border-slate-100 px-6 py-4"><div><h3 className="font-bold text-slate-900">Batch History</h3><p className="mt-1 text-xs text-slate-500">{historyBatch.batch_code||`Batch #${historyBatch.id}`} · {item.name}</p></div><button onClick={()=>setHistoryBatch(null)}><MdClose/></button></div><div className="flex-1 overflow-y-auto p-6">{historyLoading?<div className="py-10 text-center text-sm text-slate-400">Loading history...</div>:historyError?<p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-600">{historyError}</p>:<div className="space-y-6"><section><h4 className="mb-3 text-xs font-black uppercase tracking-widest text-slate-400">Movements</h4>{historyData.movements.length?<div className="space-y-3">{historyData.movements.map((row)=><div key={`move-${row.id}`} className="rounded-2xl border border-slate-200 p-4 text-sm"><div className="flex justify-between gap-3"><strong className="text-slate-800">{String(row.movement_type||row.type||'movement').replace(/_/g,' ')}</strong><span className="text-xs text-slate-400">{row.logged_at?new Date(row.logged_at).toLocaleString('en-PH'):'—'}</span></div><p className="mt-1 text-slate-600">Qty: {formatUnits(row.qty)} · By: {row.performed_by||'System'} ({row.performed_by_role||'System'})</p>{row.from_location&&<p className="mt-1 text-xs text-slate-500">From: {row.from_location}</p>}{row.to_location&&<p className="mt-1 text-xs text-slate-500">To: {row.to_location}</p>}{row.note&&<p className="mt-1 text-xs text-slate-500">{row.note}</p>}</div>)}</div>:<p className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-400">No stock movement history recorded.</p>}</section><section><h4 className="mb-3 text-xs font-black uppercase tracking-widest text-slate-400">Protected Corrections & Actions</h4>{historyData.audit.length?<div className="space-y-3">{historyData.audit.map((row)=>{const changes=auditChanges(row);const reason=row?.new_values?.reason||row?.old_values?.reason;return <div key={`audit-${row.id}`} className="rounded-2xl border border-slate-200 p-4 text-sm"><div className="flex justify-between gap-3"><strong className="text-slate-800">{String(row.action||'batch action').replace(/^inventory\\./,'').replace(/_/g,' ')}</strong><span className="text-xs text-slate-400">{row.created_at?new Date(row.created_at).toLocaleString('en-PH'):'—'}</span></div>{changes.map((change)=><p key={change.key} className="mt-1 text-xs text-slate-600"><span className="font-semibold capitalize">{change.key}:</span> {change.before} → {change.after}</p>)}{reason&&<p className="mt-2 text-xs text-slate-500"><span className="font-semibold">Reason:</span> {reason}</p>}</div>})}</div>:<p className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-400">No protected corrections recorded.</p>}</section></div>}</div><div className="border-t border-slate-100 p-5 flex justify-end"><button className="button-secondary" onClick={()=>setHistoryBatch(null)}>Close</button></div></div></div>}
  </div></div>
}

const Inventory = ({ services, canManageSellingPrice = false }) => {
  const toast = useToast()
  const { getInventory, updateStock, addInventoryItem, updateInventoryItem, deleteInventoryItem, getInventoryMasterData, requestInventoryBatchActionCode, confirmInventoryBatchAction, getInventoryBatchHistory, moveInventoryStock, getInventoryLocations } = services
  const [items, setItems] = useState([])
  const [moveItem, setMoveItem] = useState(null)
  const [stockLocations, setStockLocations] = useState([])
  const [batchManagerItem, setBatchManagerItem] = useState(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [locationTypeFilter, setLocationTypeFilter] = useState('All')
  const [showAdd, setShowAdd] = useState(false)
  const [newItemBarcode, setNewItemBarcode] = useState('')
  const [masterData, setMasterData] = useState({ suppliers: [], location_types: [], movement_reasons: [] })
  const [editItem, setEditItem] = useState(null)
  const [deleteCandidate, setDeleteCandidate] = useState(null)
  const [deleting, setDeleting] = useState(false)
  const [stockItem, setStockItem] = useState(null)
  const [stockMode, setStockMode] = useState('in')
  const [scannerOpen, setScannerOpen] = useState(false)
  const [feedback, setFeedback] = useState(null)
  const [page, setPage] = useState(1)
  const hasActiveLocationType = (masterData.location_types || []).some((entry) => Number(entry.is_active ?? 1) === 1)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [data, masters] = await Promise.all([
        getInventory(),
        getInventoryMasterData ? getInventoryMasterData().catch(() => null) : Promise.resolve(null),
      ])
      setItems(Array.isArray(data) ? data : data?.items || [])
      if (masters) setMasterData({ suppliers: masters?.suppliers || [], location_types: masters?.location_types || [], movement_reasons: masters?.movement_reasons || [] })
    } finally {
      setLoading(false)
    }
  }, [getInventory, getInventoryMasterData])

  useEffect(() => { load() }, [load])

  const openMoveStock = async (item) => {
    try {
      const rows = await getInventoryLocations()
      setStockLocations(Array.isArray(rows) ? rows : [])
      setMoveItem(item)
    } catch (err) {
      toast.error(err.message || 'Could not load storage locations.')
    }
  }

  const submitMoveStock = async (item, payload) => {
    const result = await moveInventoryStock(item.id, payload)
    setMoveItem(null)
    await load()
    setFeedback({ type: 'success', message: result?.message || 'Stock moved.' })
  }

  useEffect(() => {
    if (!feedback) return undefined
    const timer = window.setTimeout(() => setFeedback(null), 3500)
    return () => window.clearTimeout(timer)
  }, [feedback])

  useEffect(() => {
    setPage(1)
  }, [search, category, locationTypeFilter])

  const filtered = useMemo(() => items.filter(item => {
    const matchesCategory = category === 'All' || item.category === category
    const matchesLocationType = locationTypeFilter === 'All' || Number(item.location_type_id) === Number(locationTypeFilter)
    const needle = search.toLowerCase()
    const matchesSearch = !needle ||
      item.name?.toLowerCase().includes(needle) ||
      item.barcode?.toLowerCase().includes(needle) ||
      item.supplier?.toLowerCase().includes(needle) ||
      item.location_type_name?.toLowerCase().includes(needle)
    return matchesCategory && matchesLocationType && matchesSearch
  }), [items, category, locationTypeFilter, search])

  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE))
  const currentPage = Math.min(page, totalPages)
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE)

  const handleAdd = async (payload) => {
    try {
      const created = await addInventoryItem(payload)
      setItems(prev => [...prev, created])
      setFeedback({ type: 'success', message: `${created.name} was added to inventory.` })
    } catch (err) {
      setFeedback({ type: 'error', message: err.message || 'Failed to add inventory item.' })
      throw err
    }
  }

  const handleEdit = async (payload) => {
    try {
      const updated = await updateInventoryItem(editItem.id, payload)
      setItems(prev => prev.map(item => item.id === editItem.id ? { ...item, ...updated } : item))
      setFeedback({ type: 'success', message: `${updated.name} was updated.` })
    } catch (err) {
      setFeedback({ type: 'error', message: err.message || 'Failed to update inventory item.' })
      throw err
    }
  }

  const handleDelete = (item) => setDeleteCandidate(item)

  const confirmDelete = async () => {
    if (!deleteCandidate?.id) return
    setDeleting(true)
    try {
      const result = await deleteInventoryItem(deleteCandidate.id)
      setItems(prev => prev.filter(entry => entry.id !== deleteCandidate.id))
      setFeedback({ type: 'success', message: result?.message || `${deleteCandidate.name} was archived.` })
      setDeleteCandidate(null)
    } catch (err) {
      setFeedback({ type: 'error', message: err.message || 'Failed to archive inventory item.' })
      await load().catch(() => {})
      setDeleteCandidate(null)
    } finally {
      setDeleting(false)
    }
  }

  const handleStockUpdate = async (payload) => {
    try {
      const updated = await updateStock(stockItem.id, payload)
      if (updated?.id) setItems((current)=>current.map((entry)=>Number(entry.id)===Number(updated.id)?updated:entry))
      await load()
      setFeedback({ type: 'success', message: payload.type === 'in' ? `${stockItem.name} stock received as a new batch.` : `${stockItem.name} stock out recorded and inventory totals refreshed.` })
      setStockItem(null)
    } catch (err) {
      setFeedback({ type: 'error', message: err.message || 'Failed to update stock.' })
      await load().catch(()=>{})
    }
  }

  const handleScannerDetected = useCallback((code) => {
    setScannerOpen(false)
    const normalizedCode = String(code || '').trim()
    const found = items.find((item) => String(item.barcode || '').trim() === normalizedCode)
    if (found) {
      toast.success(`Barcode matched ${found.name}.`)
      setStockMode('in')
      setStockItem(found)
    } else {
      if (typeof toast.info === 'function') toast.info(`Barcode ${normalizedCode} is not registered yet. Add Item has been opened with the scanned barcode.`)
      else toast.warning(`Barcode ${normalizedCode} is not registered yet. Add Item has been opened with the scanned barcode.`)
      setNewItemBarcode(normalizedCode)
      setShowAdd(true)
    }
  }, [items, toast])

  if (loading) {
    return <div className="p-12 text-center text-sm text-slate-400">Loading inventory...</div>
  }

  const summary = {
    total: items.length,
    low: items.filter(item => {
      const count = getPackageCount(item)
      return count > 0 && count <= Number(item.threshold || 0)
    }).length,
    out: items.filter(item => getPackageCount(item) === 0).length,
    expiring: items.filter(item => {
      if (!item.expiration_date) return false
      const expiry = parseDateOnly(item.expiration_date)
      if (!expiry) return false
      const today = new Date()
      expiry.setHours(0, 0, 0, 0)
      today.setHours(0, 0, 0, 0)
      return expiry >= today && expiry <= new Date(today.getTime() + 30 * 86400000)
    }).length,
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Inventory</h1>
          <p className="text-sm text-slate-500 mt-1">Batch-aware inventory with Storage Locations configured in System Setup, generated barcodes, and whole-unit stock tracking.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={load} className="w-10 h-10 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50 flex items-center justify-center"><MdRefresh className="text-[18px]" /></button>
          <button onClick={() => setScannerOpen(true)} className="rounded-2xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm font-semibold text-sky-700 flex items-center gap-2"><MdQrCodeScanner /> Scan Barcode</button>
          <button title={hasActiveLocationType ? 'Add inventory item' : 'Configure at least one active Storage Location in System Setup first'} disabled={!hasActiveLocationType} onClick={() => { setNewItemBarcode(''); setShowAdd(true) }} className="rounded-2xl bg-[#0b1a2c] px-4 py-3 text-sm font-semibold text-white flex items-center gap-2 disabled:cursor-not-allowed disabled:opacity-40"><MdAdd /> Add Item</button>
        </div>
      </div>

      {feedback && (
        <div className={`flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm ${
          feedback.type === 'error'
            ? 'border-red-200 bg-red-50 text-red-700'
            : 'border-emerald-200 bg-emerald-50 text-emerald-700'
        }`}>
          {feedback.type === 'error' ? <MdWarningAmber className="mt-0.5 text-[18px]" /> : <MdCheckCircle className="mt-0.5 text-[18px]" />}
          <p>{feedback.message}</p>
        </div>
      )}

      {!hasActiveLocationType && <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800"><strong>Inventory setup required.</strong> Add at least one active Storage Location in Admin → System Setup before creating items.</div>}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: 'Tracked Items', value: summary.total, tone: 'text-slate-800' },
          { label: 'Low Stock', value: summary.low, tone: 'text-amber-600' },
          { label: 'Out of Stock', value: summary.out, tone: 'text-red-600' },
          { label: 'Expiring in 30 Days', value: summary.expiring, tone: 'text-violet-600' },
        ].map((card) => (
          <div key={card.label} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-widest text-slate-400">{card.label}</p>
            <p className={`mt-3 text-3xl font-black ${card.tone}`}>{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-[1fr_auto_240px]">
        <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3">
          <MdSearch className="text-slate-400 text-[18px]" />
          <input aria-label="Search inventory" value={search} onChange={e => setSearch(e.target.value)} className="w-full bg-transparent text-sm outline-none" placeholder="Search item, barcode, or supplier" />
        </div>
        <div className="flex gap-2 overflow-x-auto">
          {['All', ...CATEGORIES.map(x => x.value)].map(option => (
            <button key={option} onClick={() => setCategory(option)} className={`rounded-2xl px-4 py-3 text-sm font-semibold ${category === option ? 'bg-[#0b1a2c] text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
              {option === 'All' ? 'All' : (CATEGORIES.find(x => x.value === option)?.label || option)}
            </button>
          ))}
        </div>
        <select aria-label="Filter by storage location" value={locationTypeFilter} onChange={(e)=>setLocationTypeFilter(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-600 outline-none focus:border-sky-400">
          <option value="All">All Storage Locations</option>
          {(masterData.location_types || []).map((entry)=><option key={entry.id} value={entry.id}>{entry.name}</option>)}
        </select>
      </div>

      <div className="grid gap-4">
        {paginated.map(item => {
          const activeBatches = (Array.isArray(item.batches)?item.batches:[]).filter((batch)=>!batch.archived_at&&Number(batch.quantity||0)>0)
          return <div key={item.id} className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div className="space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-lg font-bold text-slate-800">{item.name}</p>
                  <span className={`text-xs font-bold border px-2 py-1 rounded-full ${getStockBadge(item)}`}>{getPackageCount(item) === 0 ? 'Out' : getPackageCount(item) <= Number(item.threshold || 0) ? 'Low' : 'OK'}</span>
                </div>
                <p className="text-sm text-slate-500">{CATEGORIES.find(x=>x.value===item.category)?.label || item.category} · {(ITEM_TYPES.find(x=>x.value===item.item_type)?.label || item.item_type || 'Supplies')} · {item.supplier || 'No supplier'}</p>
                <p className="text-sm text-slate-600">
                  <strong>{formatUnits(item.stock ?? item.stock_base ?? 0)}</strong> in stock
                </p>
                <p className="text-xs text-slate-400">Low stock threshold: {formatUnits(item.threshold)} · Selling Price: {Number(item.selling_price || 0) > 0 ? `PHP ${Number(item.selling_price).toFixed(2)}` : 'Not set'}</p>{Number(item.selling_price || 0) <= 0 && <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-bold text-red-700">Selling Price is missing. {canManageSellingPrice ? 'Edit this item and set a price greater than ₱0.00 before it can be used for direct Checkout billing.' : 'Ask an Admin to set the Selling Price before this item can be used for patient billing.'}</div>}
                <div className="flex flex-wrap gap-3 pt-1 text-xs">
                  <span className="inline-flex items-center gap-1 text-slate-500">
                    <MdLocationOn className="text-[14px]" /> Storage Location: {item.location_type_name || 'Not assigned'}
                  </span>
                  <span className={`inline-flex items-center gap-1 ${getExpiryMeta(item).tone}`}>
                    <MdCalendarToday className="text-[14px]" /> {getExpiryMeta(item).label}
                  </span>
                </div>
                {Array.isArray(item.batches) && item.batches.length > 0 && (
                  <div className="pt-3">
                    <div className="flex items-center justify-between gap-3"><p className="text-xs font-bold uppercase tracking-widest text-slate-400">Active Batches ({activeBatches.length})</p></div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {item.batches.filter((batch)=>!batch.archived_at && Number(batch.quantity || 0)>0).slice(0, 4).map(batch => (
                        <span key={batch.id} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-600">
                          {batch.batch_code || `Batch #${batch.id}`}{batch.supplier_lot_number ? ` · Lot ${batch.supplier_lot_number}` : ''} - {formatBatchLabel(batch)}
                        </span>
                      ))}
                      {item.batches.filter((batch)=>!batch.archived_at && Number(batch.quantity || 0)>0).length > 4 && (
                        <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-500">+{item.batches.filter((batch)=>!batch.archived_at && Number(batch.quantity || 0)>0).length - 4} more active batches</span>
                      )}
                      {item.batches.filter((batch)=>!batch.archived_at && Number(batch.quantity || 0)>0).length===0 && <span className="text-xs text-slate-400">No active batch stock.</span>}
                    </div>
                  </div>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button onClick={() => { setStockMode('in'); setStockItem(item) }} className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700 hover:bg-emerald-100 flex items-center gap-2"><MdInventory2 /> Stock In</button>
                <button onClick={() => { setStockMode('out'); setStockItem(item) }} className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-bold text-red-700 hover:bg-red-100 flex items-center gap-2"><MdInventory2 /> Stock Out</button>
                {moveInventoryStock && getInventoryLocations && Number(item.stock || 0) > 0 && <button onClick={() => openMoveStock(item)} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-600 hover:bg-slate-50 flex items-center gap-2"><MdSwapHoriz /> Move Stock</button>}
                <button onClick={() => setEditItem(item)} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-600 hover:bg-slate-50 flex items-center gap-2"><MdEdit /> Edit Item</button>
                {requestInventoryBatchActionCode && confirmInventoryBatchAction && <button onClick={()=>setBatchManagerItem(item)} className="rounded-2xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm font-bold text-sky-700 hover:bg-sky-100 flex items-center gap-2"><MdInventory2/> Manage Batches</button>}
                {deleteInventoryItem && <button onClick={() => handleDelete(item)} title="Archive item" className="w-11 h-11 rounded-2xl border border-red-200 text-red-500 hover:bg-red-50 flex items-center justify-center"><MdDelete className="text-[18px]" /></button>}
              </div>
            </div>
          </div>
        })}
      </div>

      {filtered.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center text-sm text-slate-400">No inventory items match your filters.</div>
      )}

      {filtered.length > 0 && (
        <div className="flex flex-col gap-3 rounded-3xl border border-slate-200 bg-white px-5 py-4 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>
            Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, filtered.length)} of {filtered.length} items
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((prev) => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="rounded-2xl border border-slate-200 px-4 py-2 font-semibold text-slate-600 disabled:opacity-40"
            >
              Previous
            </button>
            <span className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold uppercase tracking-wider text-slate-500">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="rounded-2xl border border-slate-200 px-4 py-2 font-semibold text-slate-600 disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {showAdd && <ItemFormModal title="Add Item" initialBarcode={newItemBarcode} canManageSellingPrice={canManageSellingPrice} masterData={masterData} existingItems={items} onClose={() => { setShowAdd(false); setNewItemBarcode('') }} onSubmit={handleAdd} />}
      {editItem && <ItemFormModal title="Edit Inventory Item" initialItem={editItem} canManageSellingPrice={canManageSellingPrice} masterData={masterData} existingItems={items} onClose={() => setEditItem(null)} onSubmit={handleEdit} />}
      {stockItem && <StockModal item={stockItem} initialType={stockMode} movementReasons={masterData.movement_reasons || []} suppliers={masterData.suppliers || []} onClose={() => setStockItem(null)} onSubmit={handleStockUpdate} />}
      {scannerOpen && <CameraScanner onDetected={handleScannerDetected} onClose={() => setScannerOpen(false)} />}
      {moveItem && <MoveStockModal item={moveItem} locations={stockLocations} onClose={() => setMoveItem(null)} onSubmit={submitMoveStock} />}
      {batchManagerItem && requestInventoryBatchActionCode && confirmInventoryBatchAction && <BatchManagerModal item={batchManagerItem} onClose={()=>setBatchManagerItem(null)} onRequestAction={requestInventoryBatchActionCode} onConfirmAction={confirmInventoryBatchAction} onLoadHistory={getInventoryBatchHistory} onChanged={async (message)=>{setBatchManagerItem(null);await load();setFeedback({type:'success',message})}} />}
      <ConfirmDialog
        open={Boolean(deleteCandidate)}
        title="Archive inventory item?"
        message={deleteCandidate ? `Archive ${deleteCandidate.name}? Items with stock cannot be archived. Archived items are hidden from active inventory and their inventory, billing, transfer, and clinical history is preserved.` : ''}
        confirmLabel="Archive Item"
        loading={deleting}
        onCancel={() => !deleting && setDeleteCandidate(null)}
        onConfirm={confirmDelete}
      />
    </div>
  )
}

export default Inventory






