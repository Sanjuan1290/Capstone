import { useEffect, useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { Link } from 'react-router-dom'
import { MdArchive, MdDelete, MdHistory, MdRefresh, MdVisibility } from 'react-icons/md'
import { deleteAuditArchive, getAuditArchives } from '../../services/admin.service'
import { useToast } from '../../components/ui/ToastProvider'
import { EmptyState, ErrorState, LoadingState } from '../../components/ui/PageState'
import Pagination from '../../components/ui/Pagination'
import Modal from '../../components/ui/Modal'

const fmt=(v)=>v?new Date(v).toLocaleString('en-PH'):'—'
const Admin_AuditArchive=()=>{const {role}=useAuth();const workspace=typeof window!=='undefined'&&window.location.pathname.match(/^\/superadmin\/branches\/\d+/);const portalBase=workspace?workspace[0]:role==='staff'?'/staff':'/admin';const canDelete=false; // Clinic audit archives are retained; no permanent deletion from branch workspaces.
  const toast=useToast();const [page,setPage]=useState(1),[data,setData]=useState({items:[],pagination:{}}),[loading,setLoading]=useState(true),[error,setError]=useState(''),[candidate,setCandidate]=useState(null),[reason,setReason]=useState(''),[confirmation,setConfirmation]=useState(''),[deleting,setDeleting]=useState(false)
  const load=async()=>{setLoading(true);setError('');try{setData(await getAuditArchives({page,limit:10}))}catch(e){setError(e.message||'Could not load audit archive.')}finally{setLoading(false)}}
  useEffect(()=>{load()},[page]) // eslint-disable-line react-hooks/exhaustive-deps
  const remove=async()=>{if(confirmation!=='DELETE'||!reason.trim())return;setDeleting(true);try{await deleteAuditArchive(candidate.id,{confirmation,reason:reason.trim()});toast.success('Archived audit log batch permanently deleted.');setCandidate(null);setReason('');setConfirmation('');load()}catch(e){toast.error(e.message||'Could not delete archive.')}finally{setDeleting(false)}}
  const items=data.items||[],p=data.pagination||{}
  return <div className="mx-auto w-full max-w-7xl space-y-5">
    <div className="flex flex-wrap items-start justify-between gap-3"><div><Link to={`${portalBase}/audit-logs`} className="text-sm font-bold text-slate-500 hover:text-slate-800">← Audit Logs</Link><h1 className="mt-2 flex items-center gap-2 text-2xl font-black text-slate-900"><MdArchive className="text-amber-500"/> Audit Log Archive</h1><p className="mt-1 text-sm text-slate-500">Archived logs are grouped into batches so old history stays reviewable without crowding the active audit feed.</p></div><button className="button-secondary" onClick={load}><MdRefresh/> Refresh</button></div>
    <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">{loading?<div className="p-5"><LoadingState label="Loading archives..."/></div>:error?<div className="p-5"><ErrorState message={error} onRetry={load}/></div>:!items.length?<div className="p-5"><EmptyState title="No archived logs" description="Audit logs appear here after an Administrator archives records that are at least one year old."/></div>:<div className="divide-y divide-slate-100">{items.map((a)=><div key={a.id} className="p-5"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="font-black text-slate-900">{a.archive_code}</p><p className="mt-1 text-sm text-slate-500">{Number(a.log_count||0).toLocaleString()} logs · archived {fmt(a.archived_at)}</p><p className="mt-1 text-xs text-slate-400">Archived by {a.archived_by||'Administrator'} · cutoff {fmt(a.cutoff_at)}</p></div><div className="flex gap-2"><Link className="button-secondary" to={`${portalBase}/audit-logs/archive/${a.id}`}><MdVisibility/> View More</Link>{canDelete&&<button className="button-danger" onClick={()=>setCandidate(a)}><MdDelete/> Delete Archive</button>}</div></div></div>)}</div>}<div className="border-t border-slate-100 p-4"><Pagination page={p.page||page} totalPages={p.totalPages||1} pageSize={p.limit||10} total={p.total||0} onPageChange={setPage}/></div></section>
    <Modal open={canDelete && Boolean(candidate)} onClose={()=>!deleting&&setCandidate(null)} title="Permanently Delete Archived Logs" description="This removes every log in this archive batch and cannot be undone." size="md"><div className="space-y-4"><div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-800"><strong>{candidate?.archive_code}</strong><p className="mt-1">{Number(candidate?.log_count||0).toLocaleString()} archived audit logs will be permanently deleted.</p></div><label className="block"><span className="form-label">Reason *</span><textarea className="form-control mt-1.5" rows={3} value={reason} onChange={(e)=>setReason(e.target.value)} /></label><label className="block"><span className="form-label">Type DELETE to confirm *</span><input className="form-control mt-1.5" value={confirmation} onChange={(e)=>setConfirmation(e.target.value)} /></label><div className="flex justify-end gap-2"><button className="button-secondary" onClick={()=>setCandidate(null)}>Cancel</button><button className="button-danger" disabled={deleting||confirmation!=='DELETE'||!reason.trim()} onClick={remove}>{deleting?'Deleting…':'Delete Permanently'}</button></div></div></Modal>
  </div>
}
export default Admin_AuditArchive



