import { useEffect, useMemo, useState } from 'react'
import { Link, useLocation, useSearchParams } from 'react-router-dom'
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdWarningAmber,
  MdRefresh,
  MdSettings,
} from 'react-icons/md'
import Admin_PatientBooking from './Admin_PatientBooking'
import Admin_Promotions from './Admin_Promotions'
import Modal from '../../components/ui/Modal'
import Pagination from '../../components/ui/Pagination'
import SystemSetupTabs, { SYSTEM_SETUP_TABS } from '../../components/system/SystemSetupTabs'
import StockRoomsManager from '../../components/system/StockRoomsManager'
import useClientPagination from '../../hooks/useClientPagination'
import { LoadingState, ErrorState, EmptyState } from '../../components/ui/PageState'
import { useToast } from '../../components/ui/ToastProvider'
import {
  getSystemSetup,
  deleteAppointmentCancellationReason,
  saveAppointmentCancellationReason,
  deleteBillingServiceCategory,
  saveBillingServiceCategory,
  saveInventoryLocationType,
  saveInventoryMovementReason,
  saveInventorySupplier,
} from '../../services/admin.service'

const TABS = SYSTEM_SETUP_TABS.filter((item) => !['billing_setup'].includes(item.key))

const clinicLabel = (value) => value === 'derma' ? 'Dermatology' : 'General Medicine'
const parseSupplierClinics = (value) => String(value || '').split(',').map((entry) => entry.trim()).filter((entry) => ['medical','derma'].includes(entry))
const supplierClinicLabel = (value) => {
  const clinics = parseSupplierClinics(value)
  return clinics.length ? clinics.map(clinicLabel).join(', ') : '—'
}

const ReferenceManager = ({ type, rows, onReload, portalBase = '/admin' }) => {
  const referenceLocation = useLocation()
  const globalReferenceReadOnly = type === 'movement_reasons' && !referenceLocation.pathname.startsWith('/superadmin/')
  const toast = useToast()
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({})
  const [saving, setSaving] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleting, setDeleting] = useState(false)


  const nameMaxLength = {
    service_categories: 120,
    suppliers: 160,
    location_types: 80,
    movement_reasons: 120,
    cancellation_reasons: 120,
  }[type] || 120

  const config = useMemo(() => ({
    cancellation_reasons: {
      title: 'Reason for Cancellation',
      plural: 'Reasons for Cancellation',
      singular: 'cancellation reason',
      save: saveAppointmentCancellationReason,
      description: 'Reusable reasons shown whenever a Patient, Admin, or Staff member cancels an appointment. “Other” is always available separately and requires an explanation.',
    },
    service_categories: {
      title: 'Service Category',
      plural: 'Service Categories',
      singular: 'service category',
      save: saveBillingServiceCategory,
      description: 'Categories only group actual services. They are shown alphabetically in Add Service; create bookable services under System Setup → Services & Pricing Setup → Services & Pricing.',
    },
    suppliers: {
      title: 'Supplier',
      plural: 'Suppliers',
      singular: 'supplier',
      save: saveInventorySupplier,
      description: 'Reusable supplier/company records with clinic assignment and contact details.',
    },
    location_types: {
      title: 'Storage Location',
      plural: 'Storage Locations',
      singular: 'storage location',
      save: saveInventoryLocationType,
      description: 'Reusable Storage Locations assigned directly to inventory items. Add at least one before creating inventory items.',
    },
    movement_reasons: {
      title: 'Movement Reason',
      plural: 'Movement Reasons',
      singular: 'movement reason',
      save: saveInventoryMovementReason,
      description: 'Reusable reasons shown when recording Stock In or Stock Out. Built-in codes stay protected so existing inventory history remains valid.',
    },
  }[type]), [type])

  const pagination = useClientPagination(rows, { initialPageSize: 10, resetDeps: [type] })

  const close = () => {
    setEditing(null)
    setForm({})
  }

  const open = (row = null) => {
    setEditing(row)
    if (type === 'cancellation_reasons') {
      setForm({
        name: row?.label || '',
        is_active: row ? Number(row.is_active) : 1,
      })
    }
    if (type === 'service_categories') {
      setForm({
        name: row?.name || '',
        clinic_type: row?.clinic_type || 'medical',
        is_active: row ? Number(row.is_active) : 1,
      })
    }
    if (type === 'suppliers') {
      setForm({
        name: row?.name || '',
        contact_person: row?.contact_person || '',
        contact_number: row?.contact_number || '',
        address: row?.address || '',
        clinics: parseSupplierClinics(row?.category),
        is_active: row ? Number(row.is_active) : 1,
      })
    }
    if (type === 'location_types') {
      setForm({
        name: row?.name || '',
        is_active: row ? Number(row.is_active) : 1,
        sort_order: row?.sort_order ?? 0,
      })
    }
    if (type === 'movement_reasons') {
      setForm({
        name: row?.name || '',
        movement_type: row?.movement_type || 'in',
        requires_batch: row ? Number(row.requires_batch) : 0,
        is_active: row ? Number(row.is_active) : 1,
        is_system: row ? Number(row.is_system) : 0,
        code: row?.code || '',
      })
    }
  }

  const save = async () => {
    if (!String(form.name || '').trim()) return toast.warning(`Enter a ${config.singular} name.`)
    if (type === 'suppliers' && !(form.clinics || []).length) return toast.warning('Select at least one clinic.')
    setSaving(true)
    try {
      const payload = type === 'cancellation_reasons'
        ? { label: String(form.name).trim(), is_active: form.is_active }
        : { ...form, name: String(form.name).trim() }
      await config.save(payload, editing?.id || null)
      toast.success(`${config.title} ${editing ? 'updated' : 'added'}.`)
      close()
      await onReload()
    } catch (err) {
      toast.error(err.message || `Could not save ${config.singular}.`)
    } finally {
      setSaving(false)
    }
  }


  const requestDelete = (row) => {
    if (!['service_categories', 'cancellation_reasons'].includes(type)) return
    setDeleteTarget(row)
  }

  const confirmDelete = async () => {
    if (!deleteTarget) return
    const inUseCount = type === 'service_categories'
      ? Number(deleteTarget.service_count || 0)
      : Number(deleteTarget.appointment_count || 0)
    if (inUseCount > 0) return
    setDeleting(true)
    try {
      if (type === 'service_categories') await deleteBillingServiceCategory(deleteTarget.id)
      else await deleteAppointmentCancellationReason(deleteTarget.id)
      toast.success(`${config.title} deleted.`)
      setDeleteTarget(null)
      await onReload()
    } catch (err) {
      toast.error(err.message || `Could not delete ${config.singular}.`)
    } finally {
      setDeleting(false)
    }
  }

  return (
    <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 p-5">
        <div>
          <h2 className="font-black text-slate-900">{config.plural}</h2>
          <p className="mt-1 max-w-3xl text-sm text-slate-500">{config.description}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {type === 'service_categories' && <Link className="button-secondary" to={`${portalBase}/system-setup/billing/services`}>Manage Services & Pricing</Link>}
          {globalReferenceReadOnly ? <span className="text-xs text-slate-500">Managed centrally by Super Admin</span> : <button className="button-primary" onClick={() => open()}><MdAdd /> Add {config.title}</button>}
        </div>
      </div>

      {!rows.length ? (
        <div className="p-5"><EmptyState title={`No ${config.plural.toLowerCase()} yet`} description="Add the first reusable option." /></div>
      ) : (
        <div>
          <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-5 py-3">Name</th>
                {type === 'cancellation_reasons' && <><th className="px-5 py-3">Used By</th></>}
                {type === 'service_categories' && <th className="px-5 py-3">Clinic</th>}
                {type === 'service_categories' && <th className="px-5 py-3">Used By</th>}
                {type === 'suppliers' && <th className="px-5 py-3">Contact</th>}
                {type === 'suppliers' && <th className="px-5 py-3">Address</th>}
                {type === 'suppliers' && <th className="px-5 py-3">Clinic</th>}
                {type === 'movement_reasons' && <th className="px-5 py-3">Movement</th>}
                {type === 'movement_reasons' && <th className="px-5 py-3">Batch Rule</th>}
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {pagination.pageItems.map((row) => (
                <tr key={row.id}>
                  <td className="px-5 py-4 font-semibold text-slate-800">{row.label || row.name}</td>
                  {type === 'cancellation_reasons' && <><td className="px-5 py-4 text-slate-500">{Number(row.appointment_count || 0)} appointment{Number(row.appointment_count || 0) === 1 ? '' : 's'}</td></>}
                  {type === 'service_categories' && <td className="px-5 py-4 text-slate-500">{clinicLabel(row.clinic_type)}</td>}
                  {type === 'service_categories' && <td className="px-5 py-4 text-slate-500">{Number(row.service_count || 0)} service{Number(row.service_count || 0) === 1 ? '' : 's'}</td>}
                  {type === 'suppliers' && <td className="px-5 py-4 text-slate-500"><p className="font-semibold text-slate-700">{row.contact_person || '—'}</p><p className="mt-1 text-xs">{row.contact_number || 'No contact number'}</p></td>}
                  {type === 'suppliers' && <td className="max-w-xs px-5 py-4 text-slate-500">{row.address || '—'}</td>}
                  {type === 'suppliers' && <td className="px-5 py-4 text-slate-500">{supplierClinicLabel(row.category)}</td>}
                  {type === 'movement_reasons' && <td className="px-5 py-4 text-slate-500"><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${row.movement_type === 'in' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>{row.movement_type === 'in' ? 'Stock In' : 'Stock Out'}</span></td>}
                  {type === 'movement_reasons' && <td className="px-5 py-4 text-slate-500">{Number(row.requires_batch) === 1 ? 'Exact batch required' : 'Standard batch flow'}</td>}
                  <td className="px-5 py-4">
                    <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${Number(row.is_active) === 1 ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                      {Number(row.is_active) === 1 ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-right">
                    <div className="inline-flex flex-wrap justify-end gap-2">
                      {!globalReferenceReadOnly && <button className="button-secondary" onClick={() => open(row)}><MdEdit /> Edit</button>}
                      {['service_categories','cancellation_reasons'].includes(type) && <button className="button-secondary !border-rose-200 !text-rose-600 hover:!bg-rose-50" onClick={() => requestDelete(row)}><MdDelete /> Delete</button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          <Pagination {...pagination} total={rows.length} pageSizeOptions={[10, 25, 50]} />
        </div>
      )}

      <Modal open={Boolean(editing) || Boolean(form.name !== undefined && Object.keys(form).length)} onClose={close} title={`${editing ? 'Edit' : 'Add'} ${config.title}`} size="md">
        <div className="space-y-4">
          <label className="block">
            <span className="form-label">{type === 'suppliers' ? 'Company / Supplier Name *' : 'Name *'}</span>
            <input maxLength={nameMaxLength} className="form-control mt-1.5" value={form.name || ''} onChange={(e) => setForm((value) => ({ ...value, name: e.target.value }))} />
          </label>

          {type === 'service_categories' && (
            <>
              <label className="block">
                <span className="form-label">Clinic *</span>
                <select className="form-control mt-1.5" value={form.clinic_type || 'medical'} disabled={Boolean(editing && Number(editing.service_count || 0) > 0)} onChange={(e) => setForm((value) => ({ ...value, clinic_type: e.target.value }))}>
                  <option value="medical">General Medicine</option>
                  <option value="derma">Dermatology</option>
                </select>
                {editing && Number(editing.service_count || 0) > 0 && <p className="mt-1 text-xs text-slate-400">Clinic is locked because this category is already used by {Number(editing.service_count)} service{Number(editing.service_count) === 1 ? '' : 's'}. You can still rename or deactivate it.</p>}
              </label>
            </>
          )}


          {type === 'suppliers' && (
            <>
              <label className="block">
                <span className="form-label">Contact Person / Spokesperson</span>
                <input maxLength={160} className="form-control mt-1.5" value={form.contact_person || ''} onChange={(e) => setForm((value) => ({ ...value, contact_person: e.target.value }))} placeholder="e.g. Juan Dela Cruz" />
              </label>
              <label className="block">
                <span className="form-label">Contact Number</span>
                <input maxLength={80} className="form-control mt-1.5" value={form.contact_number || ''} onChange={(e) => setForm((value) => ({ ...value, contact_number: e.target.value }))} placeholder="Mobile or landline" />
              </label>
              <label className="block">
                <span className="form-label">Address</span>
                <textarea maxLength={255} rows={3} className="form-control mt-1.5 resize-none" value={form.address || ''} onChange={(e) => setForm((value) => ({ ...value, address: e.target.value }))} placeholder="Supplier/company address" />
              </label>
              <fieldset className="block">
                <legend className="form-label">Clinic *</legend>
                <p className="mt-1 text-xs text-slate-500">Select every clinic this supplier can provide items for.</p>
                <div className="mt-2 grid gap-2 sm:grid-cols-2">
                  {[
                    { value: 'medical', label: 'General Medicine' },
                    { value: 'derma', label: 'Dermatology' },
                  ].map((clinic) => {
                    const checked = (form.clinics || []).includes(clinic.value)
                    return (
                      <label key={clinic.value} className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-3 text-sm font-semibold transition ${checked ? 'border-amber-300 bg-amber-50 text-slate-900' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'}`}>
                        <input
                          type="checkbox"
                          className="h-4 w-4 rounded border-slate-300 text-amber-500 focus:ring-amber-400"
                          checked={checked}
                          onChange={(e) => setForm((value) => {
                            const current = new Set(value.clinics || [])
                            if (e.target.checked) current.add(clinic.value)
                            else current.delete(clinic.value)
                            return { ...value, clinics: Array.from(current) }
                          })}
                        />
                        <span>{clinic.label}</span>
                      </label>
                    )
                  })}
                </div>
              </fieldset>
            </>
          )}

          {type === 'movement_reasons' && (
            <>
              <label className="block">
                <span className="form-label">Movement Type *</span>
                <select
                  className="form-control mt-1.5"
                  value={form.movement_type || 'in'}
                  disabled={Boolean(editing && Number(form.is_system) === 1)}
                  onChange={(e) => setForm((value) => ({ ...value, movement_type: e.target.value }))}
                >
                  <option value="in">Stock In</option>
                  <option value="out">Stock Out</option>
                </select>
                {editing && Number(form.is_system) === 1 && <p className="mt-1 text-xs text-slate-400">Built-in reasons keep their Stock In / Stock Out type so existing inventory history remains consistent.</p>}
              </label>
              <label className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <input type="checkbox" className="mt-1" checked={Number(form.requires_batch) === 1} onChange={(e) => setForm((value) => ({ ...value, requires_batch: e.target.checked ? 1 : 0 }))} />
                <span><strong className="text-sm text-slate-800">Require exact batch selection</strong><span className="mt-0.5 block text-xs text-slate-500">Use this for reasons where the specific lot must remain traceable, such as expired, damaged, wastage, or returns.</span></span>
              </label>
              {editing && form.code && <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-500">Internal code: <code className="font-bold text-slate-700">{form.code}</code>. The code is kept stable and is not edited from System Setup.</div>}
            </>
          )}


          <label className="block">
            <span className="form-label">Status</span>
            <select className="form-control mt-1.5" value={Number(form.is_active) === 0 ? 0 : 1} onChange={(e) => setForm((value) => ({ ...value, is_active: Number(e.target.value) }))}>
              <option value={1}>Active</option>
              <option value={0}>Inactive</option>
            </select>
          </label>

          <div className="flex justify-end gap-2">
            <button className="button-secondary" disabled={saving} onClick={close}>Cancel</button>
            <button className="button-primary" disabled={saving || !String(form.name || '').trim()} onClick={save}>{saving ? 'Saving…' : 'Save'}</button>
          </div>
        </div>
      </Modal>

      <Modal open={Boolean(deleteTarget)} onClose={() => !deleting && setDeleteTarget(null)} title={`Delete ${config.title}`} size="sm">
        {deleteTarget && (() => {
          const inUseCount = type === 'service_categories'
            ? Number(deleteTarget.service_count || 0)
            : Number(deleteTarget.appointment_count || 0)
          const inUseLabel = type === 'service_categories'
            ? `${inUseCount} service${inUseCount === 1 ? '' : 's'}`
            : `${inUseCount} appointment${inUseCount === 1 ? '' : 's'}`
          return <div className="space-y-4">
            <div className={`flex items-start gap-3 rounded-2xl border p-4 ${inUseCount > 0 ? 'border-amber-200 bg-amber-50' : 'border-rose-200 bg-rose-50'}`}>
              <MdWarningAmber className={`mt-0.5 shrink-0 text-xl ${inUseCount > 0 ? 'text-amber-600' : 'text-rose-600'}`} />
              <div>
                <p className="font-bold text-slate-900">{deleteTarget.label || deleteTarget.name}</p>
                {inUseCount > 0 ? (
                  <p className="mt-1 text-sm text-slate-600">This {config.singular} is currently used by {inUseLabel} and cannot be permanently deleted. Edit it and set its status to <strong>Inactive</strong> instead so existing records remain valid.</p>
                ) : (
                  <p className="mt-1 text-sm text-slate-600">This {config.singular} is not in use. Permanent deletion cannot be undone.</p>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button className="button-secondary" disabled={deleting} onClick={() => setDeleteTarget(null)}>{inUseCount > 0 ? 'Close' : 'Cancel'}</button>
              {inUseCount > 0 ? (
                <button className="button-primary" onClick={() => { setDeleteTarget(null); open(deleteTarget) }}>Edit & Deactivate</button>
              ) : (
                <button className="button-primary !bg-rose-600 hover:!bg-rose-700" disabled={deleting} onClick={confirmDelete}>{deleting ? 'Deleting…' : `Delete ${config.title}`}</button>
              )}
            </div>
          </div>
        })()}
      </Modal>
    </section>
  )
}

const Admin_SystemSetup = () => {
  const location = useLocation()
  const portalBase = location.pathname.startsWith('/staff') ? '/staff' : '/admin'
  const [searchParams] = useSearchParams()
  const requestedTab = searchParams.get('tab')
  const validTab = TABS.some((item) => item.key === requestedTab) && (requestedTab !== 'promotions' || portalBase === '/admin') ? requestedTab : 'visits'
  const [tab, setTab] = useState(validTab)
  const [data, setData] = useState({ cancellation_reasons: [], service_categories: [], suppliers: [], location_types: [], movement_reasons: [] })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      setData(await getSystemSetup())
    } catch (err) {
      setError(err.message || 'Could not load System Setup.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (validTab !== tab) setTab(validTab)
  }, [validTab]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!['visits', 'stock_rooms', 'promotions'].includes(tab)) load()
  }, [tab]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="mx-auto w-full max-w-7xl space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-black text-slate-900"><MdSettings className="text-amber-500" /> System Setup</h1>
          <p className="mt-1 text-sm text-slate-500">Manage patient visit options, cancellation reasons, services and pricing setup, service categories, reusable inventory reference data, and Stock In / Stock Out movement reasons from one place.</p>
        </div>
        {!['visits', 'stock_rooms', 'promotions'].includes(tab) && <button className="button-secondary" onClick={load}><MdRefresh /> Refresh</button>}
      </div>

      <SystemSetupTabs />

      {tab === 'visits' ? (
        <Admin_PatientBooking embedded />
      ) : tab === 'promotions' && portalBase === '/admin' ? (
        <Admin_Promotions />
      ) : tab === 'stock_rooms' ? (
        <StockRoomsManager />
      ) : loading ? (
        <LoadingState label="Loading System Setup..." />
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : (
        <ReferenceManager type={tab} rows={data[tab] || []} onReload={load} portalBase={portalBase} />
      )}
    </div>
  )
}

export default Admin_SystemSetup







