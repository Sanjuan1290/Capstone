import { useEffect, useState } from 'react'
import Pagination from '../../components/ui/Pagination'
import useClientPagination from '../../hooks/useClientPagination'
import { getMyHistory } from '../../services/patient.service'
import {
  MdAccessTime,
  MdCalendarToday,
  MdClose,
  MdExpandLess,
  MdExpandMore,
  MdFace,
  MdHistory,
  MdImage,
  MdLocalPharmacy,
  MdMedicalServices,
  MdNotes,
  MdOpenInNew,
  MdSearch,
} from 'react-icons/md'
import { doctorClinicLabel } from '../../utils/doctor'
import { formatAppointmentRange, formatDurationMinutes, getReservedDurationMinutes } from '../../utils/appointmentTime'

function formatDate(raw) {
  if (!raw) return '—'
  const [y, m, d] = String(raw).slice(0, 10).split('-').map(Number)
  if (!y || !m || !d) return String(raw)
  return new Date(y, m - 1, d).toLocaleDateString('en-PH', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  })
}

function groupByMonth(items) {
  return items.reduce((acc, item) => {
    const raw = item.appointment_date || item.date || ''
    const [y, m] = raw.slice(0, 7).split('-')
    if (!y || !m) {
      acc.Other = [...(acc.Other || []), item]
      return acc
    }
    const key = new Date(Number(y), Number(m) - 1).toLocaleDateString('en-PH', {
      month: 'long',
      year: 'numeric',
    })
    acc[key] = [...(acc[key] || []), item]
    return acc
  }, {})
}

const ProgressImages = ({ images = [] }) => {
  const list = Array.isArray(images) ? images.filter((image) => image?.image_url) : []

  if (list.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-3 py-6 text-center text-xs text-slate-400">
        No progress images saved for this visit.
      </div>
    )
  }

  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {list.map((image, index) => (
        <a
          key={`${image.image_url}-${index}`}
          href={image.image_url}
          target="_blank"
          rel="noreferrer"
          className="group overflow-hidden rounded-xl border border-slate-200 bg-white"
        >
          <img
            src={image.image_url}
            alt={image.caption || `Progress image ${index + 1}`}
            className="h-36 w-full bg-slate-100 object-cover"
          />
          <div className="flex items-start justify-between gap-2 px-3 py-2.5">
            <div className="min-w-0">
              <p className="text-xs text-slate-600">
                {image.caption || 'Progress image'}
              </p>
              <span className={`mt-2 inline-flex rounded-full px-2 py-0.5 text-[9px] font-bold ${image.security_scan_status === 'approved' ? 'bg-emerald-50 text-emerald-700' : image.security_scan_status === 'bypassed' ? 'bg-amber-50 text-amber-800' : 'bg-slate-100 text-slate-500'}`}>
                {image.security_scan_status === 'approved' ? 'Security scan passed' : image.security_scan_status === 'bypassed' ? 'Not malware scanned' : 'Legacy image'}
              </span>
            </div>
            <MdOpenInNew className="mt-0.5 shrink-0 text-slate-300 transition-colors group-hover:text-slate-500" />
          </div>
        </a>
      ))}
    </div>
  )
}

const VisitCard = ({ visit }) => {
  const [expanded, setExpanded] = useState(false)
  const Icon = visit.type === 'derma' ? MdFace : MdMedicalServices

  let prescriptions = []
  try {
    if (visit.prescription) {
      prescriptions = typeof visit.prescription === 'string'
        ? JSON.parse(visit.prescription)
        : visit.prescription
      if (!Array.isArray(prescriptions)) prescriptions = []
    }
  } catch {
    prescriptions = []
  }

  const progressImages = Array.isArray(visit.progress_images) ? visit.progress_images.filter((image) => image?.image_url) : []
  const statusMeta = {
    completed: { label: 'Completed', badge: 'bg-slate-100 text-slate-500 border-slate-200', card: 'border-slate-200 shadow-sm' },
    cancelled: { label: 'Cancelled', badge: 'bg-red-50 text-red-500 border-red-200', card: 'border-red-100 opacity-70' },
    rejected: { label: 'Rejected', badge: 'bg-violet-50 text-violet-700 border-violet-200', card: 'border-violet-100 bg-violet-50/20' },
    no_show: { label: 'No Show', badge: 'bg-amber-50 text-amber-700 border-amber-200', card: 'border-amber-100 bg-amber-50/20' },
  }[visit.status] || { label: String(visit.status || 'History').replace(/_/g, ' '), badge: 'bg-slate-100 text-slate-500 border-slate-200', card: 'border-slate-200 shadow-sm' }
  const isCancelled = visit.status === 'cancelled'
  const isRejected = visit.status === 'rejected'
  const isCompleted = visit.status === 'completed'
  const hasDetails = isCompleted && (visit.diagnosis || visit.consultation_notes || prescriptions.length > 0 || progressImages.length > 0)

  return (
    <div className={`bg-white rounded-2xl border overflow-hidden transition-all ${statusMeta.card}`}>
      <div className="flex items-start gap-3 p-4">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${visit.type === 'derma' ? 'bg-emerald-50' : 'bg-slate-100'}`}>
          <Icon className={`text-[18px] ${visit.type === 'derma' ? 'text-emerald-600' : 'text-slate-500'}`} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-sm font-bold text-slate-800 truncate">{visit.doctor || visit.doctor_name}</p>
              <p className="text-xs text-slate-400 mt-0.5 truncate">
                {doctorClinicLabel(visit)}{visit.branch_name ? ` · ${visit.branch_name}` : ''}
              </p>
            </div>
            <span className={`text-[10px] font-bold border px-2 py-0.5 rounded-full shrink-0 ${statusMeta.badge}`}>
              {statusMeta.label}
            </span>
          </div>

          <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400 font-medium flex-wrap">
            <span className="flex items-center gap-1">
              <MdCalendarToday className="text-[11px]" />
              {formatDate(visit.appointment_date || visit.date)}
            </span>
            <span className="flex items-center gap-1">
              <MdAccessTime className="text-[11px]" />
              {formatAppointmentRange(visit)}
            </span>
          </div>

          {visit.requested_service_name_snapshot && (
            <p className="mt-1.5 text-[11px] font-semibold text-sky-700">
              {visit.requested_service_name_snapshot} · {formatDurationMinutes(getReservedDurationMinutes(visit))}
            </p>
          )}

          {visit.reason && (
            <p className="text-xs text-slate-500 mt-1.5 bg-slate-50 rounded-lg px-2.5 py-1.5 inline-block">
              {visit.reason}
            </p>
          )}
          {isCancelled && (visit.cancellation_reason_snapshot || visit.cancellation_details) && (
            <div className="mt-2 rounded-xl border border-red-100 bg-red-50 px-3 py-2 text-xs text-red-700">
              <p><span className="font-bold">Reason for cancellation:</span> {visit.cancellation_reason_snapshot || 'Not recorded'}</p>
              {visit.cancellation_details && <p className="mt-1">{visit.cancellation_details}</p>}
            </div>
          )}
          {isRejected && (
            <div className="mt-2 rounded-xl border border-violet-100 bg-violet-50 px-3 py-2 text-xs text-violet-800">
              <p><span className="font-bold">Reason:</span> {visit.rejection_reason === 'confirmation_timeout' ? 'The clinic confirmation deadline passed before Staff confirmed this request.' : (visit.rejection_reason || 'Appointment request was not confirmed.')}</p>
              <p className="mt-1">The requested time was released and can be booked again.</p>
            </div>
          )}
        </div>
      </div>

      {isCompleted && visit.diagnosis && !expanded && (
        <div className="px-4 pb-3">
          <p className="text-xs font-semibold text-slate-700 truncate">
            Dx: <span className="font-normal text-slate-600">{visit.diagnosis}</span>
          </p>
        </div>
      )}

      {isCompleted && progressImages.length > 0 && !expanded && (
        <div className="px-4 pb-3">
          <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-2.5">
            <img
              src={progressImages[0].image_url}
              alt={progressImages[0].caption || 'Progress preview'}
              className="h-16 w-16 rounded-lg object-cover bg-white border border-slate-200"
            />
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Recent Progress</p>
              <p className="mt-1 text-xs text-slate-600 truncate">
                {progressImages[0].caption || `${progressImages.length} saved image${progressImages.length > 1 ? 's' : ''}`}
              </p>
              <p className={`mt-1 text-[9px] font-bold ${progressImages[0].security_scan_status === 'approved' ? 'text-emerald-600' : progressImages[0].security_scan_status === 'bypassed' ? 'text-amber-700' : 'text-slate-400'}`}>
                {progressImages[0].security_scan_status === 'approved' ? 'Security scan passed' : progressImages[0].security_scan_status === 'bypassed' ? 'Not malware scanned' : 'Legacy image'}
              </p>
            </div>
          </div>
        </div>
      )}

      {expanded && isCompleted && hasDetails && (
        <div className="px-4 pb-4 space-y-3 border-t border-slate-100 pt-3">
          {visit.diagnosis && (
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Diagnosis</p>
              <p className="text-sm text-slate-800 bg-slate-50 rounded-xl px-3 py-2 leading-relaxed">
                {visit.diagnosis}
              </p>
            </div>
          )}

          {visit.consultation_notes && (
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                <MdNotes className="text-[11px]" /> Clinical Notes
              </p>
              <p className="text-sm text-slate-600 bg-slate-50 rounded-xl px-3 py-2 leading-relaxed">
                {visit.consultation_notes}
              </p>
            </div>
          )}

          {prescriptions.length > 0 && (
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                <MdLocalPharmacy className="text-[11px]" /> Prescriptions
              </p>
              <div className="space-y-2">
                {prescriptions.map((rx, index) => (
                  <div key={index} className="bg-violet-50 border border-violet-100 rounded-xl px-3 py-2.5">
                    <p className="text-sm font-bold text-violet-800">{rx.medicine}</p>
                    <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-0.5 text-xs text-violet-600">
                      {(rx.quantity ?? rx.dosage) && <span>Quantity: {rx.quantity ?? rx.dosage}{rx.unit_label ? ` ${rx.unit_label}` : ''}</span>}
                      {rx.frequency && <span>Sig: {rx.frequency}</span>}
                      {rx.duration && <span>For: {rx.duration}</span>}
                    </div>
                    {rx.notes && <p className="text-[11px] text-violet-500 mt-0.5 italic">{rx.notes}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {progressImages.length > 0 && (
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                <MdImage className="text-[11px]" /> Progress Images
              </p>
              <ProgressImages images={progressImages} />
            </div>
          )}
        </div>
      )}

      {isCompleted && hasDetails && (
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center justify-center gap-1 py-2.5 text-[11px] font-bold text-slate-400 hover:text-slate-600 hover:bg-slate-50 border-t border-slate-100 transition-colors"
        >
          {expanded
            ? <><MdExpandLess className="text-[14px]" /> Show less</>
            : <><MdExpandMore className="text-[14px]" /> View details</>}
        </button>
      )}
    </div>
  )
}

const History = () => {
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    getMyHistory()
      .then((data) => setHistory(Array.isArray(data) ? data : []))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const filtered = history.filter((visit) => {
    const query = search.toLowerCase()
    return (
      (visit.doctor || visit.doctor_name || '').toLowerCase().includes(query) ||
      (visit.reason || '').toLowerCase().includes(query) ||
      (visit.cancellation_reason_snapshot || '').toLowerCase().includes(query) ||
      (visit.cancellation_details || '').toLowerCase().includes(query) ||
      (visit.diagnosis || '').toLowerCase().includes(query)
    )
  })

  const historyPagination = useClientPagination(filtered, { resetDeps: [search] })
  const grouped = groupByMonth(historyPagination.pageItems)
  const months = Object.keys(grouped)
  const completed = history.filter((visit) => visit.status === 'completed').length
  const cancelled = history.filter((visit) => visit.status === 'cancelled').length
  const rejected = history.filter((visit) => visit.status === 'rejected').length

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div>
        <h1 className="text-xl lg:text-2xl font-bold text-slate-800 flex items-center gap-2">
          <MdHistory className="text-slate-400 text-[22px]" /> Appointment History
        </h1>
        <p className="text-xs lg:text-sm text-slate-400 mt-0.5">
          {history.length} total visits
        </p>
      </div>

      {!loading && history.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 text-center shadow-sm">
            <p className="text-3xl font-black text-emerald-600">{completed}</p>
            <p className="text-xs text-slate-400 font-medium mt-0.5">Completed</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-2xl p-4 text-center shadow-sm">
            <p className="text-3xl font-black text-red-400">{cancelled}</p>
            <p className="text-xs text-slate-400 font-medium mt-0.5">Cancelled</p>
          </div>
          <div className="bg-white border border-violet-200 rounded-2xl p-4 text-center shadow-sm">
            <p className="text-3xl font-black text-violet-600">{rejected}</p>
            <p className="text-xs text-slate-400 font-medium mt-0.5">Rejected</p>
          </div>
        </div>
      )}

      {history.length > 0 && (
        <div className="relative">
          <MdSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-[18px]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by doctor, reason, or diagnosis..."
            className="w-full pl-10 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-sm focus:outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/10 transition-all"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <MdClose className="text-[16px]" />
            </button>
          )}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-slate-200 border-t-emerald-500 rounded-full animate-spin" />
        </div>
      ) : history.length === 0 ? (
        <div className="flex flex-col items-center py-20 text-center bg-white rounded-2xl border border-slate-200">
          <div className="w-16 h-16 rounded-2xl bg-slate-50 flex items-center justify-center mb-4">
            <MdHistory className="text-[28px] text-slate-300" />
          </div>
          <p className="text-sm font-bold text-slate-600 mb-1">No history yet</p>
          <p className="text-xs text-slate-400">Your completed appointments will appear here.</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center bg-white rounded-2xl border border-slate-200">
          <MdSearch className="text-[28px] text-slate-300 mb-2" />
          <p className="text-sm font-bold text-slate-600">No results for &quot;{search}&quot;</p>
        </div>
      ) : (
        <div className="space-y-6">
          {months.map((month) => (
            <div key={month}>
              <div className="flex items-center gap-3 mb-3">
                <div className="h-px flex-1 bg-slate-200" />
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">
                  {month}
                </span>
                <div className="h-px flex-1 bg-slate-200" />
              </div>

              <div className="space-y-3">
                {grouped[month].map((visit, index) => (
                  <VisitCard key={visit.id || index} visit={visit} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      {filtered.length > 0 && <Pagination {...historyPagination} total={filtered.length} />}
    </div>
  )
}

export default History



