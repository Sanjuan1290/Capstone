const fs = require('fs')
const path = require('path')

const root = path.resolve(__dirname, '..', '..', '..')
const read = (...parts) => fs.readFileSync(path.join(root, ...parts), 'utf8')

describe('September 30 consultation workflow UX', () => {
  it('copies selected progress-image files before clearing the browser input and leaves new captions empty', () => {
    const consultation = read('client', 'src', 'pages', 'doctorPage', 'Doctor_Consultation.jsx')
    const portal = read('client', 'src', 'services', 'portal.service.js')
    expect(consultation).toContain('Array.from(e.currentTarget.files || [])')
    expect(consultation).toContain('Upload complete. Security scan passed.')
    expect(consultation).toContain("caption: existing.caption || ''")
    expect(consultation).not.toContain("file?.name?.replace(/\\.[^.]+$/, '')")
    expect(portal).toContain('Clinical image upload failed (HTTP ${response.status}).')
  })

  it('keeps booked service consumables fixed and allows extra quantity of the same inventory item', () => {
    const consultation = read('client', 'src', 'pages', 'doctorPage', 'Doctor_Consultation.jsx')
    const controller = read('server', 'controllers', 'doctor.controller.js')
    const billing = read('server', 'utils', 'billing.js')
    expect(consultation).toContain('Booked Service · Fixed')
    expect(consultation).toContain('Service Consumables · Fixed')
    expect(consultation).toContain('Configured Quantity')
    expect(consultation).toContain('Extra Consumables')
    expect(consultation).toContain('Add Extra Consumable')
    expect(consultation).toContain('existingExtraConsumableIds')
    expect(consultation).toContain('Also in Service Setup')
    expect(consultation).not.toContain('existingConsumableIds')
    expect(controller).toContain('enforceFixedCatalogConsumables')
    expect(controller).toContain('consultation_extra === true')
    expect(controller).toContain('extrasByInventory')
    expect(controller).toContain("'BOOKED_SERVICE_REQUIRED'")
    expect(billing).toContain('{ consultation_extra: true }')
  })

  it('uses Consultation -> Prescriptions navigation and keeps Complete Consultation on the prescription step', () => {
    const consultation = read('client', 'src', 'pages', 'doctorPage', 'Doctor_Consultation.jsx')
    expect(consultation).toContain('Next: Prescriptions →')
    expect(consultation).toContain("setTab('prescriptions')")
    expect(consultation).toContain("{tab === 'prescriptions' && (")
    expect(consultation).toContain("{saving ? 'Completing…' : 'Complete Consultation'}")
  })

  it('requires an explicit prescription decision but medicine entry is free text and not inventory-linked', () => {
    const consultation = read('client', 'src', 'pages', 'doctorPage', 'Doctor_Consultation.jsx')
    const controller = read('server', 'controllers', 'doctor.controller.js')
    const schema = read('server', 'utils', 'schema.js')
    expect(consultation).toContain('No Prescription')
    expect(consultation).toContain('This field is free text and is not connected to Inventory.')
    expect(consultation).toContain('placeholder="e.g. Amoxicillin 500 mg"')
    expect(consultation).not.toContain('SearchableMedicineSelect')
    expect(consultation).not.toContain('Search medicine by name, strength or dosage form...')
    expect(consultation).toContain('prescription_status: prescriptionDecision')
    expect(controller).toContain("'PRESCRIPTION_DECISION_REQUIRED'")
    expect(controller).toContain("'PRESCRIPTION_REQUIRED'")
    expect(controller).not.toContain("inventory_id: item.inventory_id === '__other__'")
    expect(schema).toContain("ensureColumn('consultations', 'prescription_status'")
  })

  it('does not hide zero-stock inventory from extra-consumable documentation', () => {
    const controller = read('server', 'controllers', 'doctor.controller.js')
    const inventoryStart = controller.indexOf('const getInventoryItems')
    const inventoryEnd = controller.indexOf('// ── Supply Requests', inventoryStart)
    const block = controller.slice(inventoryStart, inventoryEnd)
    expect(block).toContain('WHERE i.archived_at IS NULL')
    expect(block).not.toContain('WHERE i.stock > 0')
  })
})



