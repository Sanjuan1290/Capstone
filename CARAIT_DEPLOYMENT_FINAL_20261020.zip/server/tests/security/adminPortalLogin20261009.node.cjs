const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const root = path.resolve(__dirname, '../../../')
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8')
const routes = read('client/src/App.jsx')
const shared = read('client/src/pages/auth/Admin/PortalAdminLogin.jsx')
const branch = read('client/src/pages/auth/Admin/AdminLogin.jsx')
const superadmin = read('client/src/pages/auth/Admin/SuperAdminLogin.jsx')
const controller = read('server/controllers/admin.controller.js')

assert.match(routes, /path='\/admin\/login' element=\{<AdminLogin\s*\/>\}/)
assert.match(routes, /path='\/superadmin\/login' element=\{<SuperAdminLogin\s*\/>\}/)
assert.match(branch, /portal="admin"/)
assert.match(superadmin, /portal="superadmin"/)
console.log('PASS: role-specific login routes and components')

for (const expected of ['Super Admin Sign In', 'Branch Admin Sign In', '/superadmin/forgot-password', '/admin/forgot-password', '6-digit security code', 'Verify & Sign In']) assert.ok(shared.includes(expected), expected)
assert.match(shared, /body: JSON.stringify\(mfaRequired \? \{ code, portal \} : \{ \.\.\.form, portal \}\)/)
assert.match(shared, /navigate\(config.destination, \{ replace: true \}\)/)
console.log('PASS: distinct design, recovery link, login request, and MFA form')

assert.match(controller, /requestedPortal !== actualPortal/)
assert.match(controller, /code: 'WRONG_ADMIN_PORTAL'/)
assert.match(controller, /'superadmin_mfa_pending'/)
assert.match(controller, /decoded\.portal/)
console.log('PASS: server portal validation and separated MFA pending cookies')


