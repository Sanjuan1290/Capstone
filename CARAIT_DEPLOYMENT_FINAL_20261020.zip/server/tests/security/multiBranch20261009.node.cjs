// Dependency-free static source contracts, NOT a replacement for integration tests.
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const root = path.resolve(__dirname, '../../..')
const read = p => fs.readFileSync(path.join(root, p), 'utf8')
const sql = read('server/db/migrations/2026-10-09-multi-branch-foundation.sql')
const routes = read('server/routers/branches.router.js')
const bookings = read('server/controllers/patient.controller.js')
const noShows = read('server/utils/appointments.js')
const client = read('client/src/pages/superAdminPage/BranchPortals.jsx')

test('schema preserves existing tables and introduces explicit physical branches', () => {
  assert.match(sql, /CREATE TABLE IF NOT EXISTS clinic_branches/)
  assert.match(sql, /CREATE TABLE IF NOT EXISTS admin_branch_permissions/)
  assert.match(sql, /CREATE TABLE IF NOT EXISTS branch_booking_settings/)
  assert.match(sql, /UPDATE admins SET account_role='superadmin',branch_id=NULL WHERE id=1/)
  assert.doesNotMatch(sql.split('\n').filter(line=>!line.trim().startsWith('--')).join('\n'), /\bTRUNCATE\b|\bDROP\s+TABLE\b/i)
})
test('branch Admin restricted by persisted branch assignment and permissions', () => {
  assert.match(routes, /branchId!==Number\(req\.adminContext\.branch_id\)/)
  assert.match(routes, /requirePermission\('system_setup'\)/)
  assert.match(routes, /requireSuper/)
  assert.match(routes, /admin_branch_permissions WHERE admin_id=\?/)
})
test('service catalog and branch views constrain reads and writes by branch', () => {
  assert.match(routes, /billing_service_catalog WHERE branch_id=\?/)
  assert.match(routes, /WHERE id=\? AND branch_id=\?/)
  assert.match(routes, /UPDATE billing_service_catalog SET/)
})
test('patient booking explicitly requires branch-owned doctor and service', () => {
  assert.match(bookings, /validatePatientBranch/)
  assert.match(bookings, /FROM doctors WHERE id=\? AND is_active=1 AND branch_id=\?/)
  assert.match(bookings, /FROM billing_service_catalog\s+WHERE id = \? AND branch_id = \?/)
  assert.match(bookings, /appointment_source, branch_id\)/)
})
test('no-show grace uses branch setting and excludes checked-in and walk-ins', () => {
  assert.match(noShows, /LEFT JOIN branch_booking_settings bbs ON bbs.branch_id = a.branch_id/)
  assert.match(noShows, /a.checked_in_at IS NULL/)
  assert.match(noShows, /<> 'walk_in'/)
})
test('UI has separate Super Admin and Branch Admin layouts and usable service toggle', () => {
  assert.match(client, /export const SuperAdminLayout/)
  assert.match(client, /export const BranchAdminLayout/)
  assert.match(client, /role="switch"/)
  assert.match(client, /Reasons for Cancellation/)
  assert.match(client, /No-Show Grace Period/)
})


