const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const root = path.resolve(__dirname, '../../..')
const read = file => fs.readFileSync(path.join(root, file), 'utf8')
test('patient doctor schedules require branch-scoped active doctor', () => {
  const controller=read('server/controllers/patient.controller.js')
  assert.match(controller, /const requirePatientBranchDoctor = async/)
  assert.match(controller, /d\.id = \? AND d\.branch_id = \?/)
  assert.match(controller, /if \(!await requirePatientBranchDoctor\(req, res\)\) return/)
})
test('patient booking service catalog uses SQL branch filter', () => {
  const controller=read('server/controllers/patient.controller.js')
  const billing=read('server/utils/billing.js')
  assert.match(controller, /listBillingCatalog\(\{ clinicType: clinicType \|\| undefined, branchId: branch\.id \}\)/)
  assert.match(billing, /filters\.push\('bsc\.branch_id = \?'\)/)
})
test('booking and rescheduling client carry the branch to doctor schedule lookups', () => {
  const booking=read('client/src/pages/patientPage/BookAppointment.jsx')
  const reschedule=read('client/src/pages/patientPage/ResheduleAppointment.jsx')
  assert.match(booking, /getDoctorSchedule\(form\.doctor\.id, branchId\)/)
  assert.match(reschedule, /getDoctorSchedule\(appt\.doctor_id, appt\.branch_id\)/)
})
test('Branch Admin account self-service is permitted but global legacy operations remain locked', () => {
  const router = read('server/routers/admin.router.js')
  const app = read('client/src/App.jsx')
  assert.match(router, /const auth = \[authenticate\.adminContext\(true\), requireRole\('admin'\), requireLegacySuperAdmin\]/)
  assert.match(router, /router\.post\('\/security\/password\/change', \.\.\.accountAuth/)
  assert.match(router, /router\.get\('\/appointments',\s+\.\.\.auth/)
  assert.match(app, /path='change-password' element=\{<ChangePassword \/>\}/)
})


