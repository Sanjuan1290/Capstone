// server/controllers/staff.controller.js
// FIX 1: getDoctors now returns the 'type' field so Walk-in Queue doctor filter works
// FIX 2: Added updateInventoryItem and deleteInventoryItem
// FIX 3: getPatients returns 'name' alias so AddModal dropdown shows patient names

const { nextInventoryBarcode } = require('../utils/barcodes')
const db           = require('../db/connect')
const bcrypt       = require('bcrypt')
const jwt          = require('jsonwebtoken')
const generateCookie = require('../utils/generateCookie')
const { issueSession, verifySessionToken } = require('../utils/sessionSecurity')
const { makeTemporaryPassword } = require('../utils/securityCrypto')
const { sendAppointmentStatusEmail } = require('../utils/emailService')
const { createNotification, notifyRoles } = require('../utils/notifications')
const { markOverdueAppointments, canMarkNoShow, getBranchNoShowGraceMinutes } = require('../utils/appointments')
const {
  receiveInventoryBatch,
  attachBatchesToInventory,
  consumeInventoryFromLocationByBatches,
  syncInventorySnapshot,
  ensureInventoryLocationAllocations,
} = require('../utils/inventoryBatches')
const { broadcast } = require('../utils/sse')
const { getTodayDateOnly, getCurrentTimeLabel, getClinicDateTimeSql } = require('../utils/date')
const { normalizePhilippinePhone } = require('../utils/phone')
const { validateBirthdate } = require('../utils/patientProfile')
const { sendPatientAppointmentStatusSms } = require('../utils/smsService')
const { getDoctorUnavailableDate, getDoctorUnavailableDates } = require('../utils/doctorAvailability')
const { loadImagesForConsultationIds } = require('../utils/consultationImages')
const {
  collectInventoryUsageFromBillingItems,
  computeBillingTotals,
  getBillingRecordWithItems,
  listBillingCatalog,
  normalizeBillingItems,
  saveBillingItems,
  replaceStaffBillingItems,
} = require('../utils/billing')
const {
  getActiveAppointmentConflict,
  getLastNoShowAppointment,
  makeNoShowWarningResponse,
} = require('../utils/appointmentPolicies')
const { isValidPaymentMethod, requiresPaymentReference, allocateReceiptNumber, calculatePaymentAmounts } = require('../utils/payments')
const { normalizeClinicType } = require('../utils/inventoryLocations')
const { assertCashierOpen } = require('./billingCorrections.controller')
const { isValidQueueStatus, isValidSupplyRequestResolution } = require('../utils/workflowValidation')
const { resolveSupplyTransfer, listSupplyTransferGroups } = require('../utils/supplyTransfers')
const { getAppointmentInventoryReadiness } = require('../utils/inventoryReadiness')
const { applyManualInventoryMovement } = require('../utils/manualInventoryMovement')
const { getWalkInPrecheck, addWalkInVisit } = require('../utils/walkIn')
const { buildDoctorAvailabilitySummary, buildWalkInDoctorAvailability } = require('../utils/doctorAvailabilitySummary')
const { setQueueState } = require('../utils/queueWorkflow')
const { writeAuditLog } = require('../utils/audit')
const { normalizeText, normalizeOptionalText, normalizeNumber, normalizePositiveId, assertPlainObject } = require('../utils/inputValidation')
const { validateAppointmentSlot, getAvailableAppointmentSlots, getAppointmentReservedDuration, withAppointmentSlotLock, assertAppointmentTransition, assertAppointmentMutationApplied } = require('../utils/appointmentSecurity')
const { loadBookingSettings, roundReservedDurationMinutes } = require('../utils/bookingPolicy')
const { expirePendingAppointments } = require('../utils/pendingAppointmentExpiry')
const { listCancellationReasons, resolveCancellationInput } = require('../utils/appointmentCancellation')
const { resolveDiscountForDraft, loadDiscountPreset } = require('../utils/billingSecurity')
const { loadStaffPermissions } = require('../utils/staffPermissions')
const { withSystemOtherVisitReason } = require('../utils/appointmentReasons')
const { verifyUploadSecurityToken } = require('../utils/cloudinarySecurity')

const makeTempPassword = () => makeTemporaryPassword(14)
const toDateOnly = (value) => String(value || '').trim().slice(0, 10)
const isValidDateOnly = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value)
const NORMALIZED_PHONE_SQL = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, '+', ''), '-', ''), ' ', ''), '(', ''), ')', '')"

const normalizeInventoryPayload = (body = {}) => {
  const category = ['medical','derma'].includes(String(body.category || '').trim()) ? String(body.category).trim() : 'medical'
  const itemType = ['medicine','supplies'].includes(String(body.item_type || '').trim()) ? String(body.item_type).trim() : 'supplies'
  const uom = 'unit'
  const rawMeasurementValue = body.measurement_value
  const measurementValue = rawMeasurementValue === '' || rawMeasurementValue === null || rawMeasurementValue === undefined ? null : Number(rawMeasurementValue)
  const measurementUnit = String(body.measurement_unit || '').trim() || null
  const legacyStrength = String(body.strength || '').trim() || null
  const structuredStrength = Number.isFinite(measurementValue) && measurementValue > 0 && measurementUnit ? `${Number(measurementValue)} ${measurementUnit}` : null
  return {
    barcode: String(body.barcode || '').trim() || null,
    name: String(body.name || '').trim(),
    category,
    item_type: itemType,
    uom,
    dosage_form: null,
    strength: structuredStrength || legacyStrength,
    measurement_value: Number.isFinite(measurementValue) && measurementValue > 0 ? measurementValue : null,
    measurement_unit: measurementUnit,
    unit: uom,
    base_unit: uom,
    unit_size: 1,
    stock: Math.max(0, Number(body.stock) || 0),
    threshold: Math.max(0, Number(body.threshold) || 0),
    price: Math.max(0, Number(body.price) || 0),
    selling_price: body.selling_price === '' || body.selling_price === null || body.selling_price === undefined ? null : Math.max(0, Number(body.selling_price) || 0),
    supplier: String(body.supplier || '').trim() || null,
    supplier_id: Number(body.supplier_id) || null,
    expiration_date: body.expiration_date || null,
    batch_code: String(body.batch_code || '').trim() || null,
    batch_lot_code: String(body.batch_lot_code || '').trim().replace(/^-+/, '') || null,
    supplier_lot_number: String(body.supplier_lot_number || '').trim() || null,
    location_type_id: Number(body.location_type_id) || null,
    storage_location_id: Number(body.storage_location_id) || null,
    storage_location: String(body.storage_location || '').trim() || null,
  }
}


const validateInventoryRequiredFields = (body = {}, { requireOpeningQuantity = false, requireSellingPrice = true } = {}) => {
  try {
    assertPlainObject(body)
    normalizeText(body.name, { field: 'Item Name', required: true, max: 150 })
    if (body.barcode !== undefined && body.barcode !== null && body.barcode !== '') normalizeText(body.barcode, { field: 'Product Barcode', max: 50 })
    const measurementValueProvided = body.measurement_value !== undefined && body.measurement_value !== null && body.measurement_value !== ''
    const measurementUnitProvided = String(body.measurement_unit || '').trim().length > 0
    if (measurementValueProvided !== measurementUnitProvided) {
      const error = new Error('Enter both Strength / Size and Measurement Unit, or leave both blank.')
      error.code = 'INVENTORY_MEASUREMENT_INCOMPLETE'
      error.field = measurementValueProvided ? 'measurement_unit' : 'measurement_value'
      throw error
    }
    if (measurementValueProvided) normalizeNumber(body.measurement_value, { field: 'Strength / Size', required: true, min: 0.0001, max: 99999999.9999 })
    if (measurementUnitProvided) normalizeText(body.measurement_unit, { field: 'Measurement Unit', required: true, max: 30 })
    normalizeNumber(body.threshold, { field: 'Low Stock Alert', required: true, min: 0, max: 9999999999 })
    if (requireSellingPrice) normalizeNumber(body.selling_price, { field: 'Selling Price', required: true, min: 0.01, max: 99999999.99 })
    if (requireOpeningQuantity) normalizeNumber(body.stock, { field: 'Opening Quantity', required: true, min: 0, max: 9999999999 })
  } catch (err) {
    return { message: err.message, code: err.code || 'VALIDATION_ERROR', field: err.field || null }
  }
  const name = String(body.name || '').trim()
  const category = String(body.category || '').trim()
  const itemType = String(body.item_type || '').trim()
  const locationTypeId = Number(body.location_type_id)
  const supplierId = Number(body.supplier_id) || null
  const thresholdRaw = body.threshold
  const sellingPrice = Number(body.selling_price)

  if (!name) return { message: 'Item Name is required.', code: 'INVENTORY_NAME_REQUIRED' }
  if (!['medical', 'derma'].includes(category)) return { message: 'Select a valid Category.', code: 'INVENTORY_CATEGORY_REQUIRED' }
  if (!['medicine', 'supplies'].includes(itemType)) return { message: 'Select a valid Type.', code: 'INVENTORY_TYPE_REQUIRED' }
  if (!locationTypeId) return { message: 'Storage Location is required.', code: 'INVENTORY_LOCATION_TYPE_REQUIRED' }
  if (!supplierId) return { message: 'Supplier is required.', code: 'INVENTORY_SUPPLIER_REQUIRED' }
  if (thresholdRaw === '' || thresholdRaw === null || thresholdRaw === undefined || !Number.isFinite(Number(thresholdRaw)) || Number(thresholdRaw) < 0 || !Number.isInteger(Number(thresholdRaw))) {
    return { message: 'Low Stock Alert is required and must be a whole number of 0 or greater.', code: 'INVENTORY_THRESHOLD_REQUIRED' }
  }
  if (requireSellingPrice && (!Number.isFinite(sellingPrice) || sellingPrice <= 0)) {
    return { message: 'Selling Price is required and must be greater than ₱0.00.', code: 'INVENTORY_SELLING_PRICE_REQUIRED' }
  }

  if (requireOpeningQuantity) {
    if (body.stock === '' || body.stock === null || body.stock === undefined || !Number.isFinite(Number(body.stock)) || Number(body.stock) < 0 || !Number.isInteger(Number(body.stock))) {
      return { message: 'Opening Quantity is required and must be a whole number of 0 or greater.', code: 'INVENTORY_OPENING_QUANTITY_REQUIRED' }
    }
    if (Number(body.stock) > 0) {
      const noExpiry = body.no_expiry === true || body.no_expiry === 1 || String(body.no_expiry || '').toLowerCase() === 'true'
      if (itemType === 'medicine' && !String(body.expiration_date || '').trim()) {
        return { message: 'Batch Expiry is required for medicines.', code: 'INVENTORY_EXPIRY_REQUIRED' }
      }
      if (itemType === 'supplies' && !noExpiry && !String(body.expiration_date || '').trim()) {
        return { message: 'Enter the Batch Expiry or select “No expiry / Not applicable”.', code: 'INVENTORY_EXPIRY_REQUIRED' }
      }
    }
  }

  return null
}

const hasStaffPricingMutation = (body = {}) => ['selling_price', 'price'].some((key) => (
  Object.prototype.hasOwnProperty.call(body || {}, key)
  && body[key] !== undefined
  && body[key] !== null
  && body[key] !== ''
))

const rejectStaffPricingMutation = (req, res) => {
  if (!hasStaffPricingMutation(req.body)) return false
  res.status(403).json({ code: 'ADMIN_PRICING_REQUIRED', message: 'Only Admin can change inventory Selling Price.' })
  return true
}

const resolveInventorySetupSelection = async ({ location_type_id, branchId }, executor = db) => {
  const locationTypeId = Number(location_type_id)
  if (!locationTypeId) {
    const error = new Error('Select a Storage Location configured in System Setup.')
    error.statusCode = 400
    error.code = 'INVENTORY_LOCATION_TYPE_REQUIRED'
    throw error
  }
  const [[locationType]] = await executor.query(
    'SELECT id,name,code FROM inventory_location_types WHERE id=? AND branch_id=? AND is_active=1 LIMIT 1',
    [locationTypeId,branchId]
  )
  if (!locationType) {
    const error = new Error('That Storage Location is unavailable. Configure an active Storage Location in System Setup.')
    error.statusCode = 400
    error.code = 'INVENTORY_LOCATION_TYPE_INVALID'
    throw error
  }

  return {
    uom: 'unit',
    locationType,
  }
}


const buildPhoneSearchTerms = (value = '') => {
  const trimmed = String(value || '').trim()
  const digits = trimmed.replace(/\D/g, '')
  const normalizedPhone = normalizePhilippinePhone(trimmed)
  const localPhone = normalizedPhone
    ? `0${normalizedPhone.slice(2)}`
    : digits.startsWith('63') && digits.length >= 12
      ? `0${digits.slice(2)}`
      : digits.startsWith('9') && digits.length >= 10
        ? `0${digits}`
        : null

  return {
    likeSearch: `%${trimmed}%`,
    phoneSearch: `%${normalizedPhone || digits || trimmed}%`,
    altPhoneSearch: `%${localPhone || digits || trimmed}%`,
  }
}

const findExistingPatientByPhone = async (phone) => {
  const normalizedPhone = normalizePhilippinePhone(phone)
  if (!normalizedPhone) return { normalizedPhone: null, existing: null }

  const localPhone = `0${normalizedPhone.slice(2)}`
  const [rows] = await db.query(
    `SELECT id, full_name, phone
     FROM patients
     WHERE ${NORMALIZED_PHONE_SQL} IN (?, ?)
     LIMIT 1`,
    [normalizedPhone, localPhone]
  )

  return {
    normalizedPhone,
    existing: rows[0] || null,
  }
}

const loadInventoryRows = async (executor = db, whereClause = '', params = []) => {
  const [rows] = await executor.query(
    `SELECT i.*, lt.name AS location_type_name, lt.code AS location_type_code,
            COALESCE(u.allow_decimal_quantity,0) AS uom_allow_decimal
     FROM (
       SELECT *
       FROM inventory
       ${whereClause}
     ) i
     LEFT JOIN inventory_location_types lt ON lt.id = i.location_type_id
     LEFT JOIN inventory_uoms u ON LOWER(u.name)=LOWER(COALESCE(i.uom,i.base_unit,i.unit,''))
     ORDER BY
       CASE WHEN i.expiration_date IS NULL THEN 1 ELSE 0 END,
       i.expiration_date ASC,
       i.category ASC,
       i.name ASC`,
    params
  )
  return attachBatchesToInventory(rows, executor)
}

// ── Auth ──────────────────────────────────────────────────────────────────────

const login = async (req, res) => {
  const { email, password } = req.body
  if (!email || !password)
    return res.status(400).json({ message: 'Email and password are required.' })

  const [rows] = await db.query("SELECT * FROM staff WHERE email = ? AND status = 'active'", [email])
  if (rows.length === 0) {
    await writeAuditLog({ userRole: 'staff', action: 'auth.login_failed', entityType: 'staff', newValues: { reason: 'invalid_credentials' }, ipAddress: req.ip || null }).catch(() => {})
    return res.status(401).json({ message: 'Invalid email or password.' })
  }

  const staff = rows[0]
  const match = await bcrypt.compare(password, staff.password)
  if (!match) {
    await writeAuditLog({ userId: staff.id, userRole: 'staff', action: 'auth.login_failed', entityType: 'staff', entityId: staff.id, newValues: { reason: 'invalid_credentials' }, ipAddress: req.ip || null }).catch(() => {})
    return res.status(401).json({ message: 'Invalid email or password.' })
  }

  await issueSession(res, 'staff', staff.id)
  await writeAuditLog({ userId: staff.id, userRole: 'staff', action: 'auth.login_success', entityType: 'staff', entityId: staff.id, ipAddress: req.ip || null }).catch(() => {})

  const permissions = await loadStaffPermissions(staff.id)
  res.status(200).json({
    message: 'Login successful.',
    user: { id: staff.id, full_name: staff.full_name, email: staff.email, role: 'staff', theme_preference: staff.theme_preference, profile_image_url: staff.profile_image_url, must_change_password: Boolean(staff.must_change_password), permissions },
  })
}

const checkAuth = async (req, res) => {
  const token = req.cookies['staff_token']
  if (!token) return res.status(200).json({ authenticated: false })
  try {
    const decoded = await verifySessionToken(token, 'staff')
    const [rows] = await db.query(
      "SELECT a.id,a.full_name,a.email,a.theme_preference,a.profile_image_url,a.must_change_password,a.password_changed_at,a.branch_id,b.name AS branch_name FROM staff a JOIN clinic_branches b ON b.id=a.branch_id AND b.is_active=1 WHERE a.id = ? AND a.status = 'active'", [decoded.id]
    )
    if (rows.length === 0) return res.status(200).json({ authenticated: false })
    const permissions = await loadStaffPermissions(decoded.id)
    res.status(200).json({ authenticated: true, user: { ...rows[0], role: 'staff', permissions } })
  } catch {
    res.status(200).json({ authenticated: false })
  }
}

const logout = async (req, res) => {
  await writeAuditLog({ userId: req.user?.id || null, userRole: 'staff', action: 'auth.logout', entityType: 'staff', entityId: req.user?.id || null, ipAddress: req.ip || null }).catch(() => {})
  res.clearCookie('staff_token', { path: '/' })
  res.status(200).json({ message: 'Logged out.' })
}

// ── Dashboard ─────────────────────────────────────────────────────────────────

const getDashboard = async (req, res) => {
  const today = getTodayDateOnly()
  const [[{ totalToday }]] = await db.query('SELECT COUNT(*) AS totalToday FROM appointments WHERE branch_id=? AND appointment_date=?',[req.branchId,today])
  const [[{ pendingCount }]] = await db.query("SELECT COUNT(*) AS pendingCount FROM appointments WHERE branch_id=? AND status='pending'",[req.branchId])
  const [[{ queueCount }]] = await db.query("SELECT COUNT(*) AS queueCount FROM queue WHERE branch_id=? AND queue_date=? AND status IN ('waiting','called','in_consultation')",[req.branchId,today])
  const [[{ lowStock }]] = await db.query('SELECT COUNT(*) AS lowStock FROM inventory WHERE branch_id=? AND archived_at IS NULL AND stock<=threshold',[req.branchId])
  const [[{ totalPatients }]] = await db.query('SELECT COUNT(DISTINCT patient_id) AS totalPatients FROM appointments WHERE branch_id=?',[req.branchId])
  res.json({totalToday,pendingCount,queueCount,lowStock,totalPatients})
}

// ── Appointments ──────────────────────────────────────────────────────────────

const getAppointments = async (req, res) => {
  await expirePendingAppointments().catch(() => {})
  const { date } = req.query
  const requestedSort = String(req.query.sort || '')
  const sort = ['visit_time', 'created_at', 'updated_at'].includes(requestedSort) ? requestedSort : (date ? 'visit_time' : 'created_at')
  const requestedDirection = String(req.query.direction || '').toLowerCase()
  const direction = requestedDirection === 'asc' ? 'ASC' : requestedDirection === 'desc' ? 'DESC' : (sort === 'visit_time' ? 'ASC' : 'DESC')
  let sql = `SELECT
               a.*,
               DATE_FORMAT(a.appointment_date, '%Y-%m-%d') AS date,
               a.appointment_time AS time,
               a.clinic_type      AS type,
               p.full_name        AS patient_name,
               p.full_name        AS patient,
               p.email            AS patient_email,
               p.phone            AS patient_phone,
               DATE_FORMAT(p.birthdate, '%Y-%m-%d') AS patient_birthdate,
               p.sex              AS patient_sex,
               p.address          AS patient_address,
               d.full_name        AS doctor,
               d.specialty
             FROM appointments a
             JOIN patients p ON a.patient_id = p.id
             JOIN doctors  d ON a.doctor_id  = d.id`
  const params = [req.branchId]
  sql += ' WHERE a.branch_id = ? AND d.branch_id = a.branch_id'
  if (date) {sql += ' AND a.appointment_date = ?';params.push(date)}
  if (sort === 'created_at') sql += ` ORDER BY a.created_at ${direction}, a.id ${direction}`
  else if (sort === 'updated_at') sql += ` ORDER BY a.updated_at ${direction}, a.id ${direction}`
  else sql += ` ORDER BY a.appointment_date ${direction}, STR_TO_DATE(a.appointment_time, '%h:%i %p') ${direction}, a.id ${direction}`
  const [rows] = await db.query(sql, params)
  res.json(rows)
}

const createAppointment = async (req, res) => {
  const { patient_id, doctor_id, clinic_type, requested_service_id, reason, appointment_date, appointment_time, notes } = req.body
  if (!patient_id || !doctor_id || !clinic_type || !requested_service_id || !appointment_date || !appointment_time) {
    return res.status(400).json({ message: 'Patient, doctor, clinic, service, date, and time are required.' })
  }
  const normalizedDate = toDateOnly(appointment_date)
  if (!isValidDateOnly(normalizedDate)) return res.status(400).json({ message: 'Invalid appointment date.' })
  if (normalizedDate < getTodayDateOnly()) return res.status(400).json({ message: 'Cannot create an appointment in the past.' })

  const [[service]] = await db.query(
    `SELECT id, service_name, clinic_type, default_price, average_duration_minutes, is_active
     FROM billing_service_catalog WHERE id = ? AND branch_id=? LIMIT 1`, [requested_service_id, req.branchId])
  if (!service || Number(service.is_active) !== 1 || ![clinic_type, 'all'].includes(String(service.clinic_type || ''))) {
    return res.status(409).json({ message: 'Select an active service for the selected clinic.' })
  }
  const settings = await loadBookingSettings(db, req.branchId)
  const averageDurationMinutes = Number(service.average_duration_minutes || 60)
  const reservedDurationMinutes = roundReservedDurationMinutes(averageDurationMinutes, settings.booking_start_interval_minutes)

  const lastNoShow = await getLastNoShowAppointment(patient_id)
  if (lastNoShow && !req.body?.override_no_show_warning) return res.status(409).json(makeNoShowWarningResponse(lastNoShow))

  const [activeWithDoctor] = await db.query(
    `SELECT id FROM appointments WHERE patient_id = ? AND doctor_id = ? AND status IN ('pending','confirmed','rescheduled','in-progress') LIMIT 1`,
    [patient_id, doctor_id]
  )
  if (activeWithDoctor.length) return res.status(409).json({ message: 'This patient already has an active appointment with this doctor.' })

  const [[doctorBranch]] = await db.query('SELECT id FROM doctors WHERE id=? AND branch_id=? AND is_active=1 LIMIT 1', [doctor_id, req.branchId])
  if (!doctorBranch) return res.status(404).json({ message: 'Doctor not found in your branch.' })
  const result = await withAppointmentSlotLock({ doctorId: doctor_id }, async () => {
    await validateAppointmentSlot({ doctorId: doctor_id, clinicType: clinic_type, date: normalizedDate, time: appointment_time, durationMinutes: reservedDurationMinutes, startIntervalMinutes: settings.booking_start_interval_minutes })
    const [inserted] = await db.query(
      `INSERT INTO appointments
       (patient_id, doctor_id, clinic_type, requested_service_id, requested_service_name_snapshot, requested_service_price_snapshot,
        requested_service_duration_minutes_snapshot, reserved_duration_minutes_snapshot,
        reason, appointment_date, appointment_time, notes, appointment_source, branch_id)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [patient_id, doctor_id, clinic_type, service.id, service.service_name, service.default_price,
       averageDurationMinutes, reservedDurationMinutes, reason || null, normalizedDate, appointment_time, notes || null, 'staff_booking', req.branchId]
    )
    return inserted
  })
  await writeAuditLog({ branchId:req.branchId,userId:req.user.id,userRole:'staff',action:'appointment.created',entityType:'appointment',entityId:result.insertId,newValues:{patient_id,doctor_id,clinic_type,requested_service_id:Number(service.id),requested_service_name:service.service_name,appointment_date:normalizedDate,appointment_time,appointment_source:'staff_booking',reserved_duration_minutes:reservedDurationMinutes},ipAddress:req.ip||null })
  const [rows] = await db.query(`SELECT p.full_name AS patient_name,d.id AS doctor_id,d.full_name AS doctor_name,d.phone AS doctor_phone FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN doctors d ON a.doctor_id=d.id WHERE a.id=?`,[result.insertId])
  await notifyRoles(['admin','staff'],{type:'appointment_booked',title:'New patient booking',message:`${rows[0].patient_name} booked an appointment with ${rows[0].doctor_name} on ${normalizedDate} at ${appointment_time}.`,reference_type:'appointment',reference_id:result.insertId})
  broadcast(['admin','staff'],'appointment_updated',{appointmentId:result.insertId,status:'pending'}, { branchId: req.branchId })
  res.status(201).json({ message:'Appointment created.', id:result.insertId })
}

const getAppointmentInventoryReadinessForPortal = async (req, res) => {
  const readiness = await getAppointmentInventoryReadiness(req.params.id, { branchId: req.branchId })
  if (!readiness) return res.status(404).json({ message: 'Appointment not found.' })
  res.json(readiness)
}

const confirmAppointment = async (req, res) => {
  await expirePendingAppointments({ appointmentId: req.params.id }).catch(() => {})
  const [rows] = await db.query(
    `SELECT a.id, a.status, a.appointment_date, a.appointment_time, a.clinic_type,
            p.id AS patient_id, p.email AS patient_email, p.phone AS patient_phone, p.full_name AS patient_name,
            d.id AS doctor_id, d.full_name AS doctor_name
     FROM appointments a
     JOIN patients p ON a.patient_id = p.id
     JOIN doctors d ON a.doctor_id = d.id
     WHERE a.id = ?`,
    [req.params.id]
  )
  if (rows.length === 0) return res.status(404).json({ message: 'Not found.' })
  const lastNoShow = await getLastNoShowAppointment(rows[0].patient_id)
  if (lastNoShow && !req.body?.override_no_show_warning) {
    return res.status(409).json(makeNoShowWarningResponse(lastNoShow))
  }
  assertAppointmentTransition(rows[0].status, 'confirmed')
  const [updated] = await db.query("UPDATE appointments SET status = 'confirmed', confirmation_deadline_at = NULL WHERE id = ? AND status = ?", [req.params.id, rows[0].status])
  await assertAppointmentMutationApplied(updated, req.params.id)
  await writeAuditLog({userId:req.user.id,userRole:'staff',action:'appointment.confirmed',entityType:'appointment',entityId:req.params.id,oldValues:{status:rows[0].status},newValues:{status:'confirmed'},ipAddress:req.ip||null}).catch(() => {})
  await createNotification({
    target_role: 'patient',
    target_user_id: rows[0].patient_id,
    type: 'appointment_confirmed',
    title: 'Appointment confirmed',
    message: `Your appointment with ${rows[0].doctor_name} has been confirmed.`,
    reference_type: 'appointment',
    reference_id: req.params.id,
  })
  await createNotification({
    target_role: 'doctor',
    target_user_id: rows[0].doctor_id,
    type: 'appointment_confirmed',
    title: 'Confirmed appointment',
    message: `${rows[0].patient_name} has a confirmed appointment on ${rows[0].appointment_date} at ${rows[0].appointment_time}.`,
    reference_type: 'appointment',
    reference_id: req.params.id,
  })

  await sendAppointmentStatusEmail({
    to: rows[0].patient_email,
    patient_name: rows[0].patient_name,
    doctor_name: rows[0].doctor_name,
    appointment_date: rows[0].appointment_date,
    appointment_time: rows[0].appointment_time,
    clinic_type: rows[0].clinic_type,
    status: 'confirmed',
  }).catch(() => {})
  await sendPatientAppointmentStatusSms({
    patientId: rows[0].patient_id,
    patientPhone: rows[0].patient_phone,
    patientName: rows[0].patient_name,
    doctorName: rows[0].doctor_name,
    appointmentDate: rows[0].appointment_date,
    appointmentTime: rows[0].appointment_time,
    status: 'confirmed',
  }).catch((err) => {
    console.error('SMS patient appointment confirmation failed:', err.message)
  })
  if (lastNoShow) {
    await createNotification({
      target_role: 'patient',
      target_user_id: rows[0].patient_id,
      type: 'appointment_policy_warning',
      title: 'Appointment policy reminder',
      message: 'Please arrive on time or cancel ahead if you cannot attend. Repeated no-shows or fake bookings may be cancelled by the clinic.',
      reference_type: 'appointment',
      reference_id: req.params.id,
    })
  }
  broadcast(['admin', 'staff', `doctor_${rows[0].doctor_id}`, `patient_${rows[0].patient_id}`], 'appointment_updated', { appointmentId: Number(req.params.id), status: 'confirmed' }, { branchId: req.branchId })
  res.json({ message: 'Appointment confirmed.' })
}

const cancelAppointment = async (req, res) => {
  const [rows] = await db.query(
    `SELECT a.id, a.status, a.appointment_date, a.appointment_time, a.clinic_type, a.branch_id,
            p.id AS patient_id, p.email AS patient_email, p.phone AS patient_phone, p.full_name AS patient_name,
            d.id AS doctor_id, d.full_name AS doctor_name
     FROM appointments a
     JOIN patients p ON a.patient_id = p.id
     JOIN doctors d ON a.doctor_id = d.id
     WHERE a.id = ?`,
    [req.params.id]
  )
  if (rows.length === 0) return res.status(404).json({ message: 'Not found.' })
  const [[staffBranch]] = await db.query('SELECT branch_id FROM staff WHERE id=? LIMIT 1', [req.user.id])
  if (!staffBranch || Number(staffBranch.branch_id) !== Number(rows[0].branch_id)) return res.status(404).json({ message: 'Appointment not found in your branch.' })
  const cancellation = await resolveCancellationInput(req.body, db, rows[0].branch_id)
  assertAppointmentTransition(rows[0].status, 'cancelled')
  const [updated] = await db.query(
    `UPDATE appointments
     SET status = 'cancelled', cancellation_reason_id = ?, cancellation_reason_snapshot = ?,
         cancellation_details = ?, cancelled_by_role = 'staff', cancelled_by_user_id = ?, cancelled_at = NOW()
     WHERE id = ? AND status = ?`,
    [cancellation.cancellation_reason_id, cancellation.cancellation_reason_snapshot, cancellation.cancellation_details, req.user.id, req.params.id, rows[0].status]
  )
  await assertAppointmentMutationApplied(updated, req.params.id)
  await writeAuditLog({userId:req.user.id,userRole:'staff',action:'appointment.cancelled',entityType:'appointment',entityId:req.params.id,oldValues:{status:rows[0].status},newValues:{status:'cancelled',...cancellation},ipAddress:req.ip||null}).catch(() => {})
  await createNotification({
    target_role: 'patient',
    target_user_id: rows[0].patient_id,
    type: 'appointment_cancelled',
    title: 'Appointment cancelled',
    message: `Your appointment with ${rows[0].doctor_name} has been cancelled. Reason: ${cancellation.cancellation_reason_snapshot}.`,
    reference_type: 'appointment',
    reference_id: req.params.id,
  })
  await sendAppointmentStatusEmail({
    to: rows[0].patient_email,
    patient_name: rows[0].patient_name,
    doctor_name: rows[0].doctor_name,
    appointment_date: rows[0].appointment_date,
    appointment_time: rows[0].appointment_time,
    clinic_type: rows[0].clinic_type,
    status: 'cancelled',
  }).catch(() => {})
  await sendPatientAppointmentStatusSms({
    patientId: rows[0].patient_id,
    patientPhone: rows[0].patient_phone,
    patientName: rows[0].patient_name,
    doctorName: rows[0].doctor_name,
    appointmentDate: rows[0].appointment_date,
    appointmentTime: rows[0].appointment_time,
    status: 'cancelled',
  }).catch((err) => console.error('SMS patient appointment cancellation failed:', err.message))
  broadcast(['admin', 'staff', `doctor_${rows[0].doctor_id}`, `patient_${rows[0].patient_id}`], 'appointment_updated', { appointmentId: Number(req.params.id), status: 'cancelled' }, { branchId: req.branchId })
  res.json({ message: 'Appointment cancelled.', cancellation })
}

const markAppointmentNoShow = async (req, res) => {
  const [rows] = await db.query(
    `SELECT a.id, a.status, a.appointment_date, a.appointment_time, a.checked_in_at, a.branch_id,
            p.id AS patient_id, p.full_name AS patient_name, p.phone AS patient_phone,
            d.full_name AS doctor_name
     FROM appointments a
     JOIN patients p ON a.patient_id = p.id
     JOIN doctors d ON a.doctor_id = d.id
     WHERE a.id = ?`,
    [req.params.id]
  )
  if (rows.length === 0) return res.status(404).json({ message: 'Not found.' })
  if (!['confirmed', 'rescheduled'].includes(rows[0].status)) {
    return res.status(400).json({ message: 'Only confirmed or rescheduled appointments can be marked as no show.' })
  }
  rows[0].no_show_grace_minutes = await getBranchNoShowGraceMinutes(rows[0].branch_id)
  if (!canMarkNoShow(rows[0])) return res.status(409).json({ code: 'NO_SHOW_GRACE_PERIOD', message: `Wait until ${rows[0].no_show_grace_minutes} minutes after the appointment start and check that the patient has not arrived.` })
  assertAppointmentTransition(rows[0].status, 'no_show')
  const [updated] = await db.query("UPDATE appointments SET status = 'no_show' WHERE id = ? AND status = ?", [req.params.id, rows[0].status])
  await assertAppointmentMutationApplied(updated, req.params.id)
  await writeAuditLog({userId:req.user.id,userRole:'staff',action:'appointment.no_show',entityType:'appointment',entityId:req.params.id,oldValues:{status:rows[0].status},newValues:{status:'no_show'},ipAddress:req.ip||null}).catch(() => {})
  await createNotification({
    target_role: 'patient',
    target_user_id: rows[0].patient_id,
    type: 'appointment_no_show',
    title: 'Appointment marked as no show',
    message: 'Your appointment was marked as no show.',
    reference_type: 'appointment',
    reference_id: req.params.id,
  })
  broadcast(['admin', 'staff', `patient_${rows[0].patient_id}`], 'appointment_updated', { appointmentId: Number(req.params.id), status: 'no_show' }, { branchId: req.branchId })
  res.json({ message: 'Appointment marked as no show.' })
}

const rescheduleAppointment = async (req, res) => {
  await expirePendingAppointments({ appointmentId: req.params.id }).catch(() => {})
  const { appointment_date, appointment_time } = req.body
  if (!appointment_date || !appointment_time) return res.status(400).json({ message: 'Date and time required.' })
  const normalizedDate = toDateOnly(appointment_date)
  if (!isValidDateOnly(normalizedDate)) return res.status(400).json({ message: 'Invalid appointment date.' })
  if (normalizedDate < getTodayDateOnly()) return res.status(400).json({ message: 'Cannot reschedule to a past date.' })
  const [rows] = await db.query(
    `SELECT a.id,a.doctor_id,a.status,a.clinic_type,a.reserved_duration_minutes_snapshot,a.requested_service_duration_minutes_snapshot,
            p.id AS patient_id,p.email AS patient_email,p.phone AS patient_phone,p.full_name AS patient_name,d.full_name AS doctor_name
     FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN doctors d ON a.doctor_id=d.id WHERE a.id=?`,
    [req.params.id]
  )
  if (!rows.length) return res.status(404).json({ message: 'Not found.' })
  if (!['pending','confirmed','rescheduled'].includes(rows[0].status)) return res.status(400).json({ message:'Only pending, confirmed, or rescheduled appointments can be rescheduled.' })
  const settings=await loadBookingSettings()
  const durationMinutes=getAppointmentReservedDuration(rows[0])
  assertAppointmentTransition(rows[0].status,'rescheduled')
  await withAppointmentSlotLock({doctorId:rows[0].doctor_id},async()=>{
    await validateAppointmentSlot({doctorId:rows[0].doctor_id,clinicType:rows[0].clinic_type,date:normalizedDate,time:appointment_time,durationMinutes,startIntervalMinutes:settings.booking_start_interval_minutes,excludeAppointmentId:req.params.id})
    const [updated]=await db.query("UPDATE appointments SET appointment_date=?,appointment_time=?,status='confirmed',confirmation_deadline_at=NULL WHERE id=? AND status=?",[normalizedDate,appointment_time,req.params.id,rows[0].status])
    await assertAppointmentMutationApplied(updated,req.params.id)
  })
  await writeAuditLog({userId:req.user.id,userRole:'staff',action:'appointment.rescheduled',entityType:'appointment',entityId:req.params.id,oldValues:{status:rows[0].status},newValues:{status:'confirmed',appointment_date:normalizedDate,appointment_time,duration_minutes:durationMinutes},ipAddress:req.ip||null}).catch(()=>{})
  await createNotification({target_role:'patient',target_user_id:rows[0].patient_id,type:'appointment_rescheduled',title:'Appointment rescheduled',message:`Your appointment with ${rows[0].doctor_name} was moved to ${normalizedDate} at ${appointment_time}.`,reference_type:'appointment',reference_id:req.params.id})
  await sendAppointmentStatusEmail({to:rows[0].patient_email,patient_name:rows[0].patient_name,doctor_name:rows[0].doctor_name,appointment_date:normalizedDate,appointment_time,clinic_type:rows[0].clinic_type,status:'rescheduled'}).catch(()=>{})
  await sendPatientAppointmentStatusSms({patientId:rows[0].patient_id,patientPhone:rows[0].patient_phone,patientName:rows[0].patient_name,doctorName:rows[0].doctor_name,appointmentDate:normalizedDate,appointmentTime:appointment_time,status:'rescheduled'}).catch((err)=>console.error('SMS patient appointment reschedule failed:',err.message))
  broadcast(['admin','staff',`patient_${rows[0].patient_id}`],'appointment_updated',{appointmentId:Number(req.params.id),status:'confirmed'}, { branchId: req.branchId })
  res.json({message:'Appointment rescheduled.'})
}

const getAppointmentAvailableSlotsForStaff = async (req, res) => {
  const date = toDateOnly(req.query.date)
  if (!isValidDateOnly(date)) return res.status(400).json({ message: 'A valid date is required.' })
  const doctorId = Number(req.params.id)
  const appointmentId = Number(req.query.appointment_id)
  const settings = await loadBookingSettings()
  let clinicType = String(req.query.clinic_type || '').trim()
  let durationMinutes = 60
  let excludeAppointmentId = null
  if (appointmentId > 0) {
    const [[appointment]] = await db.query(`SELECT doctor_id,clinic_type,reserved_duration_minutes_snapshot,requested_service_duration_minutes_snapshot FROM appointments WHERE id=? LIMIT 1`,[appointmentId])
    if (!appointment || Number(appointment.doctor_id)!==doctorId) return res.status(404).json({ message:'Appointment not found for this doctor.' })
    clinicType=appointment.clinic_type
    durationMinutes=getAppointmentReservedDuration(appointment)
    excludeAppointmentId=appointmentId
  } else {
    const serviceId=Number(req.query.service_id)
    if (!serviceId || !['medical','derma'].includes(clinicType)) return res.status(400).json({ message:'Clinic and service are required.' })
    const [[service]]=await db.query(`SELECT id,clinic_type,average_duration_minutes,is_active FROM billing_service_catalog WHERE id=? LIMIT 1`,[serviceId])
    if (!service || Number(service.is_active)!==1 || ![clinicType,'all'].includes(String(service.clinic_type||''))) return res.status(409).json({ message:'The selected service is unavailable for this clinic.' })
    durationMinutes=roundReservedDurationMinutes(Number(service.average_duration_minutes||60),settings.booking_start_interval_minutes)
  }
  const slots=await getAvailableAppointmentSlots({doctorId,clinicType,date,durationMinutes,startIntervalMinutes:settings.booking_start_interval_minutes,excludeAppointmentId})
  res.json({slots,reserved_duration_minutes:durationMinutes,booking_start_interval_minutes:settings.booking_start_interval_minutes})
}

const getAppointmentReasons = async (req, res) => {
  const clinicType = String(req.query.clinic_type || '').trim()
  if (clinicType && !['medical', 'derma'].includes(clinicType)) {
    return res.status(400).json({ message: 'Invalid clinic type.' })
  }
  const params = []
  let sql = `SELECT id, label, clinic_type, is_active, sort_order
             FROM appointment_reason_options
             WHERE is_active = 1`
  if (clinicType) {
    sql += ' AND (clinic_type = ? OR clinic_type = "all")'
    params.push(clinicType)
  }
  sql += ' ORDER BY label ASC'
  const [rows] = await db.query(sql, params)
  res.json(withSystemOtherVisitReason(rows))
}

const getAppointmentCancellationReasons = async (req, res) => {
  res.json(await listCancellationReasons({ activeOnly: true }))
}

// ── Queue ─────────────────────────────────────────────────────────────────────

const getQueue = async (req, res) => {
  const today = req.query.date || getTodayDateOnly()
  const [rows] = await db.query(
    `SELECT q.*, d.full_name AS doctor_name
     FROM queue q
     JOIN doctors d ON q.doctor_id = d.id
     WHERE q.branch_id = ? AND d.branch_id = q.branch_id AND q.queue_date = ?
     ORDER BY q.queue_number ASC`,
    [req.branchId, today]
  )
  res.json(rows)
}

const getQueuePrecheck = async (req, res) => {
  const result = await getWalkInPrecheck(req.params.patientId, req.branchId)
  res.json(result)
}

const addToQueue = async (req, res) => {
  const result = await addWalkInVisit({
    patientId: req.body.patient_id,
    patientName: req.body.patient_name,
    doctorId: req.body.doctor_id,
    clinicType: req.body.type,
    reason: req.body.reason,
    checkInAppointmentId: req.body.check_in_appointment_id,
    allowSeparateWalkIn: Boolean(req.body.allow_separate_walkin),
    actorRole: 'staff',
    actorId: req.user.id,
    branchId: req.branchId,
    ipAddress: req.ip || null,
  })
  return res.status(result.status).json(result.body)
}

const updateQueueStatus = async (req, res) => {
  const requestedStatus = String(req.body.status || '').trim()
  const target = requestedStatus === 'in-progress' ? 'called' : requestedStatus
  if (!isValidQueueStatus(requestedStatus) && !['called','in_consultation'].includes(target)) {
    return res.status(400).json({ message: 'Invalid queue status.' })
  }
  try {
    const row = await setQueueState({
      branchId: req.branchId,
      queueId: req.params.id,
      nextStatus: target,
      actorRole: 'staff',
      actorId: req.user.id,
      ipAddress: req.ip || null,
    })
    res.json({ message: target === 'called' ? 'Patient called.' : 'Queue updated.', queue: row })
  } catch (error) {
    if (error.statusCode) return res.status(error.statusCode).json({ code: error.code, message: error.message })
    throw error
  }
}

// ── Patients ──────────────────────────────────────────────────────────────────

const getPatients = async (req, res) => {
  const search = req.query.search || ''
  const { likeSearch, phoneSearch, altPhoneSearch } = buildPhoneSearchTerms(search)
  const [rows] = await db.query(
    `SELECT id, full_name AS name, full_name, email, phone, sex, birthdate, address, civil_status, created_at
     FROM patients
     WHERE (full_name LIKE ? OR email LIKE ? OR ${NORMALIZED_PHONE_SQL} LIKE ? OR ${NORMALIZED_PHONE_SQL} LIKE ?)
       AND EXISTS (SELECT 1 FROM appointments a WHERE a.patient_id=patients.id AND a.branch_id=?)
     ORDER BY full_name`,
    [likeSearch, likeSearch, phoneSearch, altPhoneSearch, req.branchId]
  )
  res.json(rows)
}

const lookupWalkInPatients = async (req, res) => {
  const search = String(req.query.search || '').trim()
  if (search.length < 2) return res.json([])
  const { likeSearch, phoneSearch, altPhoneSearch } = buildPhoneSearchTerms(search)
  // Global identity lookup is deliberately available only on the Walk-in Queue route.
  // A returning patient must not be registered twice in different physical branches.
  const [rows] = await db.query(
    `SELECT id, full_name AS name, full_name, email, phone, sex, birthdate, address, civil_status
     FROM patients WHERE full_name LIKE ? OR email LIKE ? OR ${NORMALIZED_PHONE_SQL} LIKE ? OR ${NORMALIZED_PHONE_SQL} LIKE ?
     ORDER BY full_name LIMIT 30`, [likeSearch,likeSearch,phoneSearch,altPhoneSearch]
  )
  res.json(rows)
}

const createWalkInPatient = async (req, res) => {
  const {
    full_name = '', phone = '', email = '', birthdate = null, sex = null,
    consent_given, consent_method = 'signed_intake_form',
  } = req.body

  if (!String(full_name).trim() || !String(phone).trim())
    return res.status(400).json({ message: 'Full name and phone number are required.' })
  if (!consent_given)
    return res.status(400).json({ message: 'Patient data privacy consent is required before registration.' })

  const normalizedSex = ['Male', 'Female', 'Other'].includes(String(sex || '')) ? String(sex) : null
  const birthdateError = birthdate ? validateBirthdate(String(birthdate)) : null
  if (birthdateError) return res.status(400).json({ message: birthdateError })
  const normalizedBirthdate = birthdate ? String(birthdate).slice(0,10) : null
  const { normalizedPhone, existing } = await findExistingPatientByPhone(phone)
  if (!normalizedPhone)
    return res.status(400).json({ message: 'Enter a valid Philippine mobile number.' })
  if (existing) {
    return res.status(409).json({
      message: 'A patient with that phone number already exists. Search for the patient and add them as an existing patient instead.',
    })
  }

  const normalizedEmail = String(email || '').trim() || null
  if (normalizedEmail) {
    const [existingEmail] = await db.query('SELECT id FROM patients WHERE email = ?', [normalizedEmail])
    if (existingEmail.length > 0) return res.status(409).json({ message: 'A patient with that email already exists.' })
  }

  const tempPassword = makeTempPassword()
  const hashedPassword = await bcrypt.hash(tempPassword, 10)
  const [result] = await db.query(
    `INSERT INTO patients
      (full_name, birthdate, gender, sex, civil_status, phone, address, email, password, is_walk_in,
       consent_given, consent_given_at, consent_method, consent_recorded_by_staff_id, receive_promotions, is_profile_complete)
     VALUES (?, ?, ?, ?, NULL, ?, NULL, ?, ?, 1, 1, NOW(), ?, ?, 0, 0)`,
    [String(full_name).trim(), normalizedBirthdate, normalizedSex, normalizedSex, normalizedPhone, normalizedEmail, hashedPassword, String(consent_method || 'signed_intake_form'), req.user.id]
  )

  await db.query(
    'INSERT INTO patient_consents (patient_id, consent_type, ip_address) VALUES (?, ?, ?)',
    [result.insertId, 'data_processing', req.ip || null]
  )
  await writeAuditLog({
    userId: req.user.id,
    userRole: 'staff',
    action: 'patient.walkin_registered',
    entityType: 'patient',
    entityId: result.insertId,
    newValues: { full_name: String(full_name).trim(), phone: normalizedPhone, email: normalizedEmail, birthdate: normalizedBirthdate, sex: normalizedSex, consent_method },
    ipAddress: req.ip || null,
  })

  res.status(201).json({ id: result.insertId, full_name: String(full_name).trim(), phone: normalizedPhone, email: normalizedEmail, birthdate: normalizedBirthdate, sex: normalizedSex })
}

const getPatientRecord = async (req, res) => {
  const [pRows] = await db.query(
    `SELECT id, full_name, email, phone, sex,
            DATE_FORMAT(birthdate, '%Y-%m-%d') AS birthdate,
            address, civil_status, created_at
     FROM patients WHERE id = ? AND EXISTS (
       SELECT 1 FROM appointments a WHERE a.patient_id=patients.id AND a.branch_id=?
     )`,
    [req.params.id, req.branchId]
  )
  if (pRows.length === 0) return res.status(404).json({ message: 'Patient not found.' })
  const patient = pRows[0]

  const [history] = await db.query(
    `SELECT a.*,
            DATE_FORMAT(a.appointment_date,'%Y-%m-%d') AS date,
            a.appointment_time                          AS time,
            a.clinic_type                               AS type,
            d.full_name AS doctor_name, d.specialty,
            c.id AS consultation_id, c.diagnosis, c.prescription, c.notes AS consultation_notes
     FROM appointments a
     JOIN doctors d ON a.doctor_id = d.id
     LEFT JOIN consultations c ON c.appointment_id = a.id
     WHERE a.patient_id = ? AND a.branch_id = ?
     ORDER BY a.appointment_date DESC`,
    [req.params.id, req.branchId]
  )
  const imagesByConsultationId = await loadImagesForConsultationIds(history.map((row) => row.consultation_id))
  const [billingHistory] = await db.query(
    `SELECT b.id, b.status, b.subtotal, b.discount_amount, b.total_amount, b.payment_method, b.paid_at, b.created_at,
            DATE_FORMAT(a.appointment_date, '%Y-%m-%d') AS appointment_date,
            a.reason, d.full_name AS doctor_name,
            COALESCE((SELECT SUM(CASE WHEN bp.status = 'completed' THEN bp.amount - COALESCE(bp.refund_amount, 0) ELSE 0 END)
                      FROM billing_payments bp WHERE bp.billing_id = b.id), 0) AS paid_amount
     FROM billing_records b
     JOIN appointments a ON a.id = b.appointment_id
     JOIN doctors d ON d.id = b.doctor_id
     WHERE b.patient_id = ? AND b.branch_id = ?
     ORDER BY COALESCE(b.paid_at, b.created_at) DESC`,
    [req.params.id, req.branchId]
  )

  res.json({
    patient,
    history: history.map((row) => ({
      ...row,
      progress_images: imagesByConsultationId[row.consultation_id] || [],
    })),
    billing: billingHistory.map((bill) => ({ ...bill, balance_amount: Math.max(0, Number(bill.total_amount || 0) - Number(bill.paid_amount || 0)) })),
  })
}

// ── Inventory ─────────────────────────────────────────────────────────────────

const getBills = async (req, res) => {
  const rawStatus = String(req.query.status || '').trim()
  const statuses = rawStatus.split(',').map((value) => value.trim()).filter(Boolean)
  const search = String(req.query.search || '').trim()
  const paymentMethod = String(req.query.payment_method || '').trim().toLowerCase()
  const dateFrom = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date_from || '')) ? String(req.query.date_from) : ''
  const dateTo = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date_to || '')) ? String(req.query.date_to) : ''
  const dateBasis = ['visit','payment','finalized'].includes(String(req.query.date_basis || '').toLowerCase()) ? String(req.query.date_basis).toLowerCase() : 'visit'
  const page = Math.max(1, Number(req.query.page) || 1)
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 10))
  const offset = (page - 1) * limit

  const buildFilters = ({ includeStatus = true } = {}) => {
    const conditions = ['b.branch_id = ?', 'a.branch_id = b.branch_id', 'd.branch_id = b.branch_id']
    const params = [req.branchId]
    if (includeStatus) {
      if (statuses.length === 1) { conditions.push('b.status = ?'); params.push(statuses[0]) }
      else if (statuses.length > 1) { conditions.push(`b.status IN (${statuses.map(() => '?').join(',')})`); params.push(...statuses) }
    }
    if (dateBasis === 'payment' && (paymentMethod || dateFrom || dateTo)) {
      const paymentFilters = ["bpf.billing_id=b.id", "bpf.status='completed'"]
      if (paymentMethod) { paymentFilters.push('bpf.payment_method=?'); params.push(paymentMethod) }
      if (dateFrom) { paymentFilters.push('DATE(bpf.paid_at)>=?'); params.push(dateFrom) }
      if (dateTo) { paymentFilters.push('DATE(bpf.paid_at)<=?'); params.push(dateTo) }
      conditions.push(`EXISTS (SELECT 1 FROM billing_payments bpf WHERE ${paymentFilters.join(' AND ')})`)
    } else {
      if (paymentMethod) {
        conditions.push(`EXISTS (SELECT 1 FROM billing_payments bpm WHERE bpm.billing_id=b.id AND bpm.payment_method=? AND bpm.status='completed')`)
        params.push(paymentMethod)
      }
      const dateSql = dateBasis === 'finalized' ? (op) => `DATE(b.finalized_at) ${op} ?` : (op) => `a.appointment_date ${op} ?`
      if (dateFrom) { conditions.push(dateSql('>=')); params.push(dateFrom) }
      if (dateTo) { conditions.push(dateSql('<=')); params.push(dateTo) }
    }
    if (search) {
      const like = `%${search}%`
      conditions.push(`(p.full_name LIKE ? OR d.full_name LIKE ? OR a.reason LIKE ? OR CAST(b.id AS CHAR) LIKE ?
        OR EXISTS (SELECT 1 FROM billing_payments bps WHERE bps.billing_id=b.id AND (bps.payment_method LIKE ? OR COALESCE(bps.reference_number,'') LIKE ? OR COALESCE(bps.receipt_number,'') LIKE ?)))`)
      params.push(like, like, like, like, like, like, like)
    }
    return { conditions, params }
  }

  const { conditions, params } = buildFilters({ includeStatus: true })
  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : ''
  const baseJoin = `
    FROM billing_records b
    JOIN appointments a ON a.id = b.appointment_id
    JOIN patients p ON p.id = b.patient_id
    JOIN doctors d ON d.id = b.doctor_id
    LEFT JOIN staff s ON s.id = b.confirmed_by_staff_id
    LEFT JOIN (
      SELECT billing_id,
             COALESCE(SUM(CASE WHEN status = 'completed' THEN amount - COALESCE(refund_amount, 0) ELSE 0 END), 0) AS paid_amount,
             GROUP_CONCAT(DISTINCT CASE WHEN status='completed' THEN payment_method END ORDER BY payment_method SEPARATOR ',') AS payment_methods,
             MAX(CASE WHEN status='completed' THEN paid_at END) AS latest_payment_at
      FROM billing_payments
      GROUP BY billing_id
    ) pay ON pay.billing_id = b.id
  `

  const [[countRow]] = await db.query(`SELECT COUNT(*) AS total ${baseJoin} ${whereClause}`, params)
  const [rows] = await db.query(
    `SELECT b.id, b.appointment_id, b.status, b.subtotal, b.discount_type, b.discount_label, b.discount_amount,
            b.total_amount, b.payment_method, b.payment_notes, b.paid_at, b.finalized_at, b.created_at, b.updated_at, b.version,
            COALESCE(pay.paid_amount, 0) AS paid_amount,
            GREATEST(0, b.total_amount - COALESCE(pay.paid_amount, 0)) AS balance_amount,
            COALESCE(pay.payment_methods,'') AS payment_methods,
            pay.latest_payment_at,
            DATE_FORMAT(a.appointment_date, '%Y-%m-%d') AS appointment_date,
            a.appointment_time, a.reason AS appointment_reason, a.clinic_type, a.appointment_source,
            p.full_name AS patient_name, p.phone AS patient_phone,
            d.full_name AS doctor_name, d.specialty AS doctor_specialty,
            s.full_name AS confirmed_by_staff_name
     ${baseJoin}
     ${whereClause}
     ORDER BY FIELD(b.status, 'draft', 'pending', 'ready', 'partially_paid', 'paid', 'voided', 'refunded'), b.created_at DESC
     LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  )

  const summaryFilter = buildFilters({ includeStatus: false })
  const summaryWhere = summaryFilter.conditions.length ? `WHERE ${summaryFilter.conditions.join(' AND ')}` : ''
  const [[summary]] = await db.query(
    `SELECT COUNT(*) AS total,
            SUM(b.status IN ('draft','pending')) AS draft,
            SUM(b.status = 'ready') AS ready,
            SUM(b.status = 'partially_paid') AS partially_paid,
            SUM(b.status = 'paid') AS paid,
            COALESCE(SUM(CASE WHEN b.status IN ('draft','pending','ready','partially_paid') THEN GREATEST(0, b.total_amount - COALESCE(pay.paid_amount, 0)) ELSE 0 END), 0) AS outstanding,
            COALESCE(SUM(COALESCE(pay.paid_amount, 0)), 0) AS collected
     ${baseJoin}
     ${summaryWhere}`,
    summaryFilter.params
  )

  const total = Number(countRow?.total || 0)
  const totalPages = Math.max(1, Math.ceil(total / limit))
  res.json({
    items: rows.map((row) => ({
      ...row,
      paid_amount: Number(row.paid_amount || 0),
      balance_amount: Number(row.balance_amount || 0),
      payment_methods: String(row.payment_methods || '').split(',').filter(Boolean),
    })),
    pagination: { page, limit, total, totalPages, hasPrev: page > 1, hasNext: page < totalPages },
    summary: {
      total: Number(summary?.total || 0),
      draft: Number(summary?.draft || 0),
      pending: Number(summary?.draft || 0),
      ready: Number(summary?.ready || 0),
      partially_paid: Number(summary?.partially_paid || 0),
      paid: Number(summary?.paid || 0),
      outstanding: Number(summary?.outstanding || 0),
      collected: Number(summary?.collected || 0),
    },
  })
}

const getBillingCatalogForStaff = async (req, res) => {
  const rows = await listBillingCatalog({
    clinicType: String(req.query.clinic_type || '').trim() || undefined,
    branchId: req.branchId,
  })
  res.json(rows)
}

const getBillById = async (req, res) => {
  const [[owned]] = await db.query('SELECT id FROM billing_records WHERE id=? AND branch_id=? LIMIT 1', [req.params.id, req.branchId])
  if (!owned) return res.status(404).json({ message: 'Billing record not found.' })
  const bill = await getBillingRecordWithItems(req.params.id)
  if (!bill) return res.status(404).json({ message: 'Billing record not found.' })
  res.json(bill)
}

const parseBillingItemDetails = (item) => {
  const raw = item?.details || item?.details_json || null
  if (!raw) return {}
  if (typeof raw === 'object') return raw
  try { return JSON.parse(raw) || {} } catch { return {} }
}

const validateStaffSupplyAvailability = async (items = [], executor = db, branchId) => {
  if (!Number.isSafeInteger(Number(branchId)) || Number(branchId) < 1) throw Object.assign(new Error('Verified branch required for checkout supplies.'),{statusCode:403})
  const inventoryCache = new Map()
  const grouped = new Map()
  const checks = []

  for (const item of Array.isArray(items) ? items : []) {
    if (String(item?.item_type || '') !== 'supply' || String(item?.source_type || '') !== 'staff_supply') continue
    const inventoryId = Number(item?.source_inventory_id || 0)
    if (!inventoryId) continue

    let inventoryItem = inventoryCache.get(inventoryId)
    if (!inventoryItem) {
      const [[row]] = await executor.query('SELECT id,name,unit,base_unit,unit_size FROM inventory WHERE id=? AND branch_id=? LIMIT 1', [inventoryId,branchId])
      inventoryItem = row || null
      inventoryCache.set(inventoryId, inventoryItem)
    }
    if (!inventoryItem) {
      checks.push({ inventory_id: inventoryId, name: item?.service_name || 'Inventory item', requested: Number(item?.quantity || 0), available: 0, sufficient: false, message: 'Inventory item no longer exists.' })
      continue
    }

    const details = parseBillingItemDetails(item)
    const batchId = Number(details.batch_id || 0)
    const sourceLocationId = Number(details.source_location_id || 0)
    const sourceLocation = String(details.source_location || '').trim()
    const usageUnit = String(details.unit || inventoryItem.unit || '').trim()
    const baseUnit = String(inventoryItem.base_unit || '').trim()
    const unitSize = Math.max(1, Number(inventoryItem.unit_size) || 1)
    const requestedUsage = Math.max(0, Number(item?.quantity || 0))
    const packageRequested = usageUnit && baseUnit && usageUnit.toLowerCase() === baseUnit.toLowerCase()
      ? requestedUsage / unitSize
      : requestedUsage

    if (!batchId || !sourceLocationId) {
      checks.push({
        inventory_id: inventoryId,
        name: inventoryItem.name,
        requested: requestedUsage,
        available: 0,
        unit: usageUnit || inventoryItem.unit || '',
        sufficient: false,
        message: 'Select the exact batch to dispense for this Checkout item.',
      })
      continue
    }

    const key = `${inventoryId}:${batchId}:${sourceLocationId}`
    const current = grouped.get(key) || {
      inventory_id: inventoryId,
      batch_id: batchId,
      source_location_id: sourceLocationId,
      source_location: sourceLocation,
      name: inventoryItem.name,
      unit: usageUnit || inventoryItem.unit || '',
      requested: 0,
      package_requested: 0,
      unit_size: unitSize,
      uses_base_unit: Boolean(usageUnit && baseUnit && usageUnit.toLowerCase() === baseUnit.toLowerCase()),
    }
    current.requested += requestedUsage
    current.package_requested += packageRequested
    grouped.set(key, current)
  }

  for (const entry of grouped.values()) {
    const [[batch]] = await executor.query(
      `SELECT ib.id, ib.batch_code, ib.expiration_date, ib.archived_at, ib.quantity AS clinic_quantity,
              il.name AS location_name, COALESCE(ilb.quantity,0) AS location_quantity
       FROM inventory_batches ib
       JOIN inventory_locations il ON il.id = ? AND il.branch_id=? AND COALESCE(il.is_active,1)=1
       LEFT JOIN inventory_location_batches ilb ON ilb.location_id = il.id AND ilb.batch_id = ib.id
       WHERE ib.id = ? AND ib.inventory_id = ? AND ib.branch_id=?
       LIMIT 1`,
      [entry.source_location_id, branchId, entry.batch_id, entry.inventory_id, branchId]
    )
    const validBatch = batch && !batch.archived_at && (!batch.expiration_date || String(batch.expiration_date).slice(0,10) >= getTodayDateOnly())
    const packageAvailable = validBatch ? Math.min(Number(batch.location_quantity || 0), Number(batch.clinic_quantity || 0)) : 0
    const canonicalLocation = batch?.location_name || entry.source_location || 'selected location'
    entry.source_location = canonicalLocation
    const available = entry.uses_base_unit ? packageAvailable * entry.unit_size : packageAvailable
    const sufficient = packageAvailable + 0.0001 >= entry.package_requested
    checks.push({
      ...entry,
      batch_code: batch?.batch_code || null,
      available,
      sufficient,
      message: sufficient ? null : validBatch
        ? `${entry.name} batch ${batch?.batch_code || `#${entry.batch_id}`} only has ${available} ${entry.unit || 'unit(s)'} available at ${entry.source_location}.`
        : `The selected batch for ${entry.name} is expired, archived, missing, or unavailable at ${entry.source_location}.`,
    })
  }
  return checks
}

const dispenseCheckoutSupplies = async ({ bill, actorRole, userId, executor, branchId }) => {
  if (!Number.isSafeInteger(Number(branchId)) || Number(branchId)<1 || Number(bill?.branch_id)!==Number(branchId)) throw Object.assign(new Error('Billing branch mismatch during dispensing.'),{statusCode:403})
  const isAdminActor = actorRole === 'admin'
  const directSupplies = (bill?.items || []).filter((item) => item.item_type === 'supply' && item.source_type === 'staff_supply' && Number(item.source_inventory_id) > 0)
  if (!directSupplies.length) return []

  const validation = await validateStaffSupplyAvailability(directSupplies, executor, branchId)
  const insufficient = validation.find((entry) => !entry.sufficient)
  if (insufficient) {
    throw Object.assign(new Error(insufficient.message || `Not enough stock for ${insufficient.name}.`), { statusCode: 409, code: 'CHECKOUT_BATCH_STOCK_CHANGED' })
  }

  const dispensed = []
  for (const item of directSupplies) {
    const [[already]] = await executor.query(
      `SELECT id FROM billing_item_batch_usage WHERE billing_id=? AND billing_item_id=? AND movement_type='dispensed' LIMIT 1`,
      [bill.id, item.id]
    )
    if (already) continue

    const details = parseBillingItemDetails(item)
    const batchId = Number(details.batch_id || 0)
    const sourceLocationId = Number(details.source_location_id || 0)
    const sourceLocation = String(details.source_location || '').trim()
    if (!batchId || !sourceLocationId) {
      throw Object.assign(new Error(`Select an exact batch for ${item.service_name} before accepting the final payment.`), { statusCode: 409, code: 'CHECKOUT_BATCH_REQUIRED' })
    }

    const [[inventoryItem]] = await executor.query('SELECT id,name,unit,base_unit,unit_size FROM inventory WHERE id=? AND branch_id=? AND archived_at IS NULL LIMIT 1 FOR UPDATE', [item.source_inventory_id,branchId])
    if (!inventoryItem) throw Object.assign(new Error(`Inventory item for ${item.service_name} is no longer available.`), { statusCode: 400 })
    const [[sourceLocationRow]] = await executor.query('SELECT id,name FROM inventory_locations WHERE id=? AND branch_id=? AND COALESCE(is_active,1)=1 LIMIT 1', [sourceLocationId,branchId])
    if (!sourceLocationRow) throw Object.assign(new Error(`The selected stock location for ${item.service_name} is no longer available.`), { statusCode: 409, code: 'CHECKOUT_LOCATION_CHANGED' })
    const canonicalSourceLocation = sourceLocationRow.name
    const usageUnit = String(details.unit || inventoryItem.unit || '').trim().toLowerCase()
    const baseUnit = String(inventoryItem.base_unit || '').trim().toLowerCase()
    const unitSize = Math.max(1, Number(inventoryItem.unit_size) || 1)
    const requestedQty = Math.max(0, Number(item.quantity) || 0)
    const packageQty = usageUnit && baseUnit && usageUnit === baseUnit ? requestedQty / unitSize : requestedQty

    const consumption = await consumeInventoryFromLocationByBatches(
      inventoryItem.id,
      [{ batch_id: batchId, quantity: packageQty }],
      canonicalSourceLocation,
      executor
    )
    if (!consumption.ok) throw Object.assign(new Error(consumption.message || `Not enough stock for ${inventoryItem.name}.`), { statusCode: 409, code: 'CHECKOUT_BATCH_STOCK_CHANGED' })

    for (const batch of consumption.consumed) {
      const batchUsageQty = usageUnit && baseUnit && usageUnit === baseUnit ? Number(batch.quantity || 0) * unitSize : Number(batch.quantity || 0)
      await executor.query(
        `INSERT INTO billing_item_batch_usage (billing_id, billing_item_id, inventory_id, batch_id, package_quantity, usage_quantity, usage_unit_label, movement_type, source_location, source_location_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'dispensed', ?, ?)`,
        [bill.id, item.id || null, inventoryItem.id, batch.batch_id, Number(batch.quantity || 0), batchUsageQty, details.unit || inventoryItem.unit, canonicalSourceLocation, sourceLocationId]
      )
      await executor.query(
        `INSERT INTO inventory_logs (inventory_id, staff_id, admin_id, type, qty, note, movement_type, reference_type, reference_id, batch_id, from_location, branch_id)
         VALUES (?, ?, ?, 'out', ?, ?, 'dispensed', 'billing_record', ?, ?, ?, ?)`,
        [inventoryItem.id, isAdminActor ? null : userId, isAdminActor ? userId : null, Number(batch.quantity || 0), `${batch.batch_code || `Batch #${batch.batch_id}`} dispensed after full payment for billing record ${bill.id}: ${item.service_name}`, String(bill.id), batch.batch_id, canonicalSourceLocation, branchId]
      )
      dispensed.push({ billing_item_id: item.id, inventory_id: inventoryItem.id, batch_id: batch.batch_id, quantity: Number(batch.quantity || 0), source_location: canonicalSourceLocation, source_location_id: sourceLocationId })
    }
  }
  return dispensed
}

const updateBill = async (req, res) => {
  const actorRole = (req.user?.role === 'admin' || req.adminContext?.account_role === 'superadmin') ? 'admin' : 'staff'
  const isAdminActor = actorRole === 'admin'
  const billingId = Number(req.params.id)
  const expectedVersion = Number(req.body.expected_version)
  if (!billingId) return res.status(400).json({ message: 'A valid billing record is required.' })
  if (!Number.isInteger(expectedVersion) || expectedVersion < 1) {
    return res.status(400).json({ message: 'Reload this bill before saving. A valid bill version is required.', code: 'BILL_VERSION_REQUIRED' })
  }

  const paymentNotes = normalizeOptionalText(req.body.payment_notes, { field: 'Payment Notes', max: 500, multiline: true })
  const rawItems = Array.isArray(req.body.items) ? req.body.items : []
  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [lockedRows] = await conn.query('SELECT * FROM billing_records WHERE id = ? AND branch_id = ? LIMIT 1 FOR UPDATE', [billingId, req.branchId])
    if (!lockedRows.length) { await conn.rollback(); return res.status(404).json({ message: 'Billing record not found.' }) }
    const locked = lockedRows[0]
    if (!['draft', 'pending'].includes(locked.status)) { await conn.rollback(); return res.status(400).json({ message: 'Only draft bills can be edited. Finalized or paid bills are locked.' }) }
    if (Number(locked.version || 1) !== expectedVersion) {
      await conn.rollback()
      return res.status(409).json({ message: 'This bill was updated by another user while you were working on it. Review the latest version before saving.', code: 'BILL_VERSION_CONFLICT', current_version: Number(locked.version || 1) })
    }

    const currentBill = await getBillingRecordWithItems(billingId, conn)
    if (Number(currentBill.paid_amount || 0) > 0) { await conn.rollback(); return res.status(400).json({ message: 'A bill with recorded payments can no longer be edited.' }) }

    // Consultation-owned lines are server-owned clinical facts. Checkout never round-trips
    // or mutates them; Staff/Admin may only add non-service charges and billing-level fields.
    const consultationItems = (currentBill.items || []).filter((item) => ['consultation', 'consultation_extra'].includes(item.source_type))
    const protectedIds = new Set(consultationItems.map((item) => Number(item.id)))
    const securedConsultationItems = consultationItems.map((existing) => ({
      ...existing,
      id: Number(existing.id),
      source_type: existing.source_type === 'consultation_extra' ? 'consultation_extra' : 'consultation',
      source_reference_id: existing.source_reference_id || currentBill.consultation_id || null,
      unit_price: Number(existing.unit_price || 0),
      line_total: Math.round(Number(existing.quantity || 0) * Number(existing.unit_price || 0) * 100) / 100,
    }))

    const staffRawItems = rawItems.filter((item) => !protectedIds.has(Number(item?.id || 0)) && !['consultation', 'consultation_extra'].includes(String(item?.source_type || '')))
    if (staffRawItems.some((item) => String(item?.item_type || '').toLowerCase() === 'service' || Number(item?.catalog_service_id || 0) > 0)) {
      await conn.rollback()
      return res.status(400).json({ message: 'Clinic services must come from the Doctor consultation. Staff can add only Medicine / Supply or Custom Charge items at Checkout.', code: 'STAFF_SERVICE_NOT_ALLOWED' })
    }
    for (const item of staffRawItems) {
      if (String(item?.item_type || '').toLowerCase() === 'custom' && !String(item?.notes || '').trim()) {
        await conn.rollback()
        return res.status(400).json({ message: 'Every custom charge requires a reason or note for the audit trail.', code: 'CUSTOM_CHARGE_REASON_REQUIRED' })
      }
    }
    const normalizedStaffItems = await normalizeBillingItems(staffRawItems.map((item) => ({
      ...item,
      source_type: String(item?.item_type || '').toLowerCase() === 'supply' ? 'staff_supply' : 'staff_custom',
      source_reference_id: null,
    })), conn, req.branchId)

    const allItems = [...securedConsultationItems, ...normalizedStaffItems]
    if (!allItems.length) { await conn.rollback(); return res.status(400).json({ message: 'Add at least one bill item.' }) }

    const supplyChecks = await validateStaffSupplyAvailability(normalizedStaffItems, conn, req.branchId)
    const insufficient = supplyChecks.find((item) => !item.sufficient)
    if (insufficient) {
      await conn.rollback()
      return res.status(409).json({
        code: 'INVENTORY_INSUFFICIENT',
        message: `${insufficient.name} requires ${insufficient.requested} ${insufficient.unit || 'unit(s)'}, but only ${insufficient.available} is currently available for dispensing.`,
        inventory_id: insufficient.inventory_id,
        requested: insufficient.requested,
        available: insufficient.available,
      })
    }

    // Discount presets are branch-owned even though the shared pricing helper
    // can load them by globally unique ID. Check ownership before using it.
    if (req.body.discount_preset_id) {
      const [[preset]] = await conn.query('SELECT id FROM discount_presets WHERE id=? AND branch_id=? AND is_active=1', [req.body.discount_preset_id, req.branchId])
      if (!preset) { await conn.rollback(); return res.status(404).json({ message: 'Discount not found in this branch.' }) }
    }
    const subtotalOnly = computeBillingTotals({ items: allItems, discount_amount: 0 })
    const discount = await resolveDiscountForDraft({
      billingId,
      billVersion: expectedVersion,
      subtotal: subtotalOnly.subtotal,
      presetId: req.body.discount_preset_id,
      reference: req.body.discount_reference,
      referenceImageUrl: req.body.discount_reference_image_url,
      requestedAmount: req.body.discount_amount,
    }, conn, { allowDirectAdmin: isAdminActor })
    let discountReferenceImageUrl = null
    if (discount.preset && Number(discount.preset.requires_reference) === 1) {
      discountReferenceImageUrl = normalizeOptionalText(req.body.discount_reference_image_url, { field: 'Discount Proof Image', max: 500 })
      if (!discountReferenceImageUrl) {
        await conn.rollback()
        return res.status(400).json({ message: `${discount.preset.label} discount requires an uploaded reference / ID proof image.`, code: 'DISCOUNT_PROOF_REQUIRED' })
      }
      const sameAsSaved = String(currentBill.discount_reference_image_url || '') === String(discountReferenceImageUrl)
      let trustedFromApprovedRequest = false
      if (!sameAsSaved && !isAdminActor) {
        const [[approvedProof]] = await conn.query(
          `SELECT id FROM billing_adjustment_requests
           WHERE billing_id=? AND bill_version=? AND request_type='discount' AND status='approved'
             AND discount_preset_id=? AND reference_image_url=?
           ORDER BY resolved_at DESC, id DESC LIMIT 1`,
          [billingId, expectedVersion, discount.preset.id, discountReferenceImageUrl]
        )
        trustedFromApprovedRequest = Boolean(approvedProof)
      }
      if (!sameAsSaved && !trustedFromApprovedRequest) {
        try {
          verifyUploadSecurityToken(String(req.body.discount_reference_security_token || ''), {
            stage: 'accepted', role: actorRole, user_id: req.user.id,
            context_type: 'discount_proof', context_id: billingId, url: discountReferenceImageUrl,
          })
        } catch (error) {
          await conn.rollback()
          return res.status(error.statusCode || 400).json({ message: error.message || 'Upload the discount proof image again before saving this bill.', code: error.code || 'DISCOUNT_PROOF_INVALID' })
        }
      }
    }

    const totals = computeBillingTotals({ items: allItems, discount_amount: discount.amount })
    const nextVersion = expectedVersion + 1

    await replaceStaffBillingItems(billingId, securedConsultationItems, normalizedStaffItems, conn)
    const [billUpdate] = await conn.query(
      `UPDATE billing_records
       SET status = 'draft', subtotal = ?, discount_type = ?, discount_label = ?, discount_reference = ?, discount_reference_image_url = ?, discount_amount = ?, total_amount = ?, payment_notes = ?, version = ?
       WHERE id = ? AND version = ?`,
      [totals.subtotal, discount.type, discount.label, discount.preset ? (String(req.body.discount_reference || '').trim() || null) : null, discount.preset ? discountReferenceImageUrl : null, totals.discount_amount, totals.total_amount, paymentNotes, nextVersion, billingId, expectedVersion]
    )
    if (Number(billUpdate.affectedRows || 0) !== 1) {
      const err = new Error('This bill changed while it was being saved. Reload the latest version and try again.')
      err.statusCode = 409; err.code = 'BILL_VERSION_CONFLICT'; throw err
    }

    // Pending requests for the old revision are no longer safe after a material save.
    await conn.query(
      `UPDATE billing_adjustment_requests
       SET status = 'expired', resolved_at = NOW(), admin_note = COALESCE(admin_note, 'Bill changed after this request was submitted.')
       WHERE billing_id = ? AND bill_version = ? AND status = 'pending'`,
      [billingId, expectedVersion]
    )

    // Approved adjustments are intentionally not carried to the next bill version.
    // They authorize this save/finalization only; any later material edit requires a fresh approval.

    await writeAuditLog({
      userId: req.user.id, userRole: actorRole, action: 'billing.draft_updated', entityType: 'billing_record', entityId: billingId,
      oldValues: { version: expectedVersion, subtotal: currentBill.subtotal, discount_amount: currentBill.discount_amount, total_amount: currentBill.total_amount },
      newValues: { version: nextVersion, subtotal: totals.subtotal, discount_type: discount.type, discount_label: discount.label, discount_amount: totals.discount_amount, total_amount: totals.total_amount },
      ipAddress: req.ip || null, branchId: req.branchId,
    }, conn)
    await conn.commit()
  } catch (err) {
    await conn.rollback()
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message, code: err.code || undefined, current_version: err.current_version })
    throw err
  } finally { conn.release() }
  res.json(await getBillingRecordWithItems(billingId))
}

const getBillingAdjustmentRequests = async (req, res) => {
  const billingId = Number(req.params.id)
  const [rows] = await db.query(
    `SELECT bar.*, dp.label AS discount_label
     FROM billing_adjustment_requests bar
     LEFT JOIN discount_presets dp ON dp.id = bar.discount_preset_id
     WHERE bar.billing_id = ? ORDER BY bar.created_at DESC`, [billingId]
  )
  res.json(rows)
}

const requestBillingAdjustment = async (req, res) => {
  const billingId = Number(req.params.id)
  const type = String(req.body.request_type || '').trim()
  if (type !== 'discount') return res.status(400).json({ message: 'Only discount approval requests are supported.', code: 'PRICE_OVERRIDE_REMOVED' })
  const bill = await getBillingRecordWithItems(billingId)
  if (!bill || !['draft', 'pending'].includes(bill.status)) return res.status(400).json({ message: 'Only draft bills can request adjustments.' })

  const currentVersion = Number(bill.version || 1)
  await db.query(
    `UPDATE billing_adjustment_requests SET status='expired', resolved_at=NOW(), admin_note=COALESCE(admin_note,'Bill changed after this request was submitted.')
     WHERE billing_id=? AND status='pending' AND bill_version<>?`,
    [billingId, currentVersion]
  )

  let discountPresetId = null, catalogServiceId = null, requestedAmount = null, requestedPrice = null
  discountPresetId = Number(req.body.discount_preset_id) || null
  const preset = await loadDiscountPreset(discountPresetId)
  if (!preset || Number(preset.is_active) === 0) return res.status(400).json({ message: 'Select a valid discount preset.' })
  requestedAmount = Math.max(0, Number(req.body.requested_amount) || 0) || null
  if (requestedAmount && requestedAmount > Number(bill.subtotal || 0) + 0.001) return res.status(400).json({ message: 'Requested discount cannot exceed the bill subtotal.' })
  const reason = normalizeText(req.body.reason, { field: 'Approval Reason', required: true, max: 255, multiline: true })
  const reference = normalizeOptionalText(req.body.reference, { field: 'Discount Reference', max: 120 })
  const referenceImageUrl = normalizeOptionalText(req.body.reference_image_url, { field: 'Discount Proof Image', max: 500 })
  if (Number(preset.requires_reference) === 1) {
    if (!referenceImageUrl) return res.status(400).json({ message: `${preset.label} discount requires an uploaded reference / ID proof image.`, code: 'DISCOUNT_PROOF_REQUIRED' })
    try {
      verifyUploadSecurityToken(String(req.body.reference_security_token || ''), {
        stage: 'accepted', role: 'staff', user_id: req.user.id,
        context_type: 'discount_proof', context_id: billingId, url: referenceImageUrl,
      })
    } catch (error) {
      return res.status(error.statusCode || 400).json({ message: error.message || 'Upload the discount proof image again before requesting approval.', code: error.code || 'DISCOUNT_PROOF_INVALID' })
    }
  }

  const [existing] = await db.query(
    `SELECT id FROM billing_adjustment_requests WHERE billing_id=? AND bill_version=? AND staff_id=? AND request_type=? AND status='pending'
     AND COALESCE(discount_preset_id,0)=COALESCE(?,0) AND COALESCE(catalog_service_id,0)=COALESCE(?,0) LIMIT 1`,
    [billingId, currentVersion, req.user.id, type, discountPresetId, catalogServiceId]
  )
  if (existing.length) return res.status(409).json({ message: 'A matching approval request is already pending.' })

  const [result] = await db.query(
    `INSERT INTO billing_adjustment_requests
     (billing_id, bill_version, staff_id, request_type, discount_preset_id, catalog_service_id, requested_amount, requested_price, reference_text, reference_image_url, reason, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
    [billingId, currentVersion, req.user.id, type, discountPresetId, catalogServiceId, requestedAmount, requestedPrice, reference, referenceImageUrl, reason]
  )
  await writeAuditLog({ userId:req.user.id,userRole:'staff',action:`billing.${type}_approval_requested`,entityType:'billing_adjustment_request',entityId:result.insertId,newValues:{billing_id:billingId,bill_version:currentVersion,discount_preset_id:discountPresetId,catalog_service_id:catalogServiceId,requested_amount:requestedAmount,requested_price:requestedPrice,reference_image_url:referenceImageUrl,reason},ipAddress:req.ip||null })
  broadcast(['admin'], 'billing_adjustment_requested', { requestId: result.insertId, billingId }, { branchId: req.branchId })
  res.status(201).json({ message: 'Administrator approval requested.', id: result.insertId, bill_version: currentVersion })
}

const cancelBillingAdjustmentRequest = async (req, res) => {
  const billingId = Number(req.params.id)
  const requestId = Number(req.params.requestId)
  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [rows] = await conn.query(
      `SELECT * FROM billing_adjustment_requests WHERE id=? AND billing_id=? AND staff_id=? LIMIT 1 FOR UPDATE`,
      [requestId, billingId, req.user.id]
    )
    if (!rows.length) { await conn.rollback(); return res.status(404).json({ message: 'Approval request not found.' }) }
    if (rows[0].status !== 'pending') { await conn.rollback(); return res.status(409).json({ message: 'Only a pending approval request can be cancelled.' }) }
    await conn.query("UPDATE billing_adjustment_requests SET status='cancelled', resolved_at=NOW(), admin_note='Cancelled by requesting staff.' WHERE id=?", [requestId])
    await writeAuditLog({ userId:req.user.id,userRole:'staff',action:'billing.adjustment_cancelled',entityType:'billing_adjustment_request',entityId:requestId,oldValues:{status:'pending'},newValues:{status:'cancelled'},ipAddress:req.ip||null }, conn)
    await conn.commit()
  } catch (err) { await conn.rollback(); throw err } finally { conn.release() }
  broadcast(['admin'], 'billing_adjustment_cancelled', { requestId, billingId }, { branchId: req.branchId })
  res.json({ message: 'Approval request cancelled.' })
}

const getFinalizePreview = async (req, res) => {
  const billingId = Number(req.params.id)
  const bill = await getBillingRecordWithItems(billingId)
  if (!bill) return res.status(404).json({ message: 'Billing record not found.' })
  if (!['draft','pending'].includes(bill.status)) return res.status(400).json({ message: 'Only a draft bill can be reviewed for confirmation.' })
  const directSupplies = (bill.items || []).filter((row) => row.item_type === 'supply' && row.source_type === 'staff_supply' && Number(row.source_inventory_id) > 0)
  const supplies = await validateStaffSupplyAvailability(directSupplies, db, req.branchId)
  res.json({
    billing_id: billingId,
    version: Number(bill.version || 1),
    total_amount: Number(bill.total_amount || 0),
    charge_count: (bill.items || []).length,
    supply_count: directSupplies.length,
    supplies,
    can_finalize: supplies.every((item) => item.sufficient),
  })
}

const finalizeBill = async (req, res) => {
  const actorRole = (req.user?.role === 'admin' || req.adminContext?.account_role === 'superadmin') ? 'admin' : 'staff'
  const isAdminActor = actorRole === 'admin'
  const billingId = Number(req.params.id)
  const expectedVersion = Number(req.body.expected_version)
  if (!Number.isInteger(expectedVersion) || expectedVersion < 1) return res.status(400).json({ message: 'Reload this bill before confirming it. A valid bill version is required.', code: 'BILL_VERSION_REQUIRED' })

  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [lockedRows] = await conn.query('SELECT * FROM billing_records WHERE id=? AND branch_id=? LIMIT 1 FOR UPDATE', [billingId, req.branchId])
    if (!lockedRows.length) { await conn.rollback(); return res.status(404).json({ message: 'Billing record not found.' }) }
    const locked = lockedRows[0]
    if (!['draft','pending'].includes(locked.status)) { await conn.rollback(); return res.status(400).json({ message: 'Only draft bills can be confirmed.' }) }
    if (Number(locked.version || 1) !== expectedVersion) { await conn.rollback(); return res.status(409).json({ message: 'This bill changed before it could be confirmed. Review the latest version.', code: 'BILL_VERSION_CONFLICT', current_version:Number(locked.version||1) }) }
    const [[pendingApproval]] = await conn.query("SELECT COUNT(*) AS count FROM billing_adjustment_requests WHERE billing_id=? AND bill_version=? AND status='pending'", [billingId, expectedVersion])
    if (!isAdminActor && Number(pendingApproval?.count || 0) > 0) { await conn.rollback(); return res.status(409).json({ message: 'This bill still has a pending administrator approval. Resolve or cancel it before confirming the bill.', code: 'PENDING_BILLING_APPROVAL' }) }

    const bill = await getBillingRecordWithItems(billingId, conn)
    if (!Array.isArray(bill.items) || bill.items.length === 0) { await conn.rollback(); return res.status(400).json({ message: 'Add at least one bill item before confirming.' }) }

    const directSupplies = bill.items.filter((item) => item.item_type === 'supply' && item.source_type === 'staff_supply' && Number(item.source_inventory_id) > 0)
    const supplyChecks = await validateStaffSupplyAvailability(directSupplies, conn, req.branchId)
    const insufficientSupply = supplyChecks.find((item) => !item.sufficient)
    if (insufficientSupply) {
      await conn.rollback()
      return res.status(409).json({
        message: insufficientSupply.message || `Not enough stock for ${insufficientSupply.name}.`,
        code: 'CHECKOUT_BATCH_STOCK_CHANGED',
      })
    }


    const nextVersion = expectedVersion + 1
    const [updated] = await conn.query(
      `UPDATE billing_records SET status='ready', finalized_at=NOW(), finalized_by_staff_id=?, finalized_by_admin_id=?, version=? WHERE id=? AND version=?`,
      [isAdminActor ? null : req.user.id, isAdminActor ? req.user.id : null, nextVersion, billingId, expectedVersion]
    )
    if (Number(updated.affectedRows || 0) !== 1) throw Object.assign(new Error('This bill changed while it was being confirmed. Reload and try again.'), { statusCode:409, code:'BILL_VERSION_CONFLICT' })
    await conn.query("UPDATE billing_adjustment_requests SET status='expired', resolved_at=NOW(), admin_note=COALESCE(admin_note,'Bill was finalized before this request was used.') WHERE billing_id=? AND status='pending'", [billingId])
    await writeAuditLog({ userId:req.user.id,userRole:actorRole,action:'billing.finalized',entityType:'billing_record',entityId:billingId,oldValues:{status:locked.status,version:expectedVersion},newValues:{status:'ready',version:nextVersion,total_amount:bill.total_amount,pending_dispense_items:directSupplies.length},ipAddress:req.ip||null,branchId:req.branchId }, conn)
    await conn.commit()
  } catch (err) {
    await conn.rollback()
    if (err.statusCode) return res.status(err.statusCode).json({ message:err.message, code:err.code || undefined })
    throw err
  } finally { conn.release() }
  broadcast(['admin','staff'], 'billing_finalized', { billingId }, { branchId: req.branchId })
  res.json(await getBillingRecordWithItems(billingId))
}

// Used by both Staff and Admin checkout screens immediately after confirmation.
// Do not use the separate Admin Bill Corrections reopen handler here: that
// workflow can reverse dispensed inventory and requires a correction reason.
const reopenBillForEditing = async (req, res) => {
  const actorRole = (req.user?.role === 'admin' || req.adminContext?.account_role === 'superadmin') ? 'admin' : 'staff'
  const billingId = Number(req.params.id)
  const expectedVersion = Number(req.body?.expected_version)

  if (!Number.isSafeInteger(billingId) || billingId <= 0) {
    return res.status(400).json({ message: 'A valid billing record is required.' })
  }
  if (!Number.isSafeInteger(expectedVersion) || expectedVersion < 1) {
    return res.status(400).json({ message: 'Reload this bill before editing. A valid bill version is required.', code: 'BILL_VERSION_REQUIRED' })
  }

  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [rows] = await conn.query('SELECT * FROM billing_records WHERE id = ? AND branch_id = ? LIMIT 1 FOR UPDATE', [billingId, req.branchId])
    if (!rows.length) {
      await conn.rollback()
      return res.status(404).json({ message: 'Billing record not found.' })
    }

    const locked = rows[0]
    const [activeQr] = await conn.query('SELECT id FROM payment_gateway_attempts WHERE active_bill_id=? LIMIT 1 FOR UPDATE',[billingId])
    if (activeQr.length) { await conn.rollback(); return res.status(409).json({code:'QR_PAYMENT_PENDING',message:'A QR payment is pending. Wait for confirmation or reconcile it before reopening.'}) }
    if (locked.status !== 'ready') {
      await conn.rollback()
      return res.status(409).json({ message: 'Only a confirmed bill with no recorded payment can return to editing.', code: 'BILL_NOT_EDITABLE' })
    }
    if (Number(locked.version || 1) !== expectedVersion) {
      await conn.rollback()
      return res.status(409).json({
        message: 'This bill changed while you were reviewing it. Reload the latest bill before editing.',
        code: 'BILL_VERSION_CONFLICT',
        current_version: Number(locked.version || 1),
      })
    }

    // Check the *entire* payment history, including voided/refunded payments.
    // Do not allow this shortcut after any checkout stock movements, either.
    const [[paymentHistory]] = await conn.query('SELECT COUNT(*) AS count FROM billing_payments WHERE billing_id = ?', [billingId])
    if (Number(paymentHistory?.count || 0) > 0 || locked.paid_at) {
      await conn.rollback()
      return res.status(409).json({ message: 'This bill already has payment history. Use the administrator correction workflow instead.', code: 'BILL_HAS_PAYMENT_HISTORY' })
    }
    const [[stockHistory]] = await conn.query('SELECT COUNT(*) AS count FROM billing_item_batch_usage WHERE billing_id = ?', [billingId])
    if (Number(stockHistory?.count || 0) > 0) {
      await conn.rollback()
      return res.status(409).json({ message: 'This bill already has checkout stock movement history. Use the administrator correction workflow instead.', code: 'BILL_HAS_STOCK_HISTORY' })
    }

    const [updated] = await conn.query(
      `UPDATE billing_records
       SET status='draft', finalized_at=NULL, finalized_by_staff_id=NULL,
           finalized_by_admin_id=NULL, version=version+1
       WHERE id=? AND status='ready' AND version=?`,
      [billingId, expectedVersion]
    )
    if (Number(updated.affectedRows || 0) !== 1) {
      const error = new Error('The bill changed while reopening. Reload and try again.')
      error.statusCode = 409
      error.code = 'BILL_VERSION_CONFLICT'
      throw error
    }

    await writeAuditLog({
      userId: req.user.id,
      userRole: actorRole,
      action: 'billing.reopened_for_editing',
      entityType: 'billing_record',
      entityId: billingId,
      oldValues: { status: locked.status, version: expectedVersion },
      newValues: { status: 'draft', version: expectedVersion + 1 },
      ipAddress: req.ip || null, branchId: req.branchId,
    }, conn)
    await conn.commit()
  } catch (err) {
    await conn.rollback().catch(() => {})
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message, code: err.code })
    throw err
  } finally {
    conn.release()
  }

  broadcast(['admin', 'staff'], 'billing_reopened', { billingId }, { branchId: req.branchId })
  res.json(await getBillingRecordWithItems(billingId))
}

const payBill = async (req, res) => {
  const actorRole = (req.user?.role === 'admin' || req.adminContext?.account_role === 'superadmin') ? 'admin' : 'staff'
  const isAdminActor = actorRole === 'admin'
  const billingId = Number(req.params.id)
  const gatewayVerified = req.gatewayVerified?.provider === 'paymongo' && Boolean(req.gatewayVerified.paymentId)
  const paymentMethod = String(req.body.payment_method || '').trim().toLowerCase()
  const paymentNotes = normalizeOptionalText(req.body.payment_notes, { field: 'Payment Notes', max: 500, multiline: true })
  const referenceNumber = normalizeOptionalText(req.body.reference_number, { field: 'Reference Number', max: 120 })
  const idempotencyKey = String(req.body.idempotency_key || '').trim()
  if (!billingId) return res.status(400).json({ message: 'A valid billing record is required.' })
  if (!idempotencyKey || idempotencyKey.length > 100) return res.status(400).json({ message: 'A valid payment request key is required.' })
  if ((paymentMethod === 'qrph' && !gatewayVerified) || (gatewayVerified && paymentMethod !== 'qrph') || !isValidPaymentMethod(paymentMethod)) return res.status(400).json({ message: 'Select a valid payment method.' })
  const paymentMethodColumns = { cash: 'cash_enabled', gcash: 'gcash_enabled', maya: 'maya_enabled', bank_transfer: 'bank_transfer_enabled' }
  const enabledColumn = paymentMethodColumns[paymentMethod]
  const [paymentSettingsRows] = gatewayVerified ? [[{is_enabled:1}]] : await db.query(`SELECT ${enabledColumn} AS is_enabled FROM branch_payment_settings WHERE branch_id = ? LIMIT 1`, [req.branchId])
  if (!paymentSettingsRows.length) return res.status(503).json({ message: 'Payment methods are not configured for this branch.' })
  if (Number(paymentSettingsRows[0].is_enabled) === 0) {
    return res.status(400).json({ message: `${paymentMethod.replace('_', ' ')} is currently disabled by an administrator.` })
  }
  if (requiresPaymentReference(paymentMethod) && !referenceNumber) return res.status(400).json({ message: 'Enter the payment reference number.' })

  try {
    if (!gatewayVerified) await assertCashierOpen({ cashierRole: actorRole, cashierId: req.user.id, branchId:req.branchId })
  } catch (error) {
    return res.status(error.statusCode || 409).json({ message: error.message, code: error.code })
  }

  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    if (!gatewayVerified) await assertCashierOpen({ cashierRole: actorRole, cashierId: req.user.id,branchId:req.branchId },conn)
    const [duplicatePayments] = await conn.query('SELECT bp.billing_id,br.branch_id FROM billing_payments bp JOIN billing_records br ON br.id=bp.billing_id WHERE bp.idempotency_key = ? LIMIT 1', [idempotencyKey])
    if (duplicatePayments.length) {
      const existingId = duplicatePayments[0].billing_id
      const existingBranchId=Number(duplicatePayments[0].branch_id)
      await conn.rollback()
      if(existingBranchId!==Number(req.branchId)||Number(existingId)!==billingId) return res.status(409).json({code:'IDEMPOTENCY_KEY_CONFLICT',message:'This payment request identifier is already in use.'})
      return res.json(await getBillingRecordWithItems(existingId))
    }

    const [lockedRows] = await conn.query('SELECT * FROM billing_records WHERE id = ? AND branch_id = ? LIMIT 1 FOR UPDATE', [billingId, req.branchId])
    if (!lockedRows.length) { await conn.rollback(); return res.status(404).json({ message: 'Billing record not found.' }) }
    const lockedBill = lockedRows[0]
    // The initial check is only a fast-path. Concurrent retries can both miss it;
    // re-check *after* locking the bill so exactly one receipt/stock movement wins.
    const [sameKeyAfterLock] = await conn.query('SELECT bp.billing_id,br.branch_id FROM billing_payments bp JOIN billing_records br ON br.id=bp.billing_id WHERE bp.idempotency_key = ? LIMIT 1', [idempotencyKey])
    if (sameKeyAfterLock.length) {
      await conn.rollback()
      if (Number(sameKeyAfterLock[0].billing_id) !== billingId || Number(sameKeyAfterLock[0].branch_id) !== Number(req.branchId)) return res.status(409).json({code:'IDEMPOTENCY_KEY_CONFLICT',message:'Payment key already used for another bill.'})
      return res.json(await getBillingRecordWithItems(billingId))
    }
    if (requiresPaymentReference(paymentMethod) && referenceNumber) {
      const [duplicateRefs] = await conn.query(
        `SELECT id, billing_id, receipt_number FROM billing_payments
         WHERE payment_method = ? AND reference_number = ? AND status = 'completed' LIMIT 1 FOR UPDATE`,
        [paymentMethod, referenceNumber]
      )
      if (duplicateRefs.length) {
        await conn.rollback()
        return res.status(409).json({
          message: 'This payment reference was already recorded. Review transactions in your own branch or contact Super Admin.',
          code: 'DUPLICATE_PAYMENT_REFERENCE',
        })
      }
    }


    const [pendingQr] = await conn.query('SELECT id,payment_intent_id FROM payment_gateway_attempts WHERE active_bill_id=? LIMIT 1 FOR UPDATE', [billingId])
    if (pendingQr.length && (!gatewayVerified || pendingQr[0].payment_intent_id !== req.gatewayVerified.intentId)) {
      await conn.rollback(); return res.status(409).json({ code:'QR_PAYMENT_PENDING', message:'A QR payment is pending. Reconcile or expire it before recording another payment.' })
    }
    if (['paid', 'voided', 'refunded'].includes(lockedBill.status)) {
      await conn.rollback(); return res.status(409).json({ message: `This bill is already ${lockedBill.status}.` })
    }
    if (!['ready', 'partially_paid', 'pending'].includes(lockedBill.status)) {
      await conn.rollback(); return res.status(400).json({ message: 'Review and finalize this draft before accepting payment.' })
    }

    const existingBill = await getBillingRecordWithItems(billingId, conn)
    const balance = Math.max(0, Number(existingBill.balance_amount ?? existingBill.total_amount) || 0)
    if (balance <= 0) { await conn.rollback(); return res.status(409).json({ message: 'This bill has no remaining balance.' }) }
    const requestedPayment = req.body.payment_amount === '' || req.body.payment_amount === undefined || req.body.payment_amount === null
      ? balance
      : Math.max(0, Number(req.body.payment_amount) || 0)
    if (requestedPayment <= 0) { await conn.rollback(); return res.status(400).json({ message: 'Enter a payment amount greater than zero.' }) }
    if (requestedPayment > balance + 0.001) { await conn.rollback(); return res.status(400).json({ message: 'Payment amount cannot exceed the remaining balance.' }) }

    const tendered = paymentMethod === 'cash'
      ? Math.max(0, Number(req.body.amount_received ?? requestedPayment) || 0)
      : requestedPayment
    const paymentAmounts = calculatePaymentAmounts({ totalAmount: requestedPayment, amountReceived: tendered })
    if (!paymentAmounts.isSufficient) { await conn.rollback(); return res.status(400).json({ message: 'Amount received cannot be lower than the payment amount.' }) }

    // Sequential, clinic-dated official receipt number (locked until commit, no gaps).
    const { receiptNumber } = await allocateReceiptNumber(conn, lockedBill.branch_id)
    const balanceAfter = Math.max(0, Math.round((balance - requestedPayment) * 100) / 100)
    const nextStatus = balanceAfter <= 0 ? 'paid' : 'partially_paid'
    const paidAt = getClinicDateTimeSql()

    // Direct Medicine / Supply charges are physically dispensed only when the bill
    // becomes fully paid. Consultation service consumables were already deducted by
    // the Doctor workflow when the consultation was finalized, so they are never
    // deducted a second time here.
    let checkoutDispensed = []
    if (nextStatus === 'paid') {
      const billForDispense = await getBillingRecordWithItems(billingId, conn)
      checkoutDispensed = await dispenseCheckoutSupplies({
        bill: billForDispense,
        actorRole,
        userId: req.user.id,
        executor: conn,
        branchId: req.branchId,
      })
    }

    await conn.query(
      `INSERT INTO billing_payments
       (billing_id, amount, payment_method, reference_number, amount_received, change_amount, receipt_number, status, notes, received_by_staff_id, received_by_admin_id, idempotency_key, paid_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?, ?, ?, ?)`,
      [billingId, requestedPayment, paymentMethod, referenceNumber, tendered, paymentAmounts.changeAmount, receiptNumber, paymentNotes, isAdminActor ? null : req.user.id, isAdminActor ? req.user.id : null, idempotencyKey, paidAt]
    )
    await conn.query(
      `UPDATE billing_records
       SET status = ?, payment_method = ?, payment_notes = ?,
           confirmed_by_staff_id = CASE WHEN ? = 1 THEN confirmed_by_staff_id ELSE ? END,
           confirmed_by_admin_id = CASE WHEN ? = 1 THEN confirmed_by_admin_id ELSE ? END,
           paid_at = CASE WHEN ? = 'paid' THEN ? ELSE paid_at END
       WHERE id = ? AND branch_id = ?`,
      [nextStatus, paymentMethod, paymentNotes,
        gatewayVerified ? 1 : 0, isAdminActor ? null : req.user.id,
        gatewayVerified ? 1 : 0, isAdminActor ? req.user.id : null,
        nextStatus, paidAt, billingId, req.branchId]
    )
    await writeAuditLog({
      userId: gatewayVerified ? null : req.user.id, userRole: gatewayVerified ? 'system' : actorRole, action: 'billing.payment_received', entityType: 'billing_record', entityId: billingId,
      oldValues: { status: lockedBill.status, balance_amount: balance },
      newValues: { status: nextStatus, payment_amount: requestedPayment, balance_amount: balanceAfter, payment_method: paymentMethod, receipt_number: receiptNumber, checkout_items_dispensed: checkoutDispensed.length },
      ipAddress: req.ip || null, branchId:req.branchId,
    }, conn)
    await conn.commit()
    broadcast(['admin', 'staff'], 'billing_paid', { billingId, receiptNumber, status: nextStatus }, { branchId: req.branchId })
  } catch (err) {
    await conn.rollback()
    if (err.statusCode) return res.status(err.statusCode).json({ message: err.message, code: err.code || undefined })
    throw err
  } finally { conn.release() }
  res.json(await getBillingRecordWithItems(billingId))
}

// Backward-compatible route for older clients. It now uses the same atomic transaction.
const confirmBillPayment = payBill

const getDiscountPresets = async (req, res) => {
  const [rows] = await db.query(
    `SELECT id, label, discount_type, value, requires_reference, requires_admin_approval
     FROM discount_presets WHERE branch_id = ? AND is_active = 1 ORDER BY created_at ASC, id ASC`,
    [req.branchId]
  )
  res.json(rows)
}

const getPaymentSettingsForStaff = async (req, res) => {
  const [rows] = await db.query(
    `SELECT cash_enabled, gcash_enabled, maya_enabled, bank_transfer_enabled,
            gcash_qr_url, maya_qr_url, gcash_qr_mode, maya_qr_mode,
            bank_name, bank_account_name, bank_account_number, updated_at
     FROM branch_payment_settings WHERE branch_id = ? LIMIT 1`, [req.branchId]
  )
  res.json(rows[0] || {
    cash_enabled: 1, gcash_enabled: 0, maya_enabled: 0, bank_transfer_enabled: 0,
    gcash_qr_url: '', maya_qr_url: '', gcash_qr_mode: 'uploaded', maya_qr_mode: 'uploaded',
    bank_name: '', bank_account_name: '', bank_account_number: '', updated_at: null,
  })
}

const supplierSupportsClinic = (categoryValue, clinic) => String(categoryValue || '')
  .split(',')
  .map((value) => value.trim())
  .filter(Boolean)
  .includes(clinic)

const getInventoryMasterData = async (req, res) => {
  const category = ['medical','derma'].includes(String(req.query.category || '')) ? String(req.query.category) : null
  const [suppliers] = await db.query(`SELECT id,name,category FROM inventory_suppliers WHERE is_active=1 AND branch_id=? ${category ? "AND FIND_IN_SET(?, REPLACE(category,' ','')) > 0" : ''} ORDER BY name`, category ? [req.branchId,category] : [req.branchId])
  const [locationTypes] = await db.query('SELECT id,name,code,is_active,sort_order FROM inventory_location_types WHERE branch_id=? AND is_active=1 ORDER BY sort_order,name',[req.branchId])
  const [movementReasons] = await db.query(`SELECT id,name,code,movement_type,requires_batch,is_system
                                            FROM inventory_movement_reasons WHERE is_active=1
                                            ORDER BY FIELD(movement_type,'in','out'),is_system DESC,name ASC`)
  res.json({ suppliers, location_types: locationTypes, movement_reasons: movementReasons })
}

const getInventory = async (req, res) => {
  // Never run the single-clinic allocation repair here: it resolves a global
  // main stockroom and could otherwise move another branch's batch balance.
  const items = await loadInventoryRows(db, 'WHERE archived_at IS NULL AND branch_id=?', [req.branchId])
  res.json(items)
}

const addInventoryItem = async (req, res) => {
  if (rejectStaffPricingMutation(req, res)) return
  const validationError = validateInventoryRequiredFields(req.body, { requireOpeningQuantity: true, requireSellingPrice: false })
  if (validationError) return res.status(400).json(validationError)

  let {
    barcode, name, category, item_type, uom, dosage_form, strength, measurement_value, measurement_unit, unit, base_unit, unit_size, stock, threshold, price, selling_price, supplier, supplier_id,
    expiration_date, batch_code, batch_lot_code, supplier_lot_number, location_type_id,
  } = normalizeInventoryPayload(req.body)
  // Staff may create inventory records, but pricing is Admin-only.
  price = null
  selling_price = null
  if (!name || !category)
    return res.status(400).json({ message: 'Name and category are required.' })

  if (barcode) {
    const [existing] = await db.query('SELECT id FROM inventory WHERE barcode = ?', [barcode])
    if (existing.length > 0)
      return res.status(409).json({ message: 'An item with that barcode already exists.' })
  }

  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const setupSelection = await resolveInventorySetupSelection({ location_type_id, branchId: req.branchId }, conn)
    uom = setupSelection.uom
    unit = uom
    base_unit = uom
    location_type_id = setupSelection.locationType.id
    if (!barcode) barcode = await nextInventoryBarcode(category, req.branchId, conn)
    // Every receipt gets its own internal batch code automatically.
    batch_code = null
    if (supplier_id) {
      const [[supplierRow]] = await conn.query('SELECT id,name,category FROM inventory_suppliers WHERE id=? AND branch_id=? AND is_active=1 LIMIT 1',[supplier_id,req.branchId])
      if (!supplierRow || !supplierSupportsClinic(supplierRow.category, category)) {
        const error = new Error('Selected supplier is not assigned to this item clinic.')
        error.statusCode = 400
        error.code = 'SUPPLIER_CLINIC_MISMATCH'
        throw error
      }
      supplier = supplierRow.name
    }
    const [result] = await conn.query(
      `INSERT INTO inventory
       (barcode, name, category, item_type, uom, dosage_form, strength, measurement_value, measurement_unit, unit, base_unit, unit_size, stock, threshold, price, selling_price, supplier, supplier_id, expiration_date, storage_location, location_type_id, branch_id)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [barcode, name, category, item_type, uom, dosage_form, strength, measurement_value, measurement_unit, unit, base_unit, 1, 0, threshold, price, selling_price, supplier, supplier_id, null, null, location_type_id, req.branchId]
    )
    let openingBatchId = null
    let openingLocation = 'Main Stockroom'
    if (stock > 0) {
      const received = await receiveInventoryBatch(result.insertId, {
        quantity: stock,
        expiration_date: req.body.no_expiry ? null : expiration_date,
        batch_code,
        supplier_lot_number: null,
        supplier_id,
        unit_cost: 0,
        note: 'Opening stock',
        location: 'Main Stockroom',
      }, conn)
      openingBatchId = received.batch_id
      batch_code = received.batch_code
      expiration_date = received.expiration_date
      openingLocation = received.location || openingLocation
    }
    await syncInventorySnapshot(result.insertId, conn)
    if (stock > 0 && openingBatchId) {
      await conn.query(
        `INSERT INTO inventory_logs (inventory_id, staff_id, type, qty, note, movement_type, batch_id, to_location, branch_id)
         VALUES (?, ?, 'in', ?, ?, 'received', ?, ?, ?)`,
        [
          result.insertId,
          req.user.id,
          stock,
          `Opening stock · ${batch_code || `Batch #${openingBatchId}`}${expiration_date ? ` · expires ${expiration_date}` : ''}`,
          openingBatchId,
          openingLocation,
          req.branchId,
        ]
      )
    }
    await writeAuditLog({
      userId: req.user.id,
      userRole: 'staff',
      action: 'inventory.item_created',
      entityType: 'inventory_item',
      entityId: result.insertId,
      newValues: { name, category, item_type, barcode, uom, strength, measurement_value, measurement_unit, supplier_id, location_type_id, initial_quantity: Number(stock || 0), opening_batch_id: openingBatchId, opening_batch_code: batch_code || null, supplier_lot_number: null, expiration_date: expiration_date || null },
      ipAddress: req.ip || null,
    }, conn)
    await conn.commit()
    const rows = await loadInventoryRows(db, 'WHERE id = ? AND branch_id=?', [result.insertId, req.branchId])
    return res.status(201).json(rows[0])
  } catch (err) {
    await conn.rollback()
    if (err?.statusCode) return res.status(err.statusCode).json({ message: err.message, code: err.code || null })
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'That barcode is already assigned to another inventory item.' })
    }
    throw err
  } finally {
    conn.release()
  }
}

// FIX 2: Edit inventory item (name, barcode, category, unit, threshold, price, supplier)
const updateInventoryItem = async (req, res) => {
  if (rejectStaffPricingMutation(req, res)) return
  const validationError = validateInventoryRequiredFields(req.body, { requireSellingPrice: false })
  if (validationError) return res.status(400).json(validationError)

  let {
    barcode, name, category, item_type, uom, dosage_form, strength, measurement_value, measurement_unit, threshold, selling_price, supplier, supplier_id, location_type_id,
  } = normalizeInventoryPayload(req.body)
  if (!name || !category)
    return res.status(400).json({ message: 'Name and category are required.' })

  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [rows] = await conn.query('SELECT * FROM inventory WHERE id = ? AND branch_id=? FOR UPDATE', [req.params.id, req.branchId])
    if (rows.length === 0) {
      await conn.rollback()
      return res.status(404).json({ message: 'Item not found.' })
    }
    if (rows[0].archived_at) {
      await conn.rollback()
      return res.status(409).json({ code: 'INVENTORY_ARCHIVED', message: 'Archived inventory items cannot be edited.' })
    }

    const setupSelection = await resolveInventorySetupSelection({ location_type_id, branchId: req.branchId }, conn)
    const canonicalUom = setupSelection.uom
    location_type_id = setupSelection.locationType.id

    if (supplier_id) {
      const [[supplierRow]] = await conn.query('SELECT id,name,category FROM inventory_suppliers WHERE id=? AND branch_id=? AND is_active=1 LIMIT 1',[supplier_id,req.branchId])
      if (!supplierRow || !supplierSupportsClinic(supplierRow.category, category)) {
        const error = new Error('Selected supplier is not assigned to this item clinic.')
        error.statusCode = 400
        error.code = 'SUPPLIER_CLINIC_MISMATCH'
        throw error
      }
      supplier = supplierRow.name
    }

    await conn.query(
      `UPDATE inventory
       SET barcode=?, name=?, category=?, item_type=?, uom=?, dosage_form=?, strength=?, measurement_value=?, measurement_unit=?, unit=?, base_unit=?, unit_size=1, threshold=?, supplier=?, supplier_id=?, location_type_id=?
       WHERE id=? AND branch_id=?`,
      [barcode, name, category, item_type, canonicalUom, dosage_form, strength, measurement_value, measurement_unit, canonicalUom, canonicalUom, threshold, supplier, supplier_id, location_type_id, req.params.id, req.branchId]
    )
    await syncInventorySnapshot(req.params.id, conn)
    await conn.commit()
    const updated = await loadInventoryRows(db, 'WHERE id = ? AND branch_id=?', [req.params.id, req.branchId])
    res.json(updated[0])
  } catch (err) {
    await conn.rollback()
    if (err?.statusCode) return res.status(err.statusCode).json({ message: err.message, code: err.code || null })
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'That barcode is already assigned to another inventory item.' })
    }
    throw err
  } finally {
    conn.release()
  }
}

// FIX 2: Delete inventory item
const deleteInventoryItem = async (req, res) => {
  return res.status(403).json({
    code: 'ADMIN_REQUIRED',
    message: 'Only an administrator can archive or remove an inventory item.'
  })
}

const updateStock = async (req, res) => {
  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [[ownedItem]] = await conn.query('SELECT id FROM inventory WHERE id=? AND branch_id=? AND archived_at IS NULL FOR UPDATE', [req.params.id, req.branchId])
    if (!ownedItem) { await conn.rollback(); return res.status(404).json({ message: 'Item not found in this branch.' }) }
    await applyManualInventoryMovement({
      branchId: req.branchId,
      inventoryId: req.params.id,
      body: req.body,
      actorRole: 'staff',
      actorId: req.user.id,
      ipAddress: req.ip,
      executor: conn,
    })
    await conn.commit()
    const updated = await loadInventoryRows(db, 'WHERE id = ? AND branch_id=?', [req.params.id, req.branchId])
    res.json(updated[0])
  } catch (err) {
    await conn.rollback()
    if (err?.statusCode) return res.status(err.statusCode).json({ message: err.message, code: err.code || null, existing_batch_id: err.existingBatchId || null })
    throw err
  } finally {
    conn.release()
  }
}


const getInventoryLocations = async (req,res) => {
  const [rows] = await db.query(`SELECT l.id,l.name,l.location_type,l.is_active,l.created_at,l.is_main_stockroom,l.clinic_type,
      COUNT(DISTINCT CASE WHEN ilb.quantity>0 THEN ilb.inventory_id END) AS item_count,
      COUNT(DISTINCT CASE WHEN ilb.quantity>0 THEN ilb.batch_id END) AS batch_count
    FROM inventory_locations l
    LEFT JOIN inventory_location_batches ilb ON ilb.location_id=l.id
    WHERE l.branch_id=?
    GROUP BY l.id ORDER BY l.is_active DESC,l.name`, [req.branchId])
  res.json(rows)
}

const createInventoryLocation = async (req, res) => {
  const name = String(req.body?.name || '').trim()
  const type = ['stockroom','room','dispensing','storage'].includes(String(req.body?.location_type || '')) ? String(req.body.location_type) : 'storage'
  if (!name) return res.status(400).json({ message: 'Location name is required.' })
  try {
    const clinicType = type === 'room' ? normalizeClinicType(req.body?.clinic_type) : null
    const [result] = await db.query('INSERT INTO inventory_locations (name,location_type,is_active,clinic_type,branch_id) VALUES (?,?,1,?,?)', [name,type,clinicType,req.branchId])
    await writeAuditLog({ userId:req.user.id,userRole:'staff',action:'inventory.location_created',entityType:'inventory_location',entityId:result.insertId,newValues:{name,location_type:type,clinic_type:clinicType},ipAddress:req.ip||null }).catch(()=>{})
    res.status(201).json({ id: result.insertId, name, location_type: type, is_active: 1, clinic_type: clinicType, is_main_stockroom: 0 })
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'That storage location already exists.' })
    throw err
  }
}

const updateInventoryLocation = async (req,res) => {
  const id = Number(req.params.id)
  const name = String(req.body?.name || '').trim()
  const type = ['stockroom','room','dispensing','storage'].includes(String(req.body?.location_type || '')) ? String(req.body.location_type) : 'storage'
  if(!id || !name) return res.status(400).json({message:'Location name is required.'})
  const [[existing]] = await db.query('SELECT * FROM inventory_locations WHERE id=? AND branch_id=? LIMIT 1',[id,req.branchId])
  if(!existing) return res.status(404).json({message:'Storage location not found.'})
  if(Number(existing.is_main_stockroom||0)===1 && type!=='stockroom') return res.status(409).json({message:'The Main Stockroom must keep the Stockroom type. You can still rename it.',code:'MAIN_STOCKROOM_PROTECTED'})
  const clinicType = type==='room' ? (req.body?.clinic_type!==undefined ? normalizeClinicType(req.body.clinic_type) : existing.clinic_type || null) : null
  try {
    await db.query('UPDATE inventory_locations SET name=?,location_type=?,clinic_type=? WHERE id=? AND branch_id=?',[name,type,clinicType,id,req.branchId])
    await writeAuditLog({userId:req.user.id,userRole:'staff',action:'inventory.location_updated',entityType:'inventory_location',entityId:id,oldValues:existing,newValues:{name,location_type:type,clinic_type:clinicType},ipAddress:req.ip||null}).catch(()=>{})
    const [[row]] = await db.query('SELECT id,name,location_type,is_active,is_main_stockroom,clinic_type FROM inventory_locations WHERE id=? AND branch_id=?',[id,req.branchId])
    res.json(row)
  } catch(err){ if(err.code==='ER_DUP_ENTRY') return res.status(409).json({message:'That storage location already exists.'}); throw err }
}

// ── Doctors list ──────────────────────────────────────────────────────────────

// FIX 1: Added 'type' computed column so AddWalkInModal filter works
const getDoctors = async (req, res) => {
  const [rows] = await db.query(
    `SELECT
       id,
       full_name AS name,
       full_name,
       specialty,
       clinic_type,
       is_active,
       clinic_type AS type
     FROM doctors
     WHERE is_active = 1 AND branch_id=?
     ORDER BY full_name`, [req.branchId]
  )
  res.json(rows)
}

const getDoctorSchedules = async (req, res) => {
  const [rows] = await db.query(
    `SELECT ds.* FROM doctor_schedules ds JOIN doctors d ON d.id=ds.doctor_id
     WHERE ds.doctor_id=? AND d.branch_id=?
     ORDER BY FIELD(ds.day_of_week,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")`,
    [req.params.id, req.branchId]
  )
  res.json(rows)
}

const getDoctorAvailabilityForStaff = async (req, res) => {
  const doctorId = Number(req.params.id)
  if (!doctorId) return res.status(400).json({ message: 'A valid doctor is required.' })
  const startDate = String(req.query.start_date || '').trim() || undefined
  if (startDate && !isValidDateOnly(startDate)) return res.status(400).json({ message: 'A valid start date is required.' })
  const result = await buildDoctorAvailabilitySummary({
    doctorId,
    startDate,
    days: Math.min(14, Math.max(1, Number(req.query.days) || 14)),
  })
  const doctor = result.doctors?.[0]
  if (!doctor) return res.status(404).json({ message: 'Doctor not found.' })
  res.json({ start_date: result.start_date, end_date: result.end_date, days: result.days, doctor })
}

const getWalkInDoctors = async (req, res) => {
  const clinicType = String(req.query.clinic_type || '').trim()
  if (!['medical', 'derma'].includes(clinicType)) {
    return res.status(400).json({ message: 'Select a valid clinic type.' })
  }
  res.json(await buildWalkInDoctorAvailability({ clinicType, branchId: req.branchId }))
}

const getDoctorUnavailableDatesForStaff = async (req, res) => {
  const rows = await getDoctorUnavailableDates(req.params.id, {
    startDate: String(req.query.start_date || '').trim() || undefined,
    endDate: String(req.query.end_date || '').trim() || undefined,
  })
  res.json(rows)
}

// ── Supply Requests ───────────────────────────────────────────────────────────

const getSupplyRequests = async (req, res) => {
  const groups = await listSupplyTransferGroups({ branchId: req.branchId, pendingFirst: true })
  res.json(groups)
}

const resolveSupplyRequest = async (req, res) => {
  const result = await resolveSupplyTransfer({
    branchId: req.branchId,
    requestId: req.params.id,
    status: req.body.status,
    actorRole: 'staff',
    actorId: req.user.id,
    branchId: req.branchId,
    ipAddress: req.ip || null,
    note: req.body.note,
  })
  res.status(result.statusCode).json(result.body)
}

module.exports = {
  login, checkAuth, logout,
  getDashboard,
  getAppointments, createAppointment, getAppointmentInventoryReadinessForPortal, confirmAppointment, cancelAppointment, markAppointmentNoShow, rescheduleAppointment, getAppointmentReasons, getAppointmentCancellationReasons,
  getQueue, getQueuePrecheck, addToQueue, updateQueueStatus,
  getPatients, lookupWalkInPatients, getPatientRecord, createWalkInPatient,
  getBills, getBillingCatalogForStaff, getBillById, updateBill, getFinalizePreview, finalizeBill, reopenBillForEditing, payBill, confirmBillPayment, getDiscountPresets, getBillingAdjustmentRequests, requestBillingAdjustment, cancelBillingAdjustmentRequest, getPaymentSettingsForStaff,
  getInventory, getInventoryMasterData, addInventoryItem, updateInventoryItem, deleteInventoryItem, updateStock, getInventoryLocations, createInventoryLocation, updateInventoryLocation,
  getDoctors, getDoctorSchedules, getDoctorAvailabilityForStaff, getWalkInDoctors, getDoctorUnavailableDatesForStaff, getAppointmentAvailableSlotsForStaff,
  getSupplyRequests, resolveSupplyRequest,
}







