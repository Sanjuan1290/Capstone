// server/routers/admin.router.js
const express    = require('express')
const router     = express.Router()
const adminCtrl  = require('../controllers/admin.controller')
const staffCtrl  = require('../controllers/staff.controller')
const commonCtrl = require('../controllers/common.controller')
const correctionsCtrl = require('../controllers/billingCorrections.controller')
const authenticate = require('../middlewares/auth.middleware')
const requireRole  = require('../middlewares/role.middleware')
const { loginLimiter, otpRequestLimiter, otpVerifyLimiter } = require('../middlewares/rateLimit.middleware')

// The pre-existing admin controllers were written for a single clinic.
// Until individually scoped, ONLY Super Admin may call those legacy routes.
// Branch Admin uses the audited, explicitly filtered /api/branches/my API.
const requireLegacySuperAdmin = async (req,res,next) => {
  try {
    if (req.user?.account_role !== 'superadmin') return res.status(403).json({code:'BRANCH_ENDPOINT_REQUIRED',message:'Use branch-scoped endpoints.'})
    next()
  } catch(e){next(e)}
}

const accountAuth = [authenticate.adminContext(), requireRole('admin')]
const auth = [authenticate.adminContext(true), requireRole('admin'), requireLegacySuperAdmin]
const promotionsCtrl = require('../controllers/promotions.controller')

// ── Auth ──────────────────────────────────────────────────────────────────────
router.post('/login',      loginLimiter, adminCtrl.login)
router.post('/login/mfa',  otpVerifyLimiter, adminCtrl.verifyLoginMfa)
router.get('/check-auth',  adminCtrl.checkAuth)
router.post('/logout',     adminCtrl.logout)
router.post('/security/password/request-code', ...accountAuth, otpRequestLimiter, commonCtrl.requestMyPasswordCode)
router.post('/security/password/change', ...accountAuth, otpVerifyLimiter, commonCtrl.changeMyPassword)
router.get('/notifications', ...auth, commonCtrl.listNotifications)
router.patch('/notifications/read-all', ...auth, commonCtrl.readAllNotifications)
router.patch('/notifications/:id/read', ...auth, commonCtrl.readNotification)
router.get('/settings', ...accountAuth, commonCtrl.getMySettings)
router.put('/settings', ...accountAuth, commonCtrl.saveMySettings)
router.post('/settings/verification/request', ...accountAuth, otpRequestLimiter, commonCtrl.requestMySettingsVerification)
router.post('/settings/verification/confirm', ...accountAuth, otpVerifyLimiter, commonCtrl.confirmMySettingsVerification)
router.get('/landing-page', ...auth, commonCtrl.getAdminLandingPage)
router.put('/landing-page', ...auth, commonCtrl.saveAdminLandingPage)

// ── Promotions (Super Admin; patient-facing announcements only) ────────
router.get('/promotions', ...auth, promotionsCtrl.listAllPromotions)
router.post('/promotions', ...auth, promotionsCtrl.savePromotion)
router.put('/promotions/:id', ...auth, promotionsCtrl.savePromotion)
router.delete('/promotions/:id', ...auth, promotionsCtrl.deletePromotion)
router.post('/promotions/:id/notify', ...auth, promotionsCtrl.notifyOptedInPatients)

// ── Dashboard ─────────────────────────────────────────────────────────────────
router.get('/dashboard',   ...auth, adminCtrl.getDashboard)

// ── Appointments ──────────────────────────────────────────────────────────────
router.get('/appointments',                    ...auth, adminCtrl.getAppointments)
router.post('/appointments',                   ...auth, adminCtrl.createAppointment)
router.get('/appointment-reasons',             ...auth, adminCtrl.getAppointmentReasonOptions)
router.get('/appointment-cancellation-reasons', ...auth, adminCtrl.getAppointmentCancellationReasons)
router.post('/appointment-reasons',            ...auth, adminCtrl.createAppointmentReasonOption)
router.put('/appointment-reasons/:reasonId',   ...auth, adminCtrl.updateAppointmentReasonOption)
router.delete('/appointment-reasons/:reasonId',...auth, adminCtrl.deleteAppointmentReasonOption)
router.get('/appointments/:id/inventory-readiness', ...auth, adminCtrl.getAppointmentInventoryReadinessForPortal)
router.patch('/appointments/:id/confirm',      ...auth, adminCtrl.confirmAppointment)
router.patch('/appointments/:id/cancel',       ...auth, adminCtrl.cancelAppointment)
router.patch('/appointments/:id/no-show',      ...auth, adminCtrl.markAppointmentNoShow)
router.patch('/appointments/:id/reschedule',   ...auth, adminCtrl.rescheduleAppointment)

// ── Queue ─────────────────────────────────────────────────────────────────────
router.get('/queue',              ...auth, adminCtrl.getQueue)
router.get('/queue/precheck/:patientId', ...auth, adminCtrl.getQueuePrecheck)
router.post('/queue',             ...auth, adminCtrl.addToQueue)
router.patch('/queue/:id/status', ...auth, adminCtrl.updateQueueStatus)

// ── Patients ──────────────────────────────────────────────────────────────────
router.get('/patients',     ...auth, adminCtrl.getPatients)
router.post('/patients/walk-in', ...auth, adminCtrl.createWalkInPatient)
router.get('/patients/:id', ...auth, adminCtrl.getPatientRecord)

// ── Staff ─────────────────────────────────────────────────────────────────────
router.get('/staff',              ...auth, adminCtrl.getStaff)
router.post('/staff',             ...auth, adminCtrl.createStaff)
router.patch('/staff/:id/toggle', ...auth, adminCtrl.toggleStaff)
router.put('/staff/:id',          ...auth, adminCtrl.updateStaff)

// ── Doctors ───────────────────────────────────────────────────────────────────
router.get('/doctors',                    ...auth, adminCtrl.getDoctors)
router.post('/doctors',                   ...auth, adminCtrl.createDoctor)
router.patch('/doctors/:id/toggle',       ...auth, adminCtrl.toggleDoctor)
router.put('/doctors/:id',                ...auth, adminCtrl.updateDoctor)
router.get('/doctors/:id/schedules',      ...auth, adminCtrl.getDoctorSchedules)
router.put('/doctors/:id/schedules',      ...auth, adminCtrl.saveDaySchedule)
router.get('/doctors/:id/unavailable-dates', ...auth, adminCtrl.getDoctorUnavailableDatesAdmin)
router.get('/doctors/:id/available-slots', ...auth, adminCtrl.getAppointmentAvailableSlotsAdmin)
router.put('/doctors/:id/unavailable-dates', ...auth, adminCtrl.saveDoctorUnavailableDateAdmin)
router.delete('/doctors/:id/unavailable-dates/:date', ...auth, adminCtrl.deleteDoctorUnavailableDateAdmin)

// ── Reports ───────────────────────────────────────────────────────────────────
router.get('/billing', ...auth, staffCtrl.getBills)
router.get('/billing/reconciliation', ...auth, adminCtrl.getBillingReconciliation)
router.get('/billing/cashier-closing', ...auth, correctionsCtrl.getMyCashierClosing)
router.post('/billing/cashier-closing', ...auth, correctionsCtrl.closeMyCashier)
router.post('/billing/cashier-closings/:closingId/reopen', ...auth, correctionsCtrl.reopenCashierClosing)
router.get('/billing/:id/stock-usage', ...auth, correctionsCtrl.getBillStockUsage)
router.post('/billing/:id/void', ...auth, correctionsCtrl.voidBill)
router.post('/billing/:id/reopen', ...auth, correctionsCtrl.reopenBill)
// A separate endpoint preserves the Admin Bill Corrections workflow above.
router.post('/billing/:id/reopen-for-editing', ...auth, staffCtrl.reopenBillForEditing)
router.post('/billing/:id/consumables/:usageBatchId/return', ...auth, correctionsCtrl.returnConsultationConsumable)
router.get('/billing/adjustment-requests', ...auth, adminCtrl.getBillingAdjustmentRequestsAdmin)
router.patch('/billing/adjustment-requests/:id', ...auth, adminCtrl.resolveBillingAdjustmentRequestAdmin)
router.get('/billing/discount-presets', ...auth, adminCtrl.getDiscountPresetsAdmin)
router.post('/billing/discount-presets', ...auth, adminCtrl.saveDiscountPresetAdmin)
router.put('/billing/discount-presets/:id', ...auth, adminCtrl.saveDiscountPresetAdmin)
router.post('/billing/payments/:paymentId/void', ...auth, otpRequestLimiter, adminCtrl.voidBillingPayment)
router.post('/billing/payments/:paymentId/refund', ...auth, otpRequestLimiter, adminCtrl.refundBillingPayment)
router.post('/billing/payments/:paymentId/action/confirm', ...auth, otpVerifyLimiter, adminCtrl.confirmBillingPaymentAction)
router.get('/billing/catalog', ...auth, adminCtrl.getBillingCatalogAdmin)
router.post('/billing/catalog', ...auth, adminCtrl.createBillingCatalogService)
router.put('/billing/catalog/:serviceId', ...auth, adminCtrl.updateBillingCatalogService)
router.delete('/billing/catalog/:serviceId', ...auth, adminCtrl.deleteBillingCatalogService)
router.get('/billing/payment-settings', ...auth, adminCtrl.getPaymentSettingsAdmin)
router.post('/billing/payment-settings/upload', ...auth, express.raw({ type: ['image/png', 'image/jpeg', 'image/webp'], limit: '5mb' }), adminCtrl.uploadPaymentQrImageAdmin)
router.post('/billing/payment-settings/upload-status', ...auth, adminCtrl.getPaymentQrUploadScanStatusAdmin)
router.post('/billing/discount-proof/upload', ...auth, express.raw({ type: ['image/png', 'image/jpeg'], limit: '5mb' }), adminCtrl.uploadDiscountProofImageAdmin)
router.post('/billing/discount-proof/upload-status', ...auth, adminCtrl.getDiscountProofUploadScanStatusAdmin)
router.put('/billing/payment-settings', ...auth, adminCtrl.updatePaymentSettingsAdmin)
router.get('/billing/:id', ...auth, staffCtrl.getBillById)
router.put('/billing/:id', ...auth, staffCtrl.updateBill)
router.get('/billing/:id/finalize-preview', ...auth, staffCtrl.getFinalizePreview)
router.post('/billing/:id/finalize', ...auth, staffCtrl.finalizeBill)
router.post('/billing/:id/pay', ...auth, staffCtrl.payBill)
router.post('/billing/:id/confirm-payment', ...auth, staffCtrl.confirmBillPayment)
router.get('/billing/:id/adjustment-requests', ...auth, staffCtrl.getBillingAdjustmentRequests)
router.get('/reports', ...auth, adminCtrl.getReports)
router.post('/reports/export-audit', ...auth, adminCtrl.recordReportExport)
router.get('/audit-logs', ...auth, adminCtrl.getAuditLogs)
router.get('/audit-logs/archive', ...auth, adminCtrl.getAuditArchiveBatches)
router.post('/audit-logs/archive', ...auth, adminCtrl.archiveAuditLogs)
router.get('/audit-logs/archive/:archiveId', ...auth, adminCtrl.getAuditArchiveDetail)
router.delete('/audit-logs/archive/:archiveId', ...auth, adminCtrl.deleteAuditArchive)
router.get('/system-setup', ...auth, adminCtrl.getSystemSetup)
router.get('/system-setup/booking-policy', ...auth, adminCtrl.getBookingPolicyAdmin)
router.put('/system-setup/booking-policy', ...auth, adminCtrl.updateBookingPolicyAdmin)
router.post('/system-setup/cancellation-reasons', ...auth, adminCtrl.saveAppointmentCancellationReason)
router.put('/system-setup/cancellation-reasons/:id', ...auth, adminCtrl.saveAppointmentCancellationReason)
router.delete('/system-setup/cancellation-reasons/:id', ...auth, adminCtrl.deleteAppointmentCancellationReason)
router.post('/system-setup/service-categories', ...auth, adminCtrl.saveBillingServiceCategory)
router.put('/system-setup/service-categories/:id', ...auth, adminCtrl.saveBillingServiceCategory)
router.delete('/system-setup/service-categories/:id', ...auth, adminCtrl.deleteBillingServiceCategory)
router.post('/system-setup/uoms', ...auth, adminCtrl.saveInventoryUom)
router.put('/system-setup/uoms/:id', ...auth, adminCtrl.saveInventoryUom)
router.delete('/system-setup/uoms/:id', ...auth, adminCtrl.deleteInventoryUom)
router.post('/system-setup/suppliers', ...auth, adminCtrl.saveInventorySupplier)
router.put('/system-setup/suppliers/:id', ...auth, adminCtrl.saveInventorySupplier)
router.post('/system-setup/location-types', ...auth, adminCtrl.saveInventoryLocationType)
router.put('/system-setup/location-types/:id', ...auth, adminCtrl.saveInventoryLocationType)
router.post('/system-setup/movement-reasons', ...auth, adminCtrl.saveInventoryMovementReason)
router.put('/system-setup/movement-reasons/:id', ...auth, adminCtrl.saveInventoryMovementReason)
router.get('/clinic-settings', ...auth, adminCtrl.getClinicSettingsAdmin)
router.put('/clinic-settings', ...auth, adminCtrl.updateClinicSettingsAdmin)

// ── Inventory ─────────────────────────────────────────────────────────────────
router.get('/inventory',              ...auth, adminCtrl.getInventory)
router.get('/inventory/master-data',  ...auth, adminCtrl.getInventoryMasterData)
router.post('/inventory/locations',    ...auth, adminCtrl.createInventoryLocation)
router.get('/inventory/locations',     ...auth, adminCtrl.getInventoryLocationsAdmin)
router.put('/inventory/locations/:id', ...auth, adminCtrl.updateInventoryLocation)
router.delete('/inventory/locations/:id', ...auth, adminCtrl.deleteInventoryLocation)
router.post('/inventory/suppliers',    ...auth, adminCtrl.createInventorySupplier)
router.get('/inventory/logs',         ...auth, adminCtrl.getInventoryLogs)
router.post('/inventory',             ...auth, adminCtrl.addInventoryItem)
router.patch('/inventory/:id/stock',  ...auth, adminCtrl.updateStock)
router.post('/inventory/:id/move-location', ...auth, correctionsCtrl.moveStockBetweenLocations)
router.get('/inventory/batches/:batchId/history', ...auth, adminCtrl.getInventoryBatchHistory)
router.post('/inventory/batches/:batchId/action/request-code', ...auth, otpRequestLimiter, adminCtrl.requestInventoryBatchActionCode)
router.post('/inventory/batches/:batchId/action/confirm', ...auth, otpVerifyLimiter, adminCtrl.confirmInventoryBatchAction)
// FIX 5: Edit and Delete inventory items
router.put('/inventory/:id',          ...auth, adminCtrl.updateInventoryItem)
router.delete('/inventory/:id',       ...auth, adminCtrl.deleteInventoryItem)

// ── Supply Requests ───────────────────────────────────────────────────────────
router.get('/supply-requests',       ...auth, adminCtrl.getSupplyRequests)
router.patch('/supply-requests/:id', ...auth, adminCtrl.resolveSupplyRequest)

module.exports = router





